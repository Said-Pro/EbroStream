#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EbroStream Web API Server
Gestion complète des serveurs Stalker et Xtream via interface web
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import sys
import uuid
from urllib.parse import urlparse, parse_qs

# Ajouter le chemin du plugin
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
if PLUGIN_PATH not in sys.path:
    sys.path.insert(0, PLUGIN_PATH)

# Configuration
CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"
DEFAULT_PORT = 8088  # Changé de 8080 à 8088

# Créer le répertoire de config si nécessaire
os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)


class EbroStreamAPIHandler(BaseHTTPRequestHandler):
    """Gestionnaire des requêtes API"""
    
    def _send_json_response(self, code, data):
        """Envoie une réponse JSON"""
        response = json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(response)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(response)
    
    def _send_html_response(self, content):
        """Envoie une réponse HTML"""
        content_encoded = content.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(content_encoded)))
        self.end_headers()
        self.wfile.write(content_encoded)
    
    def do_OPTIONS(self):
        """Gère les requêtes CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_GET(self):
        """Traite les requêtes GET"""
        parsed = urlparse(self.path)
        path = parsed.path
        
        # Routes API
        if path == '/api/servers':
            self._get_servers()
        elif path == '/api/servers/stalker':
            self._get_stalker_servers()
        elif path == '/api/servers/xtream':
            self._get_xtream_servers()
        elif path == '/api/active':
            self._get_active_server()
        elif path == '/api/status':
            self._get_status()
        elif path == '/' or path == '' or path == '/index.html':
            self._serve_web_interface()
        else:
            self._send_json_response(404, {"error": f"Route non trouvée: {path}"})
    
    def do_POST(self):
        """Traite les requêtes POST"""
        parsed = urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(post_data) if post_data else {}
        except json.JSONDecodeError:
            data = {}
        
        if path == '/api/servers/stalker':
            self._add_stalker_server(data)
        elif path == '/api/servers/xtream':
            self._add_xtream_server(data)
        elif path == '/api/servers/validate':
            self._validate_server(data)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    def do_PUT(self):
        """Traite les requêtes PUT (mise à jour)"""
        parsed = urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        put_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(put_data) if put_data else {}
        except json.JSONDecodeError:
            data = {}
        
        if path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._update_server(server_id, data)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    def do_DELETE(self):
        """Traite les requêtes DELETE"""
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._delete_server(server_id)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    # ==================== MÉTHODES API ====================
    
    def _get_servers(self):
        """Retourne tous les serveurs"""
        try:
            servers = self._load_servers()
            for server in servers:
                if 'password' in server:
                    server['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "servers": servers,
                "total": len(servers)
            })
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_stalker_servers(self):
        """Retourne uniquement les serveurs Stalker"""
        try:
            servers = self._load_servers()
            stalker_servers = [s for s in servers if s.get('type') == 'stalker']
            for server in stalker_servers:
                if 'password' in server:
                    server['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "servers": stalker_servers,
                "total": len(stalker_servers)
            })
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_xtream_servers(self):
        """Retourne uniquement les serveurs Xtream"""
        try:
            servers = self._load_servers()
            xtream_servers = [s for s in servers if s.get('type') == 'xtream']
            for server in xtream_servers:
                if 'password' in server:
                    server['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "servers": xtream_servers,
                "total": len(xtream_servers)
            })
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_active_server(self):
        """Retourne le serveur actif"""
        try:
            servers = self._load_servers()
            active = next((s for s in servers if s.get('active', False)), None)
            if active and 'password' in active:
                active['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "server": active
            })
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_status(self):
        """Retourne le statut du serveur web"""
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            try:
                ip = socket.gethostbyname(socket.gethostname())
            except:
                ip = "127.0.0.1"
        
        self._send_json_response(200, {
            "success": True,
            "status": "running",
            "version": "4.2.1",
            "server": "EbroStream Web Interface",
            "ip": ip,
            "port": DEFAULT_PORT
        })
    
    def _add_stalker_server(self, data):
        """Ajoute un serveur Stalker"""
        errors = []
        
        name = data.get('name', '').strip()
        if not name:
            errors.append("Le nom du serveur est requis")
        
        host = data.get('host', '').strip()
        if not host:
            errors.append("L'URL du serveur est requise")
        elif not host.startswith(('http://', 'https://')):
            errors.append("L'URL doit commencer par http:// ou https://")
        
        mac = data.get('mac', '').strip()
        if not mac:
            errors.append("L'adresse MAC est requise")
        
        if errors:
            self._send_json_response(400, {"success": False, "errors": errors})
            return
        
        server = {
            "id": str(uuid.uuid4())[:8],
            "type": "stalker",
            "name": name,
            "host": host.rstrip('/'),
            "mac": self._format_mac(mac),
            "active": data.get('active', False)
        }
        
        if server['active']:
            self._deactivate_all_servers()
        
        servers = self._load_servers()
        servers.append(server)
        
        if self._save_servers(servers):
            self._send_json_response(201, {
                "success": True,
                "message": f"Serveur Stalker '{name}' ajouté avec succès",
                "server": server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _add_xtream_server(self, data):
        """Ajoute un serveur Xtream"""
        errors = []
        
        name = data.get('name', '').strip()
        if not name:
            errors.append("Le nom du serveur est requis")
        
        host = data.get('host', '').strip()
        if not host:
            errors.append("L'hôte du serveur est requis")
        
        username = data.get('username', '').strip()
        if not username:
            errors.append("Le nom d'utilisateur est requis")
        
        password = data.get('password', '').strip()
        if not password:
            errors.append("Le mot de passe est requis")
        
        if errors:
            self._send_json_response(400, {"success": False, "errors": errors})
            return
        
        server = {
            "id": str(uuid.uuid4())[:8],
            "type": "xtream",
            "name": name,
            "host": host.rstrip('/'),
            "username": username,
            "password": password,
            "active": data.get('active', False)
        }
        
        if server['active']:
            self._deactivate_all_servers()
        
        servers = self._load_servers()
        servers.append(server)
        
        if self._save_servers(servers):
            response_server = server.copy()
            response_server['password'] = '********'
            self._send_json_response(201, {
                "success": True,
                "message": f"Serveur Xtream '{name}' ajouté avec succès",
                "server": response_server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _update_server(self, server_id, data):
        """Met à jour un serveur existant"""
        servers = self._load_servers()
        
        server_index = None
        for i, s in enumerate(servers):
            if s.get('id') == server_id:
                server_index = i
                break
        
        if server_index is None:
            self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
            return
        
        server = servers[server_index]
        
        if 'name' in data:
            server['name'] = data['name'].strip()
        if 'host' in data:
            server['host'] = data['host'].strip()
        if 'active' in data:
            server['active'] = data['active']
        
        if server['type'] == 'stalker':
            if 'mac' in data:
                server['mac'] = self._format_mac(data['mac'])
        else:
            if 'username' in data:
                server['username'] = data['username'].strip()
            if 'password' in data and data['password'] and data['password'] != '********':
                server['password'] = data['password'].strip()
        
        if server.get('active', False):
            for i, s in enumerate(servers):
                if i != server_index:
                    s['active'] = False
        
        if self._save_servers(servers):
            response_server = server.copy()
            if 'password' in response_server:
                response_server['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "message": "Serveur mis à jour avec succès",
                "server": response_server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _delete_server(self, server_id):
        """Supprime un serveur"""
        servers = self._load_servers()
        
        new_servers = [s for s in servers if s.get('id') != server_id]
        
        if len(new_servers) == len(servers):
            self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
            return
        
        if self._save_servers(new_servers):
            self._send_json_response(200, {
                "success": True,
                "message": "Serveur supprimé avec succès"
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la suppression"})
    
    def _validate_server(self, data):
        """Valide un serveur avant ajout"""
        server_type = data.get('type', 'stalker')
        errors = []
        
        if not data.get('name', '').strip():
            errors.append("Le nom du serveur est requis")
        
        if server_type == 'stalker':
            host = data.get('host', '').strip()
            if not host:
                errors.append("L'URL du serveur est requise")
            elif not host.startswith(('http://', 'https://')):
                errors.append("L'URL doit commencer par http:// ou https://")
            
            mac = data.get('mac', '').strip()
            if not mac:
                errors.append("L'adresse MAC est requise")
            elif not self._validate_mac(mac):
                errors.append("Format MAC invalide (ex: 00:1A:79:00:00:00)")
        else:
            if not data.get('host', '').strip():
                errors.append("L'hôte du serveur est requis")
            if not data.get('username', '').strip():
                errors.append("Le nom d'utilisateur est requis")
            if not data.get('password', '').strip():
                errors.append("Le mot de passe est requis")
        
        self._send_json_response(200, {
            "success": len(errors) == 0,
            "errors": errors
        })
    
    # ==================== MÉTHODES UTILITAIRES ====================
    
    def _load_servers(self):
        """Charge les serveurs depuis le fichier JSON"""
        if not os.path.exists(CONFIG_FILE):
            return []
        
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
                elif isinstance(data, dict) and 'servers' in data:
                    return data['servers']
                return []
        except (json.JSONDecodeError, IOError) as e:
            print(f"[WebAPI] Erreur chargement: {e}")
            return []
    
    def _save_servers(self, servers):
        """Sauvegarde les serveurs dans le fichier JSON"""
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            
            data = {
                "version": "2.0",
                "servers": servers,
                "total": len(servers)
            }
            
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except IOError as e:
            print(f"[WebAPI] Erreur sauvegarde: {e}")
            return False
    
    def _deactivate_all_servers(self):
        """Désactive tous les serveurs"""
        servers = self._load_servers()
        for server in servers:
            server['active'] = False
        self._save_servers(servers)
    
    def _format_mac(self, mac):
        """Formate une adresse MAC"""
        if not mac:
            return "00:00:00:00:00:00"
        
        mac = mac.strip().upper()
        mac = ''.join(c for c in mac if c.isalnum())
        
        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]
        
        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])
    
    def _validate_mac(self, mac):
        """Valide une adresse MAC"""
        import re
        pattern = r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'
        return bool(re.match(pattern, mac))
    
    # ==================== INTERFACE WEB ====================
    
    def _serve_web_interface(self):
        """Sert l'interface web"""
        html = self._get_complete_html()
        self._send_html_response(html)
    
    def _get_complete_html(self):
        """Retourne le HTML complet de l'interface web"""
        return '''<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EbroStream - Gestion des Serveurs IPTV</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        }
        h1 { color: #3498db; font-size: 2.5rem; margin-bottom: 10px; }
        .subtitle { color: #95a5a6; font-size: 1.1rem; }
        .stats {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 20px 30px;
            text-align: center;
        }
        .stat-number { font-size: 2rem; font-weight: bold; color: #3498db; }
        .stat-label { color: #95a5a6; margin-top: 5px; }
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: center;
        }
        .tab {
            padding: 12px 30px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: bold;
        }
        .tab:hover { background: rgba(52,152,219,0.2); }
        .tab.active { background: #3498db; border-color: #3498db; }
        .form-container {
            display: none;
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 40px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .form-container.active { display: block; }
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-group { margin-bottom: 20px; }
        label {
            display: block;
            margin-bottom: 8px;
            color: #bdc3c7;
            font-weight: 500;
        }
        input, select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 8px;
            color: #fff;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #3498db;
            background: rgba(255,255,255,0.15);
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .checkbox-group input { width: auto; }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(52,152,219,0.4);
        }
        .btn-success {
            background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
            color: white;
        }
        .btn-warning {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
        }
        .btn-danger {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
        }
        .btn-small { padding: 6px 15px; font-size: 0.85rem; }
        .server-list { margin-top: 30px; }
        .server-card {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }
        .server-card:hover {
            background: rgba(255,255,255,0.08);
            transform: translateX(5px);
        }
        .server-info h3 {
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
        }
        .badge-stalker { background: rgba(52,152,219,0.2); color: #3498db; }
        .badge-xtream { background: rgba(46,204,113,0.2); color: #2ecc71; }
        .badge-active { background: rgba(46,204,113,0.3); color: #2ecc71; }
        .badge-inactive { background: rgba(149,165,166,0.2); color: #95a5a6; }
        .server-details { color: #95a5a6; font-size: 0.85rem; margin-top: 5px; }
        .server-actions { display: flex; gap: 10px; }
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: none;
        }
        .alert.success {
            background: rgba(46,204,113,0.2);
            border-left: 4px solid #2ecc71;
            color: #2ecc71;
            display: block;
        }
        .alert.error {
            background: rgba(231,76,60,0.2);
            border-left: 4px solid #e74c3c;
            color: #e74c3c;
            display: block;
        }
        .loading { text-align: center; padding: 40px; color: #95a5a6; }
        @media (max-width: 768px) {
            .server-card { flex-direction: column; align-items: flex-start; gap: 15px; }
            .server-actions { width: 100%; justify-content: flex-end; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📡 EbroStream - Gestion des Serveurs IPTV</h1>
            <p class="subtitle">Interface web pour la configuration des serveurs Stalker et Xtream Codes</p>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number" id="totalServers">0</div>
                <div class="stat-label">Total Serveurs</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="activeServers">0</div>
                <div class="stat-label">Serveurs Actifs</div>
            </div>
        </div>
        
        <div class="tabs">
            <div class="tab active" onclick="showTab('stalker')">📡 Serveur Stalker</div>
            <div class="tab" onclick="showTab('xtream')">⚡ Serveur Xtream Codes</div>
        </div>
        
        <div id="stalkerForm" class="form-container active">
            <h2 style="margin-bottom:20px;">➕ Ajouter un serveur Stalker</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Nom du serveur *</label>
                    <input type="text" id="stalkerName" placeholder="Ex: Mon Serveur IPTV">
                </div>
                <div class="form-group">
                    <label>URL du serveur *</label>
                    <input type="url" id="stalkerHost" placeholder="http://ip:port/c/">
                    <small style="color:#95a5a6;">Format: http://IP:PORT/c/</small>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Adresse MAC *</label>
                    <input type="text" id="stalkerMac" placeholder="00:1A:79:00:00:00">
                    <small style="color:#95a5a6;">Format: 00:1A:79:XX:XX:XX</small>
                </div>
                <div class="form-group checkbox-group">
                    <label><input type="checkbox" id="stalkerActive"> Marquer comme serveur actif</label>
                </div>
            </div>
            <button class="btn btn-primary" onclick="addStalkerServer()">➕ Ajouter le serveur Stalker</button>
        </div>
        
        <div id="xtreamForm" class="form-container">
            <h2 style="margin-bottom:20px;">➕ Ajouter un serveur Xtream Codes</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Nom du serveur *</label>
                    <input type="text" id="xtreamName" placeholder="Ex: Mon Serveur Xtream">
                </div>
                <div class="form-group">
                    <label>URL du serveur *</label>
                    <input type="text" id="xtreamHost" placeholder="http://ip:port">
                    <small style="color:#95a5a6;">Format: http://IP:PORT ou https://IP:PORT</small>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Nom d'utilisateur *</label>
                    <input type="text" id="xtreamUsername" placeholder="Votre username">
                </div>
                <div class="form-group">
                    <label>Mot de passe *</label>
                    <input type="password" id="xtreamPassword" placeholder="Votre password">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group checkbox-group">
                    <label><input type="checkbox" id="xtreamActive"> Marquer comme serveur actif</label>
                </div>
            </div>
            <button class="btn btn-success" onclick="addXtreamServer()">⚡ Ajouter le serveur Xtream</button>
        </div>
        
        <div id="alert" class="alert"></div>
        
        <div class="server-list">
            <h2 style="margin-bottom:20px;">📋 Liste des serveurs configurés</h2>
            <div id="serversList"><div class="loading">Chargement des serveurs...</div></div>
        </div>
    </div>
    
    <script>
        function showTab(tab) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.form-container').forEach(f => f.classList.remove('active'));
            if (tab === 'stalker') {
                document.querySelector('.tab:first-child').classList.add('active');
                document.getElementById('stalkerForm').classList.add('active');
            } else {
                document.querySelector('.tab:last-child').classList.add('active');
                document.getElementById('xtreamForm').classList.add('active');
            }
        }
        
        function showAlert(message, type) {
            const alert = document.getElementById('alert');
            alert.textContent = message;
            alert.className = 'alert ' + type;
            setTimeout(() => { alert.className = 'alert'; }, 5000);
        }
        
        async function loadServers() {
            try {
                const response = await fetch('/api/servers');
                const data = await response.json();
                if (data.success) {
                    displayServers(data.servers);
                    document.getElementById('totalServers').textContent = data.servers.length;
                    document.getElementById('activeServers').textContent = data.servers.filter(s => s.active).length;
                }
            } catch(error) {
                showAlert('Erreur: ' + error.message, 'error');
            }
        }
        
        function escapeHtml(text) { const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }
        
        function displayServers(servers) {
            const container = document.getElementById('serversList');
            if (!servers || servers.length === 0) {
                container.innerHTML = '<div class="loading">📭 Aucun serveur configuré. Utilisez le formulaire ci-dessus.</div>';
                return;
            }
            container.innerHTML = servers.map(server => `
                <div class="server-card">
                    <div class="server-info">
                        <h3>
                            ${server.type === 'stalker' ? '📡' : '⚡'} ${escapeHtml(server.name)}
                            <span class="badge ${server.type === 'stalker' ? 'badge-stalker' : 'badge-xtream'}">${server.type.toUpperCase()}</span>
                            <span class="badge ${server.active ? 'badge-active' : 'badge-inactive'}">${server.active ? '✅ ACTIF' : '⭕ INACTIF'}</span>
                        </h3>
                        <div class="server-details">
                            ${server.type === 'stalker' ? 
                                `🌐 URL: ${escapeHtml(server.host)}<br>🔑 MAC: ${escapeHtml(server.mac)}` :
                                `🌐 URL: ${escapeHtml(server.host)}<br>👤 User: ${escapeHtml(server.username)}`
                            }
                        </div>
                    </div>
                    <div class="server-actions">
                        <button class="btn btn-small btn-warning" onclick="toggleActive('${server.id}', ${!server.active})">${server.active ? '⏸️ Désactiver' : '▶️ Activer'}</button>
                        <button class="btn btn-small btn-danger" onclick="deleteServer('${server.id}')">🗑️ Supprimer</button>
                    </div>
                </div>
            `).join('');
        }
        
        async function addStalkerServer() {
            const name = document.getElementById('stalkerName').value.trim();
            const host = document.getElementById('stalkerHost').value.trim();
            const mac = document.getElementById('stalkerMac').value.trim();
            const active = document.getElementById('stalkerActive').checked;
            if (!name || !host || !mac) { showAlert('Veuillez remplir tous les champs', 'error'); return; }
            try {
                const response = await fetch('/api/servers/stalker', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, host, mac, active })
                });
                const data = await response.json();
                if (data.success) {
                    showAlert(data.message, 'success');
                    document.getElementById('stalkerName').value = '';
                    document.getElementById('stalkerHost').value = '';
                    document.getElementById('stalkerMac').value = '';
                    document.getElementById('stalkerActive').checked = false;
                    loadServers();
                } else { showAlert(data.errors ? data.errors.join(', ') : data.error, 'error'); }
            } catch(error) { showAlert('Erreur: ' + error.message, 'error'); }
        }
        
        async function addXtreamServer() {
            const name = document.getElementById('xtreamName').value.trim();
            const host = document.getElementById('xtreamHost').value.trim();
            const username = document.getElementById('xtreamUsername').value.trim();
            const password = document.getElementById('xtreamPassword').value.trim();
            const active = document.getElementById('xtreamActive').checked;
            if (!name || !host || !username || !password) { showAlert('Veuillez remplir tous les champs', 'error'); return; }
            try {
                const response = await fetch('/api/servers/xtream', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, host, username, password, active })
                });
                const data = await response.json();
                if (data.success) {
                    showAlert(data.message, 'success');
                    document.getElementById('xtreamName').value = '';
                    document.getElementById('xtreamHost').value = '';
                    document.getElementById('xtreamUsername').value = '';
                    document.getElementById('xtreamPassword').value = '';
                    document.getElementById('xtreamActive').checked = false;
                    loadServers();
                } else { showAlert(data.errors ? data.errors.join(', ') : data.error, 'error'); }
            } catch(error) { showAlert('Erreur: ' + error.message, 'error'); }
        }
        
        async function toggleActive(serverId, active) {
            try {
                const response = await fetch('/api/servers/' + serverId, {
                    method: 'PUT', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ active })
                });
                const data = await response.json();
                if (data.success) { showAlert(data.message, 'success'); loadServers(); }
                else { showAlert(data.error, 'error'); }
            } catch(error) { showAlert('Erreur: ' + error.message, 'error'); }
        }
        
        async function deleteServer(serverId) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer ce serveur ?')) return;
            try {
                const response = await fetch('/api/servers/' + serverId, { method: 'DELETE' });
                const data = await response.json();
                if (data.success) { showAlert(data.message, 'success'); loadServers(); }
                else { showAlert(data.error, 'error'); }
            } catch(error) { showAlert('Erreur: ' + error.message, 'error'); }
        }
        
        document.addEventListener('DOMContentLoaded', () => { loadServers(); });
    </script>
</body>
</html>'''
    
    def log_message(self, format, *args):
        pass


def run_server(port=DEFAULT_PORT):
    """Démarre le serveur web"""
    try:
        server = HTTPServer(('0.0.0.0', port), EbroStreamAPIHandler)
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            ip = socket.gethostbyname(socket.gethostname())
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                    EbroStream Web Server v4.2.1              ║
╠══════════════════════════════════════════════════════════════╣
║  🌐 Serveur démarré sur le port {port}                         ║
║  📁 Fichier config: {CONFIG_FILE}                           ║
║                                                              ║
║  📱 Accédez à l'interface via:                              ║
║     http://{ip}:{port}                                       ║
║                                                              ║
║  🛑 Ctrl+C pour arrêter                                      ║
╚══════════════════════════════════════════════════════════════╝
        """)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Arrêt du serveur web...")
    except Exception as e:
        print(f"❌ Erreur: {e}")


if __name__ == '__main__':
    port = DEFAULT_PORT
    if len(sys.argv) > 2 and sys.argv[1] == '--port':
        try:
            port = int(sys.argv[2])
        except ValueError:
            pass
    run_server(port)