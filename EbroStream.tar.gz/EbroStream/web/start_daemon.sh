#!/bin/sh
# Démarre le serveur web EbroStream

# Arrêter d'abord si déjà en cours d'exécution
if [ -f /tmp/ebrostream_web.pid ]; then
    kill -9 $(cat /tmp/ebrostream_web.pid) 2>/dev/null
    rm -f /tmp/ebrostream_web.pid
fi

# Démarrer le serveur web Python personnalisé
cd /usr/lib/enigma2/python/Plugins/Extensions/EbroStream
python3 web_server.py > /tmp/ebrostream_web.log 2>&1 &
echo $! > /tmp/ebrostream_web.pid

# Attendre un peu pour le démarrage
sleep 2

# Vérifier si le serveur est en cours d'exécution
if netstat -tln | grep -q ":8080 "; then
    echo "✅ Serveur web démarré sur le port 8181"
    exit 0
else
    echo "❌ Échec du démarrage du serveur web"
    echo "📋 Logs: /tmp/ebrostream_web.log"
    tail -20 /tmp/ebrostream_web.log
    exit 1
fi