# __init__.py
#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
EbroStream - Plugin IPTV pour Enigma2
Support Stalker Middleware et Xtream Codes API
"""

from .main import EbroStreamMain
from .live import LiveScreen
from .vod import VodScreen
from .series import SeriesScreen
from .servers_list import ServersListScreen
from .server_manager import ServerManager

from .settings_menu import SettingsMenuScreen
from .settings import SettingsScreen


__version__ = "4.0"
__author__ = "Saïd M.S"
__description__ = "IPTV Client for Stalker & Xtream"

__all__ = [
    'EbroStreamMain',
    'LiveScreen',
    'VodScreen',
    'SeriesScreen',
    'ServersListScreen',
    'ServerManager',
    'ConfigurationScreen',
    'SettingsMenuScreen',
    'SettingsScreen',
    'EditServerSimpleScreen',
]