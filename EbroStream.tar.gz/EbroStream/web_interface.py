#!/usr/bin/python
# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo, ConfigInteger
from threading import Thread
import subprocess
import os
import sys

# Ajouter le chemin pour les modules locaux
sys.path.append("/usr/lib/enigma2/python/Plugins/Extensions/EbroStream")

# Configuration
config.plugins.EbroStream_web = ConfigSubsection()
config.plugins.EbroStream_web.enabled = ConfigYesNo(default=False)
config.plugins.EbroStream_web.port = ConfigInteger(default=8080, limits=(1024, 65535))

def start_web_interface():
    """Démarre l'interface web"""
    port = config.plugins.EbroStream_web.port.value
    web_dir = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/web"
    
    if not os.path.exists(web_dir):
        os.makedirs(web_dir, exist_ok=True)
    
    # Vérifier si l'interface web existe
    api_file = os.path.join(web_dir, "api.py")
    if not os.path.exists(api_file):
        # Créer un fichier api.py minimal si nécessaire
        create_minimal_api(web_dir, port)
    
    # Démarrer le serveur en arrière-plan
    cmd = f"cd {web_dir} && python3 api.py --port {port}"
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Sauvegarder le PID
    pid_file = "/tmp/Ebrostream_web.pid"
    with open(pid_file, "w") as f:
        f.write(str(process.pid))
    
    return True

def create_minimal_api(web_dir, port):
    """Crée un fichier api.py minimal si nécessaire"""
    api_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import argparse

class UnionStreamHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        if self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = {
                "status": "running",
                "message": "Union Stream Web Interface",
                "version": "1.0"
            }
            self.wfile.write(json.dumps(response).encode())
        elif self.path == '/' or self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            html = '''
<!DOCTYPE html>
<html>
<head><title>Union Stream</title></head>
<body>
<h1>Union Stream Web Interface</h1>
<p>Interface de configuration en cours de développement</p>
</body>
</html>
'''
            self.wfile.write(html.encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        # Désactiver les logs
        pass

def run_server(port=8080):
    server = HTTPServer(('', port), UnionStreamHandler)
    print(f"Serveur démarré sur le port {port}")
    server.serve_forever()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8080)
    args = parser.parse_args()
    run_server(args.port)
'''
    
api_path = os.path.join(web_dir, "api.py")
with open(api_path, "w") as f:
        f.write(api_content)
    
    # Rendre le fichier exécutable
os.chmod(api_path, 0o755)

def stop_web_interface():
        """Arrête l'interface web"""
        pid_file = "/tmp/Ebrostream_web.pid"
    
if os.path.exists(pid_file):
        with open(pid_file, "r") as f:
            pid = f.read().strip()
        
        try:
            subprocess.Popen(f"kill {pid}", shell=True)
        except:
            pass
        
        os.remove(pid_file)
    
    # Tuer aussi les autres processus python
        subprocess.Popen("pkill -f 'api.py'", shell=True)
    
        return True

def setup(session, **kwargs):
    """Configuration de l'interface web"""
    from Screens.Setup import Setup
    from Components.config import getConfigListEntry
    from Screens.MessageBox import MessageBox
    
    class WebInterfaceSetup(Setup):
        def __init__(self, session):
            Setup.__init__(self, session, "web_interface")
            
            self.list = []
            self.list.append(getConfigListEntry(
                "Activer l'interface web",
                config.plugins.EbroStream_web.enabled
            ))
            self.list.append(getConfigListEntry(
                "Port HTTP",
                config.plugins.EbroStream_web.port
            ))
            
            self["config"].list = self.list
            self["config"].l.setList(self.list)
        
        def keySave(self):
            Setup.keySave(self)
            
            # Démarrer/Arrêter selon la configuration
            if config.plugins.EbroStream_web.enabled.value:
                try:
                    start_web_interface()
                    self.session.open(
                        MessageBox,
                        f"Interface web démarrée sur le port {config.plugins.EbroStream_web.port.value}\n\n"
                        f"Accès: http://votre-ip:{config.plugins.EbroStream_web.port.value}",
                        MessageBox.TYPE_INFO
                    )
                except Exception as e:
                    self.session.open(
                        MessageBox,
                        f"Erreur lors du démarrage: {str(e)}",
                        MessageBox.TYPE_ERROR
                    )
            else:
                stop_web_interface()
                self.session.open(
                    MessageBox,
                    "Interface web arrêtée",
                    MessageBox.TYPE_INFO
                )
    
    session.open(WebInterfaceSetup)

def autostart(reason, **kwargs):
    """Démarrage automatique au démarrage d'Enigma2"""
    if reason == 0:  # Startup
        if config.plugins.EbroStream_web.enabled.value:
            # Démarrer avec un délai pour laisser le système se charger
            import threading
            import time
            
            def delayed_start():
                time.sleep(30)  # 30 secondes après le démarrage
                if config.plugins.EbroStream_web.enabled.value:
                    try:
                        start_web_interface()
                    except:
                        pass
            
            thread = threading.Thread(target=delayed_start)
            thread.daemon = True
            thread.start()
    elif reason == 1:  # Shutdown
        # Arrêter proprement à l'extinction
        if config.plugins.EbroStream_web.enabled.value:
            stop_web_interface()

def Plugins(**kwargs):
    """Liste des plugins"""
    return [
        PluginDescriptor(
            name="EbroStream Web Interface by Said M.S",
            description="Interface web pour la configuration des serveurs",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="web.png",
            fnc=setup
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        )
    ]