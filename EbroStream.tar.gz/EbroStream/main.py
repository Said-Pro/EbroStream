#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Screens.MessageBox import MessageBox
from enigma import gRGB, eTimer
import os
import json
from datetime import datetime
import socket
import fcntl
import struct

class EbroStreamMain(Screen):
    """Écran principal du plugin EbroStream IPTV"""
    
    skin = """
    <screen name="EbroStreamMain"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder">

        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/menu.png"
                 zPosition="-1"/>

        <widget name="title" position="0,40" size="1920,105"
            zPosition="1" font="Bold;55"
            halign="center" valign="center"
            foregroundColor="#ebeb0c" transparent="1" />

        <widget name="btn_live_tv" position="350,630" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_vod" position="60,970" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_series" position="600,970" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_stalker" position="1200,360" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_xtream" position="1200,520" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_servers" position="1200,730" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_settings" position="1200,900" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="date_display" position="1000,160" size="450,80"
                font="Regular;28" halign="center" valign="center"
                foregroundColor="#ffffff" backgroundColor="#00000080" transparent="1"
                zPosition="2"/>

        <widget name="ip_display" position="1450,160" size="400,60"
                font="Regular;26" halign="center" valign="center"
                foregroundColor="#00ff00" backgroundColor="#00000080" transparent="1"
                zPosition="2"/>

        <widget name="key_red" position="1550,1000" size="200,60"
                font="Bold;40" foregroundColor="#ff0000" transparent="1" />
                   
        <widget name="server_status" position="200,570" size="660,50"
                font="Bold;27" halign="center" valign="center"
                foregroundColor="#e30202" transparent="1" />
                  
        <widget name="version_info" position="1400,40" size="660,30"
                font="Bold;35" halign="center" valign="center"
                foregroundColor="#f2e70a" transparent="1" />

    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"] = Label("")
        self["status_info"] = Label("")
        self["server_status"] = Label("")
        self["player_status"] = Label("")
        self["version_info"] = Label("V4.0")
        self["date_display"] = Label("")
        self["ip_display"] = Label("")

        self["btn_live_tv"] = Button("📺 LIVE TV")
        self["btn_vod"] = Button("🎬 VOD")
        self["btn_series"] = Button("📺 SERIES")
        self["btn_stalker"] = Button("📡 STALKER")
        self["btn_xtream"] = Button("🔗 XTREAM")
        self["btn_servers"] = Button("🌐 SERVERS")
        self["btn_settings"] = Button("⚙️ SETTINGS")
        self["key_red"] = Button("❌ Exit")

        self.menu_items = [
            {"name": "LIVE TV", "button": self["btn_live_tv"], 
             "action": self.open_live_tv, "requires_server": True},
            {"name": "VOD", "button": self["btn_vod"], 
             "action": self.open_vod, "requires_server": False},
            {"name": "SERIES", "button": self["btn_series"], 
             "action": self.open_series, "requires_server": False},
            {"name": "STALKER", "button": self["btn_stalker"], 
             "action": self.open_stalker_config, "requires_server": False},
            {"name": "XTREAM", "button": self["btn_xtream"], 
             "action": self.open_xtream_config, "requires_server": False},
            {"name": "SERVERS", "button": self["btn_servers"], 
             "action": self.open_servers, "requires_server": False},
            {"name": "SETTINGS", "button": self["btn_settings"], 
             "action": self.open_settings, "requires_server": False}
        ]
        
        self.current_index = 0
        self.total_items = len(self.menu_items)
        self.active_server = None
        self.player_available = self.check_player_availability()
        self.check_server_status()

        self.update_date_display()
        self.update_ip_display()
        
        self.date_timer = eTimer()
        self.date_timer.callback.append(self.update_date_display)
        self.date_timer.start(60000, True)

        self.ip_timer = eTimer()
        self.ip_timer.callback.append(self.update_ip_display)
        self.ip_timer.start(300000, True)

        self.onLayoutFinish.append(self.initFocus)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "red": self.exit,
                "cancel": self.exit,
            },
            -1
        )

    def open_stalker_config(self):
        """Ouvre la gestion des serveurs Stalker uniquement"""
        try:
            from .stalker_servers import StalkerServersScreen
            self.session.openWithCallback(self.on_servers_closed, StalkerServersScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir la configuration Stalker")
        except Exception as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error(f"Erreur: {str(e)[:50]}")

    def open_xtream_config(self):
        """Ouvre la gestion des serveurs Xtream uniquement"""
        try:
            from .xtream_servers import XtreamServersScreen
            self.session.openWithCallback(self.on_servers_closed, XtreamServersScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir la configuration Xtream")
        except Exception as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error(f"Erreur: {str(e)[:50]}")

    def open_servers(self):
        try:
            from .servers_list import ServersListScreen
            self.session.openWithCallback(self.on_servers_closed, ServersListScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir Servers")

    def on_servers_closed(self, result=None):
        print("[EbroStream] Retour de l'écran des serveurs - Rafraîchissement du statut")
        self.refresh_server_status()

    def open_live_tv(self):
        try:
            from .live import LiveScreen
            self.session.open(LiveScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir Live TV")
    
    def open_vod(self):
        try:
            from .vod import VodScreen
            self.session.open(VodScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir VOD")
    
    def open_series(self):
        try:
            from .series import SeriesScreen
            self.session.open(SeriesScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir Series")
    
    def open_settings(self):
        try:
            from .SettingsScreen import SettingsScreen
            config_file = "/etc/enigma2/EbroStream/config.json"
            config = {}
            try:
                if os.path.exists(config_file):
                    with open(config_file, 'r') as f:
                        config = json.load(f)
            except Exception as e:
                print(f"[EbroStream] Erreur chargement config: {e}")
            
            if "settings" not in config:
                config["settings"] = {}
            
            self.session.openWithCallback(self.on_settings_closed, SettingsScreen, config)
        except ImportError as e:
            print(f"[EbroStream] Error importing SettingsScreen: {e}")
            self.show_error("Impossible d'ouvrir Settings")

    def on_settings_closed(self, result=None):
        if result:
            config_file = "/etc/enigma2/EbroStream/config.json"
            try:
                os.makedirs(os.path.dirname(config_file), exist_ok=True)
                with open(config_file, 'w') as f:
                    json.dump(result, f, indent=2)
                print("[EbroStream] Configuration sauvegardée")
                self.show_message("✅ Paramètres sauvegardés", "INFO")
            except Exception as e:
                print(f"[EbroStream] Erreur sauvegarde config: {e}")

    def refresh_server_status(self):
        print("[EbroStream] Rafraîchissement du statut serveur demandé")
        self.check_server_status()
        self.update_server_status()

    def update_selection_colors(self):
        for i, item in enumerate(self.menu_items):
            if item["button"].instance:
                if i == self.current_index:
                    item["button"].instance.setForegroundColor(gRGB(255, 255, 0))
                    item["button"].instance.setBackgroundColor(gRGB(34, 34, 34))
                else:
                    item["button"].instance.setForegroundColor(gRGB(200, 200, 200))
                    item["button"].instance.setBackgroundColor(gRGB(34, 34, 34))

    def get_current_item(self):
        return self.menu_items[self.current_index]

    def get_ip_address(self, interface='eth0'):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            ip = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', interface.encode()[:15]))
            s.close()
            return socket.inet_ntoa(ip[20:24])
        except:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                ip = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', b'wlan0'))
                s.close()
                return socket.inet_ntoa(ip[20:24])
            except:
                try:
                    hostname = socket.gethostname()
                    ip = socket.gethostbyname(hostname)
                    if ip.startswith('127.'):
                        return "Non connecté"
                    return ip
                except:
                    return "Non connecté"

    def update_ip_display(self):
        ip = self.get_ip_address()
        if ip and ip != "Non connecté":
            self["ip_display"].setText(f"🌐 IP: {ip}")
        else:
            self["ip_display"].setText("🌐 IP: Non connecté")

    def update_date_display(self):
        now = datetime.now()
        date_complete = now.strftime("%A %d %B %Y  %H:%M:%S")
        self["date_display"].setText(f"📅 {date_complete}")

    def initFocus(self):
        print("[EbroStream] Initializing focus...")
        self.update_selection_colors()
        self.update_server_status()
        self.update_player_status()

    def check_player_availability(self):
        try:
            from Screens.InfoBar import InfoBar
            from enigma import eServiceReference
            return True
        except:
            return False

    def check_server_status(self):
        try:
            config_file = "/etc/enigma2/EbroStream/servers.json"
            
            if not os.path.exists(config_file):
                self.active_server = None
                self["status_info"].setText("⚠️ Pas de configuration")
                return
            
            with open(config_file, 'r') as f:
                data = json.load(f)
            
            if "servers" in data:
                servers = data.get("servers", [])
                for server in servers:
                    if server.get("active", False):
                        self.active_server = server
                        self["status_info"].setText("✅ Serveur actif")
                        return
            
            self.active_server = None
            self["status_info"].setText("⚠️ Aucun serveur actif")
            
        except Exception as e:
            print(f"[EbroStream] Server status error: {e}")
            self.active_server = None
            self["status_info"].setText("❌ Erreur configuration")

    def update_server_status(self):
        if self.active_server:
            server_name = self.active_server.get('name', 'Serveur inconnu')
            server_host = self.active_server.get('host', 'N/A')
            server_type = self.active_server.get('type', 'stalker')
        
            if len(server_host) > 40:
                server_host = server_host[:37] + "..."
        
            type_icon = "📡 " if server_type == "stalker" else "🔗 "
            status_text = f"{type_icon}{server_name} | {server_host}"
            self["server_status"].setText(status_text)
            if self["server_status"].instance:
                self["server_status"].instance.setForegroundColor(gRGB(227, 2, 2))
        else:
            self["server_status"].setText("⚠️ Configurez un serveur dans 'SERVERS'")
            if self["server_status"].instance:
                self["server_status"].instance.setForegroundColor(gRGB(227, 2, 2))

    def update_player_status(self):
        if self.player_available:
            self["player_status"].setText("✅ Player Enigma2 disponible")
        else:
            self["player_status"].setText("⚠️ Player non disponible")

    def keyUp(self):
        self.current_index = (self.current_index - 1) % self.total_items
        self.update_selection_colors()

    def keyDown(self):
        self.current_index = (self.current_index + 1) % self.total_items
        self.update_selection_colors()

    def keyLeft(self):
        self.current_index = (self.current_index - 1) % self.total_items
        self.update_selection_colors()

    def keyRight(self):
        self.current_index = (self.current_index + 1) % self.total_items
        self.update_selection_colors()

    def keyOk(self):
        current = self.get_current_item()
        print(f"[EbroStream] OK - Selected: {current['name']}")
        
        if current.get("requires_server", False) and not self.active_server:
            self.show_error("⚠️ Aucun serveur actif!\nVeuillez configurer un serveur dans SERVERS.")
            return
        
        current["action"]()

    def show_error(self, message):
        try:
            from Screens.MessageBox import MessageBox
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
        except:
            print(f"[EbroStream] Error: {message}")

    def show_message(self, message, msg_type="INFO"):
        try:
            from Screens.MessageBox import MessageBox
            typ = MessageBox.TYPE_INFO if msg_type == "INFO" else MessageBox.TYPE_ERROR
            self.session.open(MessageBox, message, typ, timeout=3)
        except:
            print(f"[EbroStream] Message: {message}")

    def exit(self):
        if self.date_timer:
            self.date_timer.stop()
        if self.ip_timer:
            self.ip_timer.stop()
        print("[EbroStream] Exiting...")
        super().close()
