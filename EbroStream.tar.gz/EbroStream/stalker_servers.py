#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
StalkerServersScreen - Affiche uniquement les serveurs de type STALKER
"""

from .servers_list import ServersListScreen

class StalkerServersScreen(ServersListScreen):
    """
    Écran des serveurs Stalker uniquement
    Filtre pour n'afficher que les serveurs de type 'stalker'
    """
    
    def __init__(self, session):
        # Initialiser avec le filtre 'stalker'
        self.filter_type = "stalker"
        ServersListScreen.__init__(self, session)
    
    def load_servers(self):
        """Charge uniquement les serveurs de type Stalker"""
        try:
            import json
            import os
            
            CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"
            
            if not os.path.exists(CONFIG_FILE):
                self.servers = []
                self["status"].setText("⚠️ Aucun serveur Stalker trouvé - Cliquez ADD")
                return

            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)

            # Lire tous les serveurs
            if isinstance(data, list):
                all_servers = data
            elif isinstance(data, dict) and "servers" in data:
                all_servers = data["servers"]
            else:
                all_servers = []

            # Filtrer UNIQUEMENT les serveurs Stalker
            self.servers = [s for s in all_servers if s.get('type') == 'stalker']

            # Normalisation des champs
            for server in self.servers:
                if 'active' not in server:
                    server['active'] = False
                if 'name' not in server:
                    server['name'] = 'Serveur inconnu'
                if 'host' not in server and 'url' in server:
                    server['host'] = server['url']
                if 'url' not in server and 'host' in server:
                    server['url'] = server['host']

            # Mettre à jour l'affichage
            if len(self.servers) == 0:
                self.selected_index = 0
                self.current_page = 0
                self["status"].setText("⚠️ Aucun serveur Stalker - Cliquez ADD")
            else:
                active_index = -1
                for i, s in enumerate(self.servers):
                    if s.get('active', False):
                        active_index = i
                        break
                
                if active_index >= 0:
                    self.selected_index = active_index
                    self.current_page = active_index // self.SERVERS_PER_PAGE
                else:
                    self.selected_index = 0
                    self.current_page = 0
                    
                active_count = sum(1 for s in self.servers if s.get('active', False))
                self["status"].setText(f"✅ {len(self.servers)} serveur(s) Stalker chargé(s) ({active_count} actif)")

        except Exception as e:
            print(f"[StalkerServers] Erreur chargement: {e}")
            self.servers = []
            self["status"].setText("❌ Erreur chargement serveurs Stalker")
    
    def update_page_info(self):
        """Met à jour les infos de page avec mention Stalker"""
        total_pages = self.get_total_pages()
        if total_pages > 1:
            self["page_info"].setText(f"📄 Page {self.current_page + 1} / {total_pages} ({len(self.servers)} serveur(s) Stalker)")
        else:
            self["page_info"].setText(f"📄 {len(self.servers)} serveur(s) Stalker")