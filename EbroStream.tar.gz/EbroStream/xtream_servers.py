#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
XtreamServersScreen - Affiche uniquement les serveurs de type XTREAM
"""

from .servers_list import ServersListScreen

class XtreamServersScreen(ServersListScreen):
    """
    Écran des serveurs Xtream uniquement
    Filtre pour n'afficher que les serveurs de type 'xtream'
    """
    
    def __init__(self, session):
        # Initialiser avec le filtre 'xtream'
        self.filter_type = "xtream"
        ServersListScreen.__init__(self, session)
    
    def load_servers(self):
        """Charge uniquement les serveurs de type Xtream"""
        try:
            import json
            import os
            
            CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"
            
            if not os.path.exists(CONFIG_FILE):
                self.servers = []
                self["status"].setText("⚠️ Aucun serveur Xtream trouvé - Cliquez ADD")
                return

            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)

            # Lire tous les serveurs
            if isinstance(data, list):
                all_servers = data
            elif isinstance(data, dict) and "servers" in data:
                all_servers = data["servers"]
            else:
                all_servers = []

            # Filtrer UNIQUEMENT les serveurs Xtream
            self.servers = [s for s in all_servers if s.get('type') == 'xtream']

            # Normalisation des champs
            for server in self.servers:
                if 'active' not in server:
                    server['active'] = False
                if 'name' not in server:
                    server['name'] = 'Serveur inconnu'
                if 'host' not in server and 'url' in server:
                    server['host'] = server['url']
                if 'url' not in server and 'host' in server:
                    server['url'] = server['host']
                # S'assurer que les champs Xtream existent
                if 'username' not in server:
                    server['username'] = server.get('user', '')
                if 'password' not in server:
                    server['password'] = ''

            # Mettre à jour l'affichage
            if len(self.servers) == 0:
                self.selected_index = 0
                self.current_page = 0
                self["status"].setText("⚠️ Aucun serveur Xtream - Cliquez ADD")
            else:
                active_index = -1
                for i, s in enumerate(self.servers):
                    if s.get('active', False):
                        active_index = i
                        break
                
                if active_index >= 0:
                    self.selected_index = active_index
                    self.current_page = active_index // self.SERVERS_PER_PAGE
                else:
                    self.selected_index = 0
                    self.current_page = 0
                    
                active_count = sum(1 for s in self.servers if s.get('active', False))
                self["status"].setText(f"✅ {len(self.servers)} serveur(s) Xtream chargé(s) ({active_count} actif)")

        except Exception as e:
            print(f"[XtreamServers] Erreur chargement: {e}")
            self.servers = []
            self["status"].setText("❌ Erreur chargement serveurs Xtream")
    
    def update_page_info(self):
        """Met à jour les infos de page avec mention Xtream"""
        total_pages = self.get_total_pages()
        if total_pages > 1:
            self["page_info"].setText(f"📄 Page {self.current_page + 1} / {total_pages} ({len(self.servers)} serveur(s) Xtream)")
        else:
            self["page_info"].setText(f"📄 {len(self.servers)} serveur(s) Xtream")