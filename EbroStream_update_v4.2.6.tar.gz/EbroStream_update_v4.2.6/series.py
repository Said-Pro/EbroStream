#!/usr/bin/python
# -*- coding: utf-8 -*-

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, eTimer
import json
import os
import urllib.request
import urllib.parse
import ssl
import re

class SeriesScreen(Screen):
    skin = """
    <screen name="SeriesScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">
        <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png" zPosition="-1"/>
        <widget name="title" position="0,60" size="1920,70" font="Bold;55" halign="center" valign="center" foregroundColor="#ffffff" transparent="1"/>
        <widget name="server_info" position="0,130" size="1920,35" font="Regular;26" halign="center" valign="center" foregroundColor="#aaaaaa" transparent="1"/>
        <widget name="category_label" position="40,175" size="430,45" font="Bold;28" halign="center" valign="center" foregroundColor="#f1f90b" transparent="1"/>
        <widget name="category_list" position="40,228" size="430,700" font="Regular;23" halign="left" valign="center" foregroundColorSelected="#ffffff" foregroundColor="#cccccc" backgroundColorSelected="#3a6ea5" backgroundColor="#572c6e" scrollbarMode="showOnDemand"/>
        <widget name="series_label" position="500,175" size="430,45" font="Bold;28" halign="center" valign="center" foregroundColor="#f1f90b" transparent="1"/>
        <widget name="series_list" position="500,228" size="430,700" font="Regular;23" halign="left" valign="center" foregroundColorSelected="#ffffff" foregroundColor="#cccccc" backgroundColorSelected="#3a6ea5" backgroundColor="#572c6e" scrollbarMode="showOnDemand"/>
        <widget name="seasons_label" position="960,175" size="430,45" font="Bold;28" halign="center" valign="center" foregroundColor="#f1f90b" transparent="1"/>
        <widget name="seasons_list" position="960,228" size="430,700" font="Regular;23" halign="left" valign="center" foregroundColorSelected="#ffffff" foregroundColor="#cccccc" backgroundColorSelected="#3a6ea5" backgroundColor="#572c6e" scrollbarMode="showOnDemand"/>
        <widget name="episodes_label" position="1420,175" size="460,45" font="Bold;28" halign="center" valign="center" foregroundColor="#f1f90b" transparent="1"/>
        <widget name="episodes_list" position="1420,228" size="460,700" font="Regular;23" halign="left" valign="center" foregroundColorSelected="#ffffff" foregroundColor="#cccccc" backgroundColorSelected="#3a6ea5" backgroundColor="#572c6e" scrollbarMode="showOnDemand"/>
        <widget name="status" position="40,945" size="1840,40" font="Regular;26" halign="center" valign="center" foregroundColor="#00ff00" transparent="1"/>
        <widget name="info" position="40,900" size="1840,40" font="Regular;24" halign="center" valign="center" foregroundColor="#ffff00" transparent="1"/>
        <widget name="key_red" position="40,1005" size="200,55" font="Regular;26" halign="center" valign="center" backgroundColor="#c0392b" foregroundColor="white" transparent="0"/>
        <widget name="key_green" position="280,1005" size="200,55" font="Regular;26" halign="center" valign="center" backgroundColor="#27ae60" foregroundColor="white" transparent="0"/>
        <widget name="key_yellow" position="520,1005" size="200,55" font="Regular;26" halign="center" valign="center" backgroundColor="#f39c12" foregroundColor="black" transparent="0"/>
        <widget name="key_blue" position="760,1005" size="200,55" font="Regular;26" halign="center" valign="center" backgroundColor="#2980b9" foregroundColor="white" transparent="0"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        
        self["title"] = Label("📺 Séries TV")
        self["server_info"] = Label("")
        self["category_label"] = Label("CATÉGORIES")
        self["series_label"] = Label("SÉRIES")
        self["seasons_label"] = Label("SAISONS")
        self["episodes_label"] = Label("ÉPISODES")
        self["status"] = Label("Chargement...")
        self["info"] = Label("")
        self["key_red"] = Label("🔴 Quitter")
        self["key_green"] = Label("✅ Lire")
        self["key_yellow"] = Label("◀ Page -")
        self["key_blue"] = Label("▶ Page +")
        
        self["category_list"] = MenuList([], enableWrapAround=True)
        self["series_list"] = MenuList([], enableWrapAround=True)
        self["seasons_list"] = MenuList([], enableWrapAround=True)
        self["episodes_list"] = MenuList([], enableWrapAround=True)
        
        self.categories = []
        self.series = []
        self.seasons = []
        self.episodes = []
        self.current_cat_id = None
        self.current_series_id = None
        self.current_series_name = ""
        self.current_season_id = None
        self.current_focus = "categories"
        
        self.active_server = None
        self.server_type = None
        self.portal = None
        self.mac = None
        self.token = None
        
        self.playing = False
        self.overlay_visible = True  # <-- هذا السطر كان مفقوداً
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hide_overlay)
        
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp, "down": self.keyDown,
                "left": self.keyLeft, "right": self.keyRight,
                "ok": self.keyOk, "cancel": self.exit, "red": self.exit,
                "green": self.keyGreen,
            }, -1
        )
        
        self.onLayoutFinish.append(self.start)
    
    def show_overlay(self):
        if not self.playing:
            return
        self.show()
        self.overlay_visible = True
        self.hide_timer.stop()
        self.hide_timer.start(5000, True)
    
    def hide_overlay(self):
        if self.playing and self.overlay_visible:
            self.hide()
            self.overlay_visible = False
    
    def start(self):
        self.load_active_server()
    
    def load_active_server(self):
        config_file = "/etc/enigma2/EbroStream/servers.json"
        if not os.path.exists(config_file):
            self["status"].setText("❌ Aucun serveur configuré")
            return
        
        try:
            with open(config_file, 'r') as f:
                data = json.load(f)
            
            for srv in data.get("servers", []):
                if srv.get("active", False):
                    self.active_server = srv
                    self.server_type = srv.get("type", "stalker")
                    name = srv.get("name", "Serveur")
                    self["server_info"].setText(f"🌐 {name}")
                    
                    if self.server_type == "stalker":
                        self.portal = srv["host"].rstrip("/") + "/server/load.php"
                        self.mac = srv.get("mac", "")
                        self.stalker_handshake()
                    return
            
            self["status"].setText("⚠️ Aucun serveur actif")
        except:
            self["status"].setText("❌ Erreur")
    
    def stalker_handshake(self):
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "stb", "action": "handshake", "token": "", "JsHttpRequest": "1-xml"
            })
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0",
                "Cookie": f"mac={self.mac}; stb_lang=en"
            })
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            self.token = data.get("js", {}).get("token")
            self.load_categories()
        except:
            self["status"].setText("❌ Connexion échouée")
    
    def get_headers(self):
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Cookie": f"mac={self.mac}; stb_lang=en"
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers
    
    def load_categories(self):
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "series", "action": "get_categories", "JsHttpRequest": "1-xml"
            })
            req = urllib.request.Request(url, headers=self.get_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            
            self.categories = [{"id": "all", "name": "📁 Toutes les séries"}]
            raw = data.get("js", [])
            if isinstance(raw, dict):
                raw = raw.get("data", [])
            for cat in raw:
                if isinstance(cat, dict):
                    self.categories.append({
                        "id": cat.get("id", ""),
                        "name": cat.get("title", cat.get("name", "Catégorie")),
                    })
            
            self.update_category_list()
            self["status"].setText(f"✅ {len(self.categories)-1} catégories")
        except:
            self["status"].setText("⚠️ Pas de catégories")
    
    def update_category_list(self):
        self["category_list"].setList([c["name"] for c in self.categories])
        self["category_list"].moveToIndex(0)
    
    def load_series(self, category_id):
        try:
            self["status"].setText("Chargement des séries...")
            
            params = {"type": "series", "action": "get_ordered_list", "JsHttpRequest": "1-xml"}
            if category_id and category_id != "all":
                params["category"] = str(category_id)
            
            url = self.portal + "?" + urllib.parse.urlencode(params)
            req = urllib.request.Request(url, headers=self.get_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=20)
            data = json.loads(resp.read().decode())
            
            js = data.get("js", {})
            self.series = js.get("data", [])
            
            self.display_series()
            self["status"].setText(f"✅ {len(self.series)} séries")
        except:
            self["status"].setText("❌ Erreur séries")
    
    def display_series(self):
        items = [f"📺 {s.get('name', 'Série')}" for s in self.series]
        self["series_list"].setList(items)
        if items:
            self["series_list"].moveToIndex(0)
        self.updateFocusVisual()
    
    def load_seasons(self, series_id, series_name):
        try:
            self["status"].setText("Chargement des saisons...")
            
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "series", "action": "get_ordered_list",
                "movie_id": str(series_id), "season_id": "0", "episode_id": "0",
                "JsHttpRequest": "1-xml"
            })
            
            req = urllib.request.Request(url, headers=self.get_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            
            js = data.get("js", {})
            seasons_raw = js.get("data", [])
            
            self.seasons = []
            for season in seasons_raw:
                if isinstance(season, dict):
                    sid = season.get("id", "")
                    num = sid.split(':')[1] if ':' in sid else "1"
                    name = season.get("name", f"Saison {num}")
                    self.seasons.append({
                        "id": str(sid),
                        "name": name,
                        "season_num": str(num)
                    })
            
            self.update_seasons_list()
            self["status"].setText(f"✅ {len(self.seasons)} saisons")
        except:
            self.seasons = []
            self.update_seasons_list()
    
    def update_seasons_list(self):
        if self.seasons:
            items = [s.get("name", "Saison") for s in self.seasons]
            self["seasons_list"].setList(items)
            if items:
                self["seasons_list"].moveToIndex(0)
            self["seasons_label"].setText(f"SAISONS ({len(self.seasons)})")
        else:
            self["seasons_list"].setList([])
            self["seasons_label"].setText("SAISONS")
        self.updateFocusVisual()
    
    def load_episodes(self, series_id, season_id, season_num):
        try:
            self["status"].setText("Chargement des épisodes...")
            
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "series", "action": "get_ordered_list",
                "movie_id": str(series_id), "season_id": str(season_id), "episode_id": "0",
                "JsHttpRequest": "1-xml"
            })
            
            req = urllib.request.Request(url, headers=self.get_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            
            js = data.get("js", {})
            episodes_data = js.get("data", [])
            
            self.episodes = []
            for ep_data in episodes_data:
                if isinstance(ep_data, dict):
                    series_list = ep_data.get("series", [])
                    for ep_num in series_list:
                        self.episodes.append({
                            "num": str(ep_num),
                            "name": f"Épisode {ep_num}",
                            "cmd": ep_data.get("cmd", "")
                        })
            
            self.update_episodes_list()
            self["status"].setText(f"✅ {len(self.episodes)} épisodes")
        except:
            self.episodes = []
            self.update_episodes_list()
    
    def update_episodes_list(self):
        if self.episodes:
            items = [f"{ep['num']}️⃣ {ep['name']}" for ep in self.episodes]
            self["episodes_list"].setList(items)
            if items:
                self["episodes_list"].moveToIndex(0)
            self["episodes_label"].setText(f"ÉPISODES ({len(self.episodes)})")
        else:
            self["episodes_list"].setList([])
            self["episodes_label"].setText("ÉPISODES")
        self.updateFocusVisual()
    
    def play_episode(self, episode):
        ep_num = episode.get("num", "?")
        ep_name = episode.get("name", f"Épisode {ep_num}")
        cmd = episode.get("cmd", "")
        
        if not cmd:
            self["status"].setText("❌ Pas de lien")
            return
        
        # Method 1: Try direct playback with cmd as URL
        if cmd.startswith(("http://", "https://")):
            try:
                sref = eServiceReference(4097, 0, cmd)
                sref.setName(f"{self.current_series_name} - {ep_name}")
                self.session.nav.playService(sref)
                self.playing = True
                self["status"].setText(f"▶️ {ep_name}")
                self.show_overlay()
                return
            except:
                pass
        
        # Method 2: Try create_link
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "vod", "action": "create_link",
                "cmd": cmd, "series": ep_num,
                "forced_storage": "", "disable_ad": "0",
                "download": "0", "force_ch_link_check": "0",
                "JsHttpRequest": "1-xml"
            })
            
            req = urllib.request.Request(url, headers=self.get_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            
            stream_url = data.get("js", {}).get("cmd", "")
            if stream_url:
                if stream_url.startswith("ffmpeg "):
                    stream_url = stream_url.replace("ffmpeg ", "").strip()
                
                if stream_url.startswith(("http://", "https://")):
                    sref = eServiceReference(4097, 0, stream_url)
                    sref.setName(f"{self.current_series_name} - {ep_name}")
                    self.session.nav.playService(sref)
                    self.playing = True
                    self["status"].setText(f"▶️ {ep_name}")
                    self.show_overlay()
                    return
        except:
            pass
        
        self["status"].setText("❌ Lecture impossible")
    
    def updateFocusVisual(self):
        try:
            colors = {"categories": gRGB(255,255,255), "series": gRGB(170,0,68),
                      "seasons": gRGB(170,0,68), "episodes": gRGB(170,0,68)}
            for focus in colors:
                color = colors[focus] if self.current_focus == focus else gRGB(170,0,68)
                self[f"{focus}_label"].instance.setForegroundColor(color)
        except:
            pass
    
    def keyUp(self):
        if self.playing:
            self.show_overlay()
            return
        if self.current_focus == "categories":
            self["category_list"].up()
        elif self.current_focus == "series":
            self["series_list"].up()
        elif self.current_focus == "seasons" and self.seasons:
            self["seasons_list"].up()
        elif self.current_focus == "episodes" and self.episodes:
            self["episodes_list"].up()
    
    def keyDown(self):
        if self.playing:
            self.show_overlay()
            return
        if self.current_focus == "categories":
            self["category_list"].down()
        elif self.current_focus == "series":
            self["series_list"].down()
        elif self.current_focus == "seasons" and self.seasons:
            self["seasons_list"].down()
        elif self.current_focus == "episodes" and self.episodes:
            self["episodes_list"].down()
    
    def keyLeft(self):
        if self.playing:
            self.show_overlay()
            return
        if self.current_focus == "series":
            self.current_focus = "categories"
        elif self.current_focus == "seasons":
            self.current_focus = "series"
        elif self.current_focus == "episodes":
            self.current_focus = "seasons"
        self.updateFocusVisual()
    
    def keyRight(self):
        if self.playing:
            self.show_overlay()
            return
        if self.current_focus == "categories" and self.series:
            self.current_focus = "series"
        elif self.current_focus == "series" and self.seasons:
            self.current_focus = "seasons"
        elif self.current_focus == "seasons" and self.episodes:
            self.current_focus = "episodes"
        self.updateFocusVisual()
    
    def keyOk(self):
        if self.playing:
            if not self.overlay_visible:
                self.show_overlay()
                return
        
        if self.current_focus == "categories":
            idx = self["category_list"].getSelectedIndex()
            if 0 <= idx < len(self.categories):
                self.current_cat_id = self.categories[idx]["id"]
                self.load_series(self.current_cat_id)
                self.current_focus = "series"
                self.updateFocusVisual()
        
        elif self.current_focus == "series":
            idx = self["series_list"].getSelectedIndex()
            if 0 <= idx < len(self.series):
                series = self.series[idx]
                self.current_series_id = series.get("id", "")
                self.current_series_name = series.get("name", "Série")
                if self.current_series_id:
                    self.load_seasons(self.current_series_id, self.current_series_name)
                    self.current_focus = "seasons"
                    self.updateFocusVisual()
        
        elif self.current_focus == "seasons":
            idx = self["seasons_list"].getSelectedIndex()
            if 0 <= idx < len(self.seasons):
                season = self.seasons[idx]
                self.current_season_id = season.get("id", "")
                self.load_episodes(self.current_series_id, self.current_season_id, season.get("season_num", "1"))
                self.current_focus = "episodes"
                self.updateFocusVisual()
        
        elif self.current_focus == "episodes":
            idx = self["episodes_list"].getSelectedIndex()
            if 0 <= idx < len(self.episodes):
                self.play_episode(self.episodes[idx])
    
    def keyGreen(self):
        if self.current_focus == "episodes":
            idx = self["episodes_list"].getSelectedIndex()
            if 0 <= idx < len(self.episodes):
                self.play_episode(self.episodes[idx])
    
    def exit(self):
        if self.playing:
            self.session.nav.stopService()
        self.close()
    
    def close(self):
        super().close()
