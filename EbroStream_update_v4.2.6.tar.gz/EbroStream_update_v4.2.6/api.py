#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EbroStream Web API Server - Version Complète
Gestion complète des serveurs Stalker et Xtream (CRUD complet)
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from collections import OrderedDict
import json
import os
import sys
import uuid
import re
import urllib.request
from urllib.parse import urlparse

# Configuration
CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"
DEFAULT_PORT = 8088
TICKER_URL = "https://raw.githubusercontent.com/Said-Pro/EbroStream/refs/heads/main/News/Ebro"

os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)


def reorder_server(server):
    ordered = OrderedDict()
    priority_fields = ['id', 'type', 'name', 'host', 'active', 'mac', 'username', 'password', 'created_at']
    for field in priority_fields:
        if field in server:
            ordered[field] = server[field]
    for key, value in server.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def get_ticker_text():
    try:
        req = urllib.request.Request(TICKER_URL, headers={'User-Agent': 'EbroStream/4.5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8')
            lines = content.split('\n')
            cleaned_items = []
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                if line.startswith('<<<') and line.endswith('>>>'):
                    continue
                if line.startswith('✅'):
                    line = line[1:].strip()
                if line in ['*', '-', '---', '***']:
                    continue
                if line:
                    cleaned_items.append(line)
            result = ' | '.join(cleaned_items)
            if result:
                return result
            else:
                return "Bienvenue sur EbroStream - Gestion IPTV - Serveurs disponibles"
    except Exception as e:
        return "Bienvenue sur EbroStream - Gestion IPTV - Serveur IPTV Stalker & Xtream"


class EbroStreamAPIHandler(BaseHTTPRequestHandler):
    
    def _send_json_response(self, code, data):
        response = json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(response)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(response)
    
    def _send_html_response(self, content):
        content_encoded = content.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(content_encoded)))
        self.end_headers()
        self.wfile.write(content_encoded)
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path == '/api/servers':
            self._get_servers()
        elif path == '/api/active':
            self._get_active_server()
        elif path == '/api/ticker':
            self._get_ticker()
        elif path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._get_server_by_id(server_id)
        elif path == '/' or path == '' or path == '/index.html':
            self._serve_web_interface()
        else:
            self._send_json_response(404, {"error": f"Route non trouvée: {path}"})
    
    def _get_ticker(self):
        text = get_ticker_text()
        self._send_json_response(200, {"success": True, "text": text})
    
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(post_data) if post_data else {}
        except json.JSONDecodeError:
            data = {}
        
        if path == '/api/servers':
            self._add_server(data)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    def do_PUT(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        put_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(put_data) if put_data else {}
        except json.JSONDecodeError:
            data = {}
        
        if path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._update_server(server_id, data)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._delete_server(server_id)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    # ==================== MÉTHODES PRINCIPALES ====================
    
    def _normalize_host(self, host):
        if not host:
            return ""
        host = host.strip().lower()
        host = re.sub(r'^https?://', '', host)
        host = re.sub(r'/c/?$', '', host)
        host = re.sub(r':80$', '', host)
        host = re.sub(r':443$', '', host)
        return host
    
    def _is_host_duplicate(self, servers, new_host, exclude_id=None):
        normalized_new = self._normalize_host(new_host)
        for server in servers:
            if exclude_id and server.get('id') == exclude_id:
                continue
            existing_host = server.get('host', '')
            if self._normalize_host(existing_host) == normalized_new:
                return True
            existing_url = server.get('url', '')
            if self._normalize_host(existing_url) == normalized_new:
                return True
        return False
    
    def _load_servers(self):
        if not os.path.exists(CONFIG_FILE):
            self._save_servers([])
            return []
        
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
                if isinstance(data, dict) and 'servers' in data:
                    servers = data['servers']
                elif isinstance(data, list):
                    servers = data
                else:
                    servers = []
                
                modified = False
                for i, s in enumerate(servers):
                    if 'id' not in s:
                        s['id'] = str(uuid.uuid4())[:8]
                        modified = True
                    if 'type' not in s:
                        s['type'] = 'stalker'
                    if 'active' not in s:
                        s['active'] = False
                    
                    servers[i] = reorder_server(s)
                    
                    if 'url' in servers[i] and 'host' in servers[i]:
                        if servers[i]['url'] == servers[i]['host']:
                            del servers[i]['url']
                            modified = True
                
                if modified:
                    self._save_servers(servers)
                    print("[WebAPI] IDs ajoutés aux serveurs manquants")
                
                return servers
                    
        except (json.JSONDecodeError, IOError) as e:
            print(f"[WebAPI] Erreur chargement: {e}")
            return []
    
    def _save_servers(self, servers):
        try:
            reordered_servers = [reorder_server(s) for s in servers]
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            data = {
                "version": "2.0",
                "servers": reordered_servers,
                "total": len(reordered_servers)
            }
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"[WebAPI] Sauvegarde réussie: {len(servers)} serveurs")
            return True
        except IOError as e:
            print(f"[WebAPI] Erreur sauvegarde: {e}")
            return False
    
    def _get_servers(self):
        try:
            servers = self._load_servers()
            safe = []
            for server in servers:
                s = server.copy()
                if 'password' in s:
                    s['password'] = '********'
                safe.append(s)
            self._send_json_response(200, {
                "success": True,
                "servers": safe,
                "total": len(safe)
            })
        except Exception as e:
            print(f"[WebAPI] Erreur _get_servers: {e}")
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_server_by_id(self, server_id):
        try:
            servers = self._load_servers()
            server = next((s for s in servers if s.get('id') == server_id), None)
            if not server:
                self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
                return
            self._send_json_response(200, {"success": True, "server": server})
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_active_server(self):
        try:
            servers = self._load_servers()
            active = next((s for s in servers if s.get('active', False)), None)
            if active and 'password' in active:
                active = active.copy()
                active['password'] = '********'
            self._send_json_response(200, {"success": True, "server": active})
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _add_server(self, data):
        errors = []
        server_type = data.get('type', 'stalker')
        
        name = data.get('name', '').strip()
        if not name:
            errors.append("Le nom du serveur est requis")
        
        host = data.get('host', '').strip()
        if not host:
            errors.append("L'URL du serveur est requise")
        
        if server_type == 'stalker':
            mac = data.get('mac', '').strip()
            if not mac:
                errors.append("L'adresse MAC est requise")
        else:
            username = data.get('username', '').strip()
            password = data.get('password', '').strip()
            if not username:
                errors.append("Le nom d'utilisateur est requis")
            if not password:
                errors.append("Le mot de passe est requis")
        
        if errors:
            self._send_json_response(400, {"success": False, "errors": errors})
            return
        
        servers = self._load_servers()
        if self._is_host_duplicate(servers, host):
            self._send_json_response(400, {
                "success": False, 
                "error": f"Un serveur avec l'URL '{host}' existe déjà"
            })
            return
        
        server = OrderedDict()
        server["id"] = str(uuid.uuid4())[:8]
        server["type"] = server_type
        server["name"] = name
        server["host"] = host.rstrip('/')
        
        if server_type == 'stalker':
            server["mac"] = self._format_mac(mac)
        else:
            server["username"] = username
            server["password"] = password
        
        server["active"] = data.get('active', False)
        
        if server['active']:
            self._deactivate_all_servers()
        
        servers.append(server)
        
        if self._save_servers(servers):
            response_server = server.copy()
            if 'password' in response_server:
                response_server['password'] = '********'
            self._send_json_response(201, {
                "success": True,
                "message": f"Serveur '{name}' ajouté avec succès",
                "server": response_server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _update_server(self, server_id, data):
        servers = self._load_servers()
        
        server_index = None
        for i, s in enumerate(servers):
            if s.get('id') == server_id:
                server_index = i
                break
        
        if server_index is None:
            self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
            return
        
        server = servers[server_index]
        old_active = server.get('active', False)
        
        new_host = data.get('host', '').strip()
        if new_host and self._is_host_duplicate(servers, new_host, exclude_id=server_id):
            self._send_json_response(400, {
                "success": False, 
                "error": f"Un serveur avec l'URL '{new_host}' existe déjà"
            })
            return
        
        if 'name' in data and data['name']:
            server['name'] = data['name'].strip()
        if 'host' in data and data['host']:
            server['host'] = data['host'].strip().rstrip('/')
            if 'url' in server:
                del server['url']
        if 'active' in data:
            server['active'] = data['active']
        
        if server['type'] == 'stalker':
            if 'mac' in data and data['mac']:
                server['mac'] = self._format_mac(data['mac'])
        else:
            if 'username' in data and data['username']:
                server['username'] = data['username'].strip()
            if 'password' in data and data['password'] and data['password'] != '********':
                server['password'] = data['password'].strip()
        
        if server.get('active', False) and not old_active:
            for i, s in enumerate(servers):
                if i != server_index:
                    s['active'] = False
        
        if self._save_servers(servers):
            response_server = server.copy()
            if 'password' in response_server:
                response_server['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "message": "Serveur mis à jour avec succès",
                "server": response_server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _delete_server(self, server_id):
        servers = self._load_servers()
        
        server_to_delete = next((s for s in servers if s.get('id') == server_id), None)
        
        if not server_to_delete:
            self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
            return
        
        server_name = server_to_delete.get('name', 'Inconnu')
        new_servers = [s for s in servers if s.get('id') != server_id]
        
        if self._save_servers(new_servers):
            self._send_json_response(200, {
                "success": True,
                "message": f"Serveur '{server_name}' supprimé avec succès"
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la suppression"})
    
    def _deactivate_all_servers(self):
        servers = self._load_servers()
        for server in servers:
            server['active'] = False
        self._save_servers(servers)
    
    def _format_mac(self, mac):
        if not mac:
            return "00:00:00:00:00:00"
        mac = mac.strip().upper()
        mac = ''.join(c for c in mac if c.isalnum())
        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]
        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])
    
    # ==================== INTERFACE WEB AVEC TICKER ====================
    
    def _serve_web_interface(self):
        html = '''<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EbroStream - Gestion IPTV</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            min-height: 100vh;
            color: #fff;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes ticker {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }
        .ticker-container {
            background: linear-gradient(90deg, #1a1a2e, #16213e, #1a1a2e);
            border-radius: 40px;
            margin-bottom: 20px;
            padding: 12px 20px;
            border: 1px solid rgba(96,239,255,0.3);
            box-shadow: 0 0 15px rgba(96,239,255,0.1);
            overflow: hidden;
            position: relative;
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .ticker-wrapper {
            overflow: hidden;
            white-space: nowrap;
            position: relative;
        }
        .ticker-content {
            display: inline-block;
            animation: ticker 25s linear infinite;
            white-space: nowrap;
            font-size: 0.95rem;
            font-weight: 500;
            color: #60efff;
            letter-spacing: 0.5px;
        }
        .ticker-content i {
            margin: 0 8px;
            color: #f1c40f;
        }
        .ticker-content:hover {
            animation-play-state: paused;
        }
        .ticker-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: #60efff;
            color: #1a1a2e;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
            font-size: 0.8rem;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 30px; animation: fadeInUp 0.6s ease-out; }
        .header { text-align: center; margin-bottom: 20px; }
        .logo {
            display: inline-flex;
            align-items: center;
            gap: 15px;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            padding: 15px 35px;
            border-radius: 60px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .logo i { font-size: 2.5rem; color: #60efff; }
        .logo h1 { font-size: 1.8rem; font-weight: 700; background: linear-gradient(135deg, #fff 0%, #60efff 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 40px;
            cursor: pointer;
        }
        .stat-card {
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .stat-card:hover { transform: translateY(-5px); background: rgba(255,255,255,0.15); border-color: #60efff; }
        .stat-card.active { border-color: #60efff; background: rgba(96,239,255,0.15); box-shadow: 0 0 20px rgba(96,239,255,0.3); }
        .stat-icon { font-size: 2.5rem; color: #60efff; margin-bottom: 15px; }
        .stat-value { font-size: 2.5rem; font-weight: 800; margin-bottom: 5px; }
        .stat-label { font-size: 0.9rem; color: #a8b2d1; text-transform: uppercase; letter-spacing: 1px; }
        .tabs {
            display: flex;
            gap: 10px;
            background: rgba(0,0,0,0.3);
            padding: 8px;
            border-radius: 60px;
            width: fit-content;
            margin-bottom: 30px;
        }
        .tab {
            padding: 12px 30px;
            border-radius: 50px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .tab i { font-size: 1.1rem; }
        .tab.active { background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; box-shadow: 0 4px 15px rgba(59,130,246,0.4); }
        .tab:not(.active):hover { background: rgba(255,255,255,0.1); }
        .form-panel {
            display: none;
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .form-panel.active { display: block; animation: fadeInUp 0.4s ease-out; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; margin-bottom: 25px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        .form-group label { font-weight: 600; font-size: 0.85rem; color: #cbd5e1; letter-spacing: 0.5px; }
        .form-group label i { margin-right: 8px; color: #60efff; }
        .form-group input, .form-group select {
            padding: 12px 16px;
            background: rgba(0,0,0,0.4);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 12px;
            color: white;
            font-size: 0.95rem;
            transition: all 0.3s;
        }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #60efff; background: rgba(0,0,0,0.6); }
        .checkbox-group { flex-direction: row; align-items: center; gap: 10px; }
        .checkbox-group input { width: 20px; height: 20px; cursor: pointer; }
        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }
        .btn-primary { background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; }
        .btn-primary:hover { transform: scale(1.02); box-shadow: 0 5px 20px rgba(59,130,246,0.4); }
        .btn-success { background: linear-gradient(135deg, #10b981, #059669); color: white; }
        .btn-danger { background: linear-gradient(135deg, #ef4444, #dc2626); color: white; }
        .btn-warning { background: linear-gradient(135deg, #f59e0b, #d97706); color: white; }
        .btn-sm { padding: 6px 16px; font-size: 0.8rem; }
        .servers-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .servers-header h3 { font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }
        .filter-badge { background: rgba(96,239,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; color: #60efff; }
        .server-list { 
            display: grid; 
            grid-template-columns: repeat(3, 1fr); 
            gap: 15px; 
            max-height: 600px; 
            overflow-y: auto; 
            padding: 10px; 
        }
        .server-list::-webkit-scrollbar { width: 6px; }
        .server-list::-webkit-scrollbar-track { background: rgba(255,255,255,0.1); border-radius: 10px; }
        .server-list::-webkit-scrollbar-thumb { background: #60efff; border-radius: 10px; }
        .server-item {
            background: rgba(0,0,0,0.35);
            border-radius: 16px;
            padding: 18px 22px;
            border-left: 4px solid;
            transition: all 0.3s;
            animation: fadeInUp 0.3s ease-out;
        }
        .server-item:hover { background: rgba(0,0,0,0.5); transform: translateY(-3px); }
        .server-item.stalker { border-left-color: #3b82f6; }
        .server-item.xtream { border-left-color: #10b981; }
        .server-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; }
        .server-title { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
        .server-name { font-size: 1rem; font-weight: 700; }
        .badge { padding: 4px 12px; border-radius: 20px; font-size: 0.65rem; font-weight: 600; }
        .badge-stalker { background: rgba(59,130,246,0.2); color: #60a5fa; }
        .badge-xtream { background: rgba(16,185,129,0.2); color: #34d399; }
        .badge-active { background: rgba(16,185,129,0.25); color: #34d399; }
        .badge-inactive { background: rgba(156,163,175,0.2); color: #9ca3af; }
        .server-details { font-size: 0.7rem; color: #9ca3af; margin: 10px 0; line-height: 1.4; display: flex; flex-wrap: wrap; gap: 10px; }
        .server-actions { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(8px);
            align-items: center;
            justify-content: center;
            z-index: 1000;
            animation: fadeInUp 0.3s ease;
        }
        .modal.open { display: flex; }
        .modal-content {
            background: linear-gradient(135deg, #1e1b4b, #1a1a3e);
            border-radius: 32px;
            width: 90%;
            max-width: 550px;
            max-height: 90vh;
            overflow-y: auto;
            padding: 30px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .modal-close { background: none; border: none; color: #cbd5e1; font-size: 1.5rem; cursor: pointer; transition: all 0.3s; }
        .modal-close:hover { color: #ef4444; transform: rotate(90deg); }
        .modal-footer { display: flex; justify-content: flex-end; gap: 15px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); }
        .toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            min-width: 300px;
            background: #1e293b;
            border-left: 4px solid;
            padding: 15px 20px;
            border-radius: 12px;
            color: white;
            z-index: 1100;
            opacity: 0;
            transition: all 0.3s;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .toast.show { opacity: 1; }
        .toast.success { border-left-color: #10b981; }
        .toast.error { border-left-color: #ef4444; }
        .loading { text-align: center; padding: 40px; color: #94a3b8; }
        .empty-state { text-align: center; padding: 60px; color: #94a3b8; }
        hr { border-color: rgba(255,255,255,0.08); margin: 20px 0; }
        @media (max-width: 1200px) {
            .server-list { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 768px) {
            .container { padding: 15px; }
            .form-grid { grid-template-columns: 1fr; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .server-list { grid-template-columns: 1fr; }
            .ticker-content { font-size: 0.8rem; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">
            <i class="fas fa-tv"></i>
            <h1>EbroStream</h1>
        </div>
        <p style="color: #a8b2d1;">Gestion avancée des serveurs IPTV</p>
    </div>
    
    <div class="ticker-container">
        <div class="ticker-icon">
            <i class="fas fa-bullhorn"></i>
        </div>
        <div class="ticker-wrapper" style="margin-left: 40px;">
            <div class="ticker-content" id="tickerText">
                <i class="fas fa-spinner fa-spin"></i> Chargement...
            </div>
        </div>
    </div>
    
    <!-- Stats Cards as Buttons -->
    <div class="stats-grid">
        <div class="stat-card" data-filter="all" id="filterAll">
            <div class="stat-icon"><i class="fas fa-server"></i></div>
            <div class="stat-value" id="totalCount">0</div>
            <div class="stat-label">SERVEURS</div>
        </div>
        <div class="stat-card" data-filter="active" id="filterActive">
            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            <div class="stat-value" id="activeCount">0</div>
            <div class="stat-label">ACTIFS</div>
        </div>
        <div class="stat-card" data-filter="stalker" id="filterStalker">
            <div class="stat-icon"><i class="fas fa-satellite-dish"></i></div>
            <div class="stat-value" id="stalkerCount">0</div>
            <div class="stat-label">STALKER</div>
        </div>
        <div class="stat-card" data-filter="xtream" id="filterXtream">
            <div class="stat-icon"><i class="fas fa-code-branch"></i></div>
            <div class="stat-value" id="xtreamCount">0</div>
            <div class="stat-label">XTREAM</div>
        </div>
    </div>
    
    <div class="tabs">
        <div class="tab active" data-tab="stalker"><i class="fas fa-satellite-dish"></i> Stalker Portal</div>
        <div class="tab" data-tab="xtream"><i class="fas fa-bolt"></i> Xtream Codes</div>
    </div>
    
    <div id="panelStalker" class="form-panel active">
        <h3 style="margin-bottom:20px"><i class="fas fa-plus-circle"></i> Ajouter un serveur Stalker</h3>
        <div class="form-grid">
            <div class="form-group"><label><i class="fas fa-tag"></i> Nom du serveur</label><input type="text" id="stalkerName" placeholder="Ex: Mon serveur principal"></div>
            <div class="form-group"><label><i class="fas fa-link"></i> URL du serveur</label><input type="text" id="stalkerHost" placeholder="http://ip:port/c/"></div>
            <div class="form-group"><label><i class="fas fa-fingerprint"></i> Adresse MAC</label><input type="text" id="stalkerMac" placeholder="00:1A:79:00:00:00"></div>
            <div class="form-group checkbox-group"><input type="checkbox" id="stalkerActive"><label><i class="fas fa-power-off"></i> Activer ce serveur</label></div>
        </div>
        <button class="btn btn-primary" onclick="addServer('stalker')"><i class="fas fa-plus"></i> Ajouter le serveur</button>
    </div>
    
    <div id="panelXtream" class="form-panel">
        <h3 style="margin-bottom:20px"><i class="fas fa-plus-circle"></i> Ajouter un serveur Xtream</h3>
        <div class="form-grid">
            <div class="form-group"><label><i class="fas fa-tag"></i> Nom du serveur</label><input type="text" id="xtreamName" placeholder="Ex: Serveur Xtream"></div>
            <div class="form-group"><label><i class="fas fa-link"></i> URL du serveur</label><input type="text" id="xtreamHost" placeholder="http://ip:port"></div>
            <div class="form-group"><label><i class="fas fa-user"></i> Nom d'utilisateur</label><input type="text" id="xtreamUser" placeholder="username"></div>
            <div class="form-group"><label><i class="fas fa-lock"></i> Mot de passe</label><input type="password" id="xtreamPass" placeholder="password"></div>
            <div class="form-group checkbox-group"><input type="checkbox" id="xtreamActive"><label><i class="fas fa-power-off"></i> Activer ce serveur</label></div>
        </div>
        <button class="btn btn-success" onclick="addServer('xtream')"><i class="fas fa-plus"></i> Ajouter le serveur</button>
    </div>
    
    <hr>
    
    <div class="servers-header">
        <h3><i class="fas fa-list"></i> Liste des serveurs <span id="filterBadge" class="filter-badge"></span></h3>
    </div>
    <div id="serversList" class="server-list"><div class="loading"><i class="fas fa-spinner"></i> Chargement...</div></div>
</div>

<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h3><i class="fas fa-edit"></i> Modifier le serveur</h3><button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button></div>
        <input type="hidden" id="editId"><input type="hidden" id="editType">
        <div class="form-group"><label><i class="fas fa-tag"></i> Nom</label><input type="text" id="editName"></div>
        <div class="form-group"><label><i class="fas fa-link"></i> URL</label><input type="text" id="editHost"></div>
        <div id="editMacGroup" class="form-group"><label><i class="fas fa-fingerprint"></i> MAC</label><input type="text" id="editMac"></div>
        <div id="editXtreamGroup" style="display:none;">
            <div class="form-group"><label><i class="fas fa-user"></i> Username</label><input type="text" id="editUsername"></div>
            <div class="form-group"><label><i class="fas fa-lock"></i> Mot de passe</label><input type="password" id="editPassword" placeholder="Laisser vide = inchangé"></div>
        </div>
        <div class="form-group checkbox-group"><input type="checkbox" id="editActive"><label><i class="fas fa-power-off"></i> Serveur actif</label></div>
        <div class="modal-footer">
            <button class="btn" style="background:#334155;" onclick="closeModal()"><i class="fas fa-times"></i> Annuler</button>
            <button class="btn btn-primary" onclick="saveEdit()"><i class="fas fa-save"></i> Enregistrer</button>
        </div>
    </div>
</div>

<div id="toast" class="toast"></div>

<script>
    let currentType = 'stalker';
    let allServers = [];
    let currentFilter = 'all';
    
    async function loadTicker() {
        try {
            const res = await fetch('/api/ticker');
            const data = await res.json();
            if(data.success && data.text) {
                const tickerDiv = document.getElementById('tickerText');
                let text = data.text;
                let repeatedText = '';
                for(let i = 0; i < 20; i++) {
                    repeatedText += `<i class="fas fa-star"></i> ${text} <i class="fas fa-star"></i> `;
                }
                tickerDiv.innerHTML = repeatedText;
            }
        } catch(e) {
            document.getElementById('tickerText').innerHTML = '<i class="fas fa-info-circle"></i> EbroStream IPTV';
        }
    }
    
    function setActiveFilter(filter) {
        currentFilter = filter;
        document.querySelectorAll('.stat-card').forEach(card => {
            card.classList.remove('active');
        });
        if (filter === 'all') document.getElementById('filterAll').classList.add('active');
        if (filter === 'active') document.getElementById('filterActive').classList.add('active');
        if (filter === 'stalker') document.getElementById('filterStalker').classList.add('active');
        if (filter === 'xtream') document.getElementById('filterXtream').classList.add('active');
        
        const badge = document.getElementById('filterBadge');
        if (filter === 'all') badge.innerHTML = '';
        if (filter === 'active') badge.innerHTML = '🔍 Filtre: Serveurs actifs';
        if (filter === 'stalker') badge.innerHTML = '🔍 Filtre: Serveurs Stalker';
        if (filter === 'xtream') badge.innerHTML = '🔍 Filtre: Serveurs Xtream';
        
        renderServersWithFilter();
    }
    
    function getFilteredServers() {
        if (currentFilter === 'all') return allServers;
        if (currentFilter === 'active') return allServers.filter(s => s.active === true);
        if (currentFilter === 'stalker') return allServers.filter(s => s.type === 'stalker');
        if (currentFilter === 'xtream') return allServers.filter(s => s.type === 'xtream');
        return allServers;
    }
    
    function renderServersWithFilter() {
        const filtered = getFilteredServers();
        renderServers(filtered);
    }
    
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const type = tab.dataset.tab;
            document.getElementById('panelStalker').classList.toggle('active', type === 'stalker');
            document.getElementById('panelXtream').classList.toggle('active', type === 'xtream');
        });
    });
    
    document.getElementById('filterAll').addEventListener('click', () => setActiveFilter('all'));
    document.getElementById('filterActive').addEventListener('click', () => setActiveFilter('active'));
    document.getElementById('filterStalker').addEventListener('click', () => setActiveFilter('stalker'));
    document.getElementById('filterXtream').addEventListener('click', () => setActiveFilter('xtream'));
    
    function showToast(msg, type = 'success') {
        const toast = document.getElementById('toast');
        toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${msg}`;
        toast.className = `toast ${type} show`;
        setTimeout(() => toast.classList.remove('show'), 3000);
    }
    
    async function loadStats() {
        try {
            const res = await fetch('/api/servers');
            const data = await res.json();
            if(data.success) {
                document.getElementById('totalCount').innerText = data.servers.length;
                document.getElementById('activeCount').innerText = data.servers.filter(s => s.active).length;
                document.getElementById('stalkerCount').innerText = data.servers.filter(s => s.type === 'stalker').length;
                document.getElementById('xtreamCount').innerText = data.servers.filter(s => s.type === 'xtream').length;
            }
        } catch(e) {}
    }
    
    async function loadServers() {
        try {
            const res = await fetch('/api/servers');
            const data = await res.json();
            if(data.success) {
                allServers = data.servers;
                renderServersWithFilter();
                loadStats();
                document.getElementById('filterAll').classList.add('active');
            } else throw new Error(data.error);
        } catch(e) {
            document.getElementById('serversList').innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Erreur de chargement</p></div>';
        }
    }
    
    function escapeHtml(str) { if(!str) return ''; return str.replace(/[&<>]/g, function(m){ if(m==='&') return '&amp;'; if(m==='<') return '&lt;'; if(m==='>') return '&gt;'; return m;}); }
    
    function renderServers(servers) {
        const container = document.getElementById('serversList');
        if(!servers.length) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-database"></i><p>Aucun serveur configuré</p></div>';
            return;
        }
        container.innerHTML = servers.map(s => {
            const isStalker = s.type === 'stalker';
            const activeBadge = s.active ? '<span class="badge badge-active"><i class="fas fa-check-circle"></i> ACTIF</span>' : '<span class="badge badge-inactive"><i class="fas fa-circle"></i> INACTIF</span>';
            let details = '';
            if(isStalker) {
                details = `<span><i class="fas fa-link"></i> ${escapeHtml(s.host)}</span><span><i class="fas fa-fingerprint"></i> MAC: ${escapeHtml(s.mac)}</span>`;
            } else {
                details = `<span><i class="fas fa-link"></i> ${escapeHtml(s.host)}</span><span><i class="fas fa-user"></i> User: ${escapeHtml(s.username)}</span>`;
            }
            return `<div class="server-item ${isStalker ? 'stalker' : 'xtream'}">
                <div class="server-header"><div class="server-title"><span class="server-name">${escapeHtml(s.name)}</span><span class="badge ${isStalker ? 'badge-stalker' : 'badge-xtream'}"><i class="fas ${isStalker ? 'fa-satellite-dish' : 'fa-bolt'}"></i> ${s.type.toUpperCase()}</span>${activeBadge}</div></div>
                <div class="server-details">${details}</div>
                <div class="server-actions">
                    <button class="btn btn-sm ${s.active ? 'btn-warning' : 'btn-success'}" onclick="toggleActive('${s.id}', ${!s.active})"><i class="fas ${s.active ? 'fa-pause' : 'fa-play'}"></i> ${s.active ? 'Désactiver' : 'Activer'}</button>
                    <button class="btn btn-sm btn-primary" onclick="openEditModal('${s.id}')"><i class="fas fa-edit"></i> Modifier</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteServer('${s.id}', '${escapeHtml(s.name).replace(/'/g, "\\'")}')"><i class="fas fa-trash"></i> Supprimer</button>
                </div>
            </div>`;
        }).join('');
    }
    
    async function addServer(type) {
        let payload = { type };
        if(type === 'stalker') {
            payload.name = document.getElementById('stalkerName').value.trim();
            payload.host = document.getElementById('stalkerHost').value.trim();
            payload.mac = document.getElementById('stalkerMac').value.trim();
            payload.active = document.getElementById('stalkerActive').checked;
            if(!payload.name || !payload.host || !payload.mac) { showToast('Tous les champs sont obligatoires', 'error'); return; }
        } else {
            payload.name = document.getElementById('xtreamName').value.trim();
            payload.host = document.getElementById('xtreamHost').value.trim();
            payload.username = document.getElementById('xtreamUser').value.trim();
            payload.password = document.getElementById('xtreamPass').value.trim();
            payload.active = document.getElementById('xtreamActive').checked;
            if(!payload.name || !payload.host || !payload.username || !payload.password) { showToast('Tous les champs sont obligatoires', 'error'); return; }
        }
        try {
            const res = await fetch('/api/servers', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            if(data.success) {
                showToast(data.message, 'success');
                if(type==='stalker') { document.getElementById('stalkerName').value=''; document.getElementById('stalkerHost').value=''; document.getElementById('stalkerMac').value='00:1A:79:00:00:00'; document.getElementById('stalkerActive').checked=false; }
                else { document.getElementById('xtreamName').value=''; document.getElementById('xtreamHost').value=''; document.getElementById('xtreamUser').value=''; document.getElementById('xtreamPass').value=''; document.getElementById('xtreamActive').checked=false; }
                loadServers();
            } else showToast(data.errors ? data.errors.join(', ') : 'Erreur', 'error');
        } catch(e) { showToast('Erreur réseau', 'error'); }
    }
    
    async function toggleActive(id, active) {
        try {
            const res = await fetch(`/api/servers/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ active }) });
            const data = await res.json();
            if(data.success) { showToast(data.message, 'success'); loadServers(); }
            else showToast(data.error || 'Erreur', 'error');
        } catch(e) { showToast('Erreur', 'error'); }
    }
    
    async function deleteServer(id, name) {
        if(!confirm(`⚠️ Supprimer définitivement "${name}" ?`)) return;
        try {
            const res = await fetch(`/api/servers/${id}`, { method:'DELETE' });
            const data = await res.json();
            if(data.success) { showToast(data.message, 'success'); loadServers(); }
            else showToast(data.error, 'error');
        } catch(e) { showToast('Erreur', 'error'); }
    }
    
    async function openEditModal(id) {
        try {
            const res = await fetch(`/api/servers/${id}`);
            const data = await res.json();
            if(!data.success || !data.server) throw new Error();
            const s = data.server;
            document.getElementById('editId').value = s.id;
            document.getElementById('editType').value = s.type;
            document.getElementById('editName').value = s.name || '';
            document.getElementById('editHost').value = s.host || '';
            document.getElementById('editActive').checked = s.active || false;
            const isStalker = s.type === 'stalker';
            document.getElementById('editMacGroup').style.display = isStalker ? 'block' : 'none';
            document.getElementById('editXtreamGroup').style.display = isStalker ? 'none' : 'block';
            if(isStalker) document.getElementById('editMac').value = s.mac || '';
            else { document.getElementById('editUsername').value = s.username || ''; document.getElementById('editPassword').value = ''; }
            document.getElementById('editModal').classList.add('open');
        } catch(e) { showToast('Erreur chargement', 'error'); }
    }
    
    async function saveEdit() {
        const id = document.getElementById('editId').value;
        const type = document.getElementById('editType').value;
        const payload = { name: document.getElementById('editName').value.trim(), host: document.getElementById('editHost').value.trim(), active: document.getElementById('editActive').checked };
        if(!payload.name || !payload.host) { showToast('Nom et URL requis', 'error'); return; }
        if(type === 'stalker') { const mac = document.getElementById('editMac').value.trim(); if(mac) payload.mac = mac; }
        else { const user = document.getElementById('editUsername').value.trim(); const pass = document.getElementById('editPassword').value.trim(); if(user) payload.username = user; if(pass) payload.password = pass; }
        try {
            const res = await fetch(`/api/servers/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            if(data.success) { showToast(data.message, 'success'); closeModal(); loadServers(); }
            else showToast(data.error || 'Erreur', 'error');
        } catch(e) { showToast('Erreur', 'error'); }
    }
    
    function closeModal() { document.getElementById('editModal').classList.remove('open'); }
    window.onclick = function(e) { if(e.target === document.getElementById('editModal')) closeModal(); };
    
    document.addEventListener('DOMContentLoaded', () => {
        loadServers();
        loadTicker();
        setInterval(loadTicker, 30000);
    });
</script>
</body>
</html>'''
        self._send_html_response(html)
    
    def log_message(self, format, *args):
        pass


def run_server(port=DEFAULT_PORT):
    try:
        server = HTTPServer(('0.0.0.0', port), EbroStreamAPIHandler)
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            ip = "127.0.0.1"
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                    EbroStream Web Server                     ║
╠══════════════════════════════════════════════════════════════╣
║  🌐 Serveur démarré sur le port {port}                         ║
║  📁 Fichier config: {CONFIG_FILE}                           ║
║  📊 Affichage en grille 3 colonnes                           ║
║  🔍 Filtres interactifs sur les statistiques                 ║
║                                                              ║
║  📱 Accédez à l'interface via:                              ║
║     http://{ip}:{port}                                       ║
║                                                              ║
║  🛑 Ctrl+C pour arrêter                                      ║
╚══════════════════════════════════════════════════════════════╝
        """)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Arrêt du serveur web...")
    except Exception as e:
        print(f"❌ Erreur: {e}")


if __name__ == '__main__':
    port = DEFAULT_PORT
    if len(sys.argv) > 2 and sys.argv[1] == '--port':
        try:
            port = int(sys.argv[2])
        except ValueError:
            pass
    run_server(port)
