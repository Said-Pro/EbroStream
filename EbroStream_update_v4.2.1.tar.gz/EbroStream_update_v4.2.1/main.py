#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Screens.MessageBox import MessageBox
from enigma import gRGB, eTimer
import os
import json
import urllib.request
import urllib.parse
import ssl
import zipfile
import tarfile  # AJOUTÉ pour support tar.gz
import tempfile
import shutil
import subprocess
from datetime import datetime

class EbroStreamMain(Screen):
    """Écran principal du plugin EbroStream IPTV"""
    
    skin = """
    <screen name="EbroStreamMain"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder">

        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/menu.png"
                 zPosition="-1"/>

        <widget name="title" position="0,40" size="1920,105"
            zPosition="1" font="Bold;55"
            halign="center" valign="center"
            foregroundColor="#ebeb0c" transparent="1" />

        <widget name="btn_live_tv" position="350,630" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_vod" position="60,970" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_series" position="600,970" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_stalker" position="1200,360" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_xtream" position="1200,520" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_servers" position="1200,730" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <widget name="btn_settings" position="1200,900" size="350,80"
                font="Bold;40" halign="center" valign="center" transparent="1" />

        <!-- NOUVEAU BOUTON BLEU UPDATE -->
        <widget name="btn_update" position="1050,1000" size="200,60"
                font="Bold;40" foregroundColor="#0a0fa6" transparent="1" />

        <widget name="date_display" position="1050,160" size="280,80"
                font="Regular;28" halign="center" valign="center"
                foregroundColor="#ffffff" backgroundColor="#00000080" transparent="1"
                zPosition="2"/>

        <widget name="ip_display" position="1450,160" size="400,60"
                font="Regular;26" halign="center" valign="center"
                foregroundColor="#00ff00" backgroundColor="#00000080" transparent="1"
                zPosition="2"/>

        <widget name="key_red" position="1550,1000" size="200,60"
                font="Bold;40" foregroundColor="#ff0000" transparent="1" />
                   
        <widget name="server_status" position="200,570" size="660,50"
                font="Bold;27" halign="center" valign="center"
                foregroundColor="#e30202" transparent="1" />
                  
        <widget name="version_info" position="1400,40" size="660,30"
                font="Bold;35" halign="center" valign="center"
                foregroundColor="#f2e70a" transparent="1" />

        <!-- Message de mise à jour -->
        <widget name="update_status" position="60,720" size="350,40"
                font="Regular;22" halign="center" valign="center"
                foregroundColor="#00ff00" backgroundColor="#00000080"
                transparent="1" zPosition="2" />

    </screen>
    """

    # Configuration GitHub
    GITHUB_USER = "Said-Pro"
    REPO_NAME = "EbroStream"
    VERSION_URL = "https://raw.githubusercontent.com/Said-Pro/EbroStream/refs/heads/main/version.json"

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"] = Label("")
        self["status_info"] = Label("")
        self["server_status"] = Label("")
        self["player_status"] = Label("")
        self["version_info"] = Label("V4.0")
        self["date_display"] = Label("")
        self["ip_display"] = Label("")
        self["update_status"] = Label("")

        self["btn_live_tv"] = Button("📺 LIVE TV")
        self["btn_vod"] = Button("🎬 VOD")
        self["btn_series"] = Button("📺 SERIES")
        self["btn_stalker"] = Button("📡 STALKER")
        self["btn_xtream"] = Button("🔗 XTREAM")
        self["btn_servers"] = Button("🌐 SERVERS")
        self["btn_settings"] = Button("⚙️ SETTINGS")
        self["btn_update"] = Button("🔵 UPDATE")
        self["key_red"] = Button("❌ Exit")

        # Liste des menus
        self.menu_items = [
            {"name": "UPDATE", "button": self["btn_update"], 
             "action": self.check_and_update, "requires_server": False},
            {"name": "LIVE TV", "button": self["btn_live_tv"], 
             "action": self.open_live_tv, "requires_server": True},
            {"name": "VOD", "button": self["btn_vod"], 
             "action": self.open_vod, "requires_server": False},
            {"name": "SERIES", "button": self["btn_series"], 
             "action": self.open_series, "requires_server": False},
            {"name": "STALKER", "button": self["btn_stalker"], 
             "action": self.open_stalker_config, "requires_server": False},
            {"name": "XTREAM", "button": self["btn_xtream"], 
             "action": self.open_xtream_config, "requires_server": False},
            {"name": "SERVERS", "button": self["btn_servers"], 
             "action": self.open_servers, "requires_server": False},
            {"name": "SETTINGS", "button": self["btn_settings"], 
             "action": self.open_settings, "requires_server": False}
        ]
        
        self.current_index = 0
        self.total_items = len(self.menu_items)
        self.active_server = None
        
        # Version actuelle
        self.current_version = self.get_current_version()
        self["version_info"].setText(f"V{self.current_version}")
        
        # Timer pour vérifier les mises à jour en arrière-plan
        self.update_check_timer = eTimer()
        self.update_check_timer.callback.append(self.background_update_check)
        self.update_check_timer.start(3600000)  # 1 heure
        
        self.update_date_display()
        self.update_ip_display()
        self.check_server_status()

        self.date_timer = eTimer()
        self.date_timer.callback.append(self.update_date_display)
        self.date_timer.start(60000, True)

        self.ip_timer = eTimer()
        self.ip_timer.callback.append(self.update_ip_display)
        self.ip_timer.start(300000, True)

        self.onLayoutFinish.append(self.initFocus)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "red": self.exit,
                "cancel": self.exit,
                "blue": self.check_and_update,
            },
            -1
        )
    
    def get_current_version(self):
        """Lit la version depuis le fichier local"""
        version_file = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/version.json"
        try:
            if os.path.exists(version_file):
                with open(version_file, 'r') as f:
                    data = json.load(f)
                    return data.get('version', '4.0')
        except:
            pass
        return "4.0"
    
    def save_version_info(self, version_data):
        """Sauvegarde les infos de version localement"""
        version_file = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/version.json"
        try:
            with open(version_file, 'w') as f:
                json.dump(version_data, f, indent=2)
            self.current_version = version_data.get('version', '4.0')
            self["version_info"].setText(f"V{self.current_version}")
        except Exception as e:
            print(f"[Update] Erreur sauvegarde version: {e}")
    
    def background_update_check(self):
        """Vérifie les mises à jour en arrière-plan"""
        try:
            latest = self.fetch_remote_version()
            if latest and latest.get('version', '0') > self.current_version:
                self["update_status"].setText("🔵 Nouvelle version disponible! Appuyez sur BLEU")
                self["btn_update"].setText("🔵 UPDATE (NEW!)")
        except:
            pass
    
    def fetch_remote_version(self):
        """Télécharge version.json depuis GitHub"""
        try:
            context = ssl._create_unverified_context()
            req = urllib.request.Request(
                self.VERSION_URL,
                headers={'User-Agent': 'EbroStream/4.0'}
            )
            response = urllib.request.urlopen(req, context=context, timeout=10)
            data = json.loads(response.read().decode('utf-8'))
            return data
        except Exception as e:
            print(f"[Update] Erreur téléchargement version: {e}")
            return None
    
    def check_and_update(self):
        """Vérifie et effectue la mise à jour"""
        self["update_status"].setText("🔍 Vérification des mises à jour...")
        
        # Télécharger les infos de version
        remote = self.fetch_remote_version()
        
        if not remote:
            self.session.open(MessageBox, 
                "❌ Impossible de vérifier les mises à jour.\n"
                "Vérifiez votre connexion internet.",
                MessageBox.TYPE_ERROR, timeout=5)
            self["update_status"].setText("")
            return
        
        remote_version = remote.get('version', '0')
        changelog = remote.get('changelog', [])
        download_url = remote.get('download_url', '')
        
        # Comparer les versions
        def vtuple(v):
            return tuple(map(int, v.split('.')))
        
        try:
            is_newer = vtuple(remote_version) > vtuple(self.current_version)
        except:
            is_newer = remote_version != self.current_version
        
        if not is_newer:
            self.session.open(MessageBox,
                f"✅ Plugin à jour !\n\n"
                f"Version actuelle: {self.current_version}\n"
                f"Dernière version: {remote_version}",
                MessageBox.TYPE_INFO, timeout=3)
            self["update_status"].setText("✅ Plugin à jour")
            return
        
        # Construire le message de confirmation
        changelog_text = "\n".join([f"  • {c}" for c in changelog[:10]])
        message = f"📢 Nouvelle version disponible !\n\n"
        message += f"Version actuelle: {self.current_version}\n"
        message += f"Nouvelle version: {remote_version}\n\n"
        message += f"📝 Nouveautés:\n{changelog_text}\n\n"
        message += f"Voulez-vous mettre à jour maintenant ?"
        
        self.session.openWithCallback(
            lambda result: self.confirm_update(result, download_url, remote),
            MessageBox,
            message,
            MessageBox.TYPE_YESNO
        )
    
    def confirm_update(self, result, download_url, remote_info):
        """Confirme et lance la mise à jour"""
        if not result:
            self["update_status"].setText("")
            return
        
        self["update_status"].setText("📥 Téléchargement de la mise à jour...")
        
        # Démarrer la mise à jour dans un thread séparé
        import threading
        thread = threading.Thread(target=self.perform_update, args=(download_url, remote_info))
        thread.daemon = True
        thread.start()
    
    def perform_update(self, download_url, remote_info):
        """Effectue la mise à jour (téléchargement + installation)"""
        try:
            self.update_status_callback("📥 Téléchargement... 0%")
            
            context = ssl._create_unverified_context()
            req = urllib.request.Request(
                download_url,
                headers={'User-Agent': 'EbroStream/4.0'}
            )
            
            response = urllib.request.urlopen(req, context=context, timeout=30)
            total_size = int(response.headers.get('Content-Length', 0))
            
            # Créer un dossier temporaire
            temp_dir = tempfile.mkdtemp()
            
            # Détecter le type d'archive
            is_tar_gz = download_url.endswith('.tar.gz')
            is_zip = download_url.endswith('.zip')
            
            if is_tar_gz:
                archive_path = os.path.join(temp_dir, 'update.tar.gz')
            else:
                archive_path = os.path.join(temp_dir, 'update.zip')
            
            # Télécharger avec progression
            downloaded = 0
            with open(archive_path, 'wb') as f:
                while True:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = int(downloaded * 100 / total_size)
                        self.update_status_callback(f"📥 Téléchargement... {percent}%")
            
            # 2. Extraire l'archive
            self.update_status_callback("📦 Installation...")
            
            plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
            
            # Sauvegarder la configuration AVANT l'extraction
            config_backup = self.backup_config()
            
            if is_tar_gz:
                # Extraction TAR.GZ
                with tarfile.open(archive_path, 'r:gz') as tar:
                    # Obtenir le nom du dossier racine dans l'archive
                    members = tar.getmembers()
                    root_folder = None
                    
                    # Trouver le dossier racine commun
                    if members:
                        first = members[0].path.split('/')[0]
                        if all(m.path.startswith(first + '/') or m.path == first for m in members):
                            root_folder = first
                    
                    if root_folder:
                        # Extraire avec strip du dossier racine
                        for member in members:
                            # Enlever le dossier racine du chemin
                            rel_path = '/'.join(member.path.split('/')[1:]) if '/' in member.path else ''
                            if not rel_path:
                                continue
                            
                            dest_path = os.path.join(plugin_path, rel_path)
                            if member.isdir():
                                os.makedirs(dest_path, exist_ok=True)
                            else:
                                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                                with tar.extractfile(member) as source:
                                    with open(dest_path, 'wb') as target:
                                        shutil.copyfileobj(source, target)
                    else:
                        # Extraction simple
                        tar.extractall(plugin_path)
            else:
                # Extraction ZIP
                with zipfile.ZipFile(archive_path, 'r') as zf:
                    for name in zf.namelist():
                        # Nettoyer le chemin
                        if '/' in name:
                            rel_path = '/'.join(name.split('/')[1:])
                        else:
                            rel_path = name
                        
                        if not rel_path or rel_path.endswith('/'):
                            continue
                        
                        dest_path = os.path.join(plugin_path, rel_path)
                        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                        
                        with zf.open(name) as source:
                            with open(dest_path, 'wb') as target:
                                shutil.copyfileobj(source, target)
            
            # Restaurer la configuration
            self.restore_config(config_backup)
            
            # 3. Sauvegarder la nouvelle version localement
            local_version = {
                'version': remote_info.get('version', '4.2.0'),
                'updated_at': datetime.now().isoformat(),
                'changelog': remote_info.get('changelog', [])
            }
            self.save_version_info(local_version)
            
            # 4. Nettoyer
            shutil.rmtree(temp_dir, ignore_errors=True)
            
            # 5. Afficher le message de succès
            self.update_status_callback("✅ Mise à jour terminée! Redémarrage...")
            
            # 6. Redémarrer Enigma2
            self.restart_enigma2()
            
        except Exception as e:
            print(f"[Update] Erreur: {e}")
            import traceback
            traceback.print_exc()
            self.update_status_callback(f"❌ Erreur: {str(e)[:50]}")
            self.session.open(MessageBox,
                f"❌ Erreur lors de la mise à jour:\n{str(e)}",
                MessageBox.TYPE_ERROR)
    
    def update_status_callback(self, message):
        """Met à jour le message de statut (appelé depuis thread)"""
        from enigma import eTimer
        timer = eTimer()
        timer.callback.append(lambda: self._set_status(message))
        timer.start(0, True)
    
    def _set_status(self, message):
        """Définit le message de statut"""
        self["update_status"].setText(message)
    
    def backup_config(self):
        """Sauvegarde les fichiers de configuration"""
        plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
        backup_dir = tempfile.mkdtemp()
        
        config_files = ['servers.json', 'config.json', 'settings.json', 'version.json']
        backed_up = []
        
        for filename in config_files:
            src = os.path.join(plugin_path, filename)
            if os.path.exists(src):
                dst = os.path.join(backup_dir, filename)
                shutil.copy2(src, dst)
                backed_up.append(filename)
        
        return {'dir': backup_dir, 'files': backed_up}
    
    def restore_config(self, backup_info):
        """Restaure les fichiers de configuration"""
        if not backup_info:
            return
        
        plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
        backup_dir = backup_info.get('dir')
        
        if not backup_dir or not os.path.exists(backup_dir):
            return
        
        for filename in backup_info.get('files', []):
            src = os.path.join(backup_dir, filename)
            dst = os.path.join(plugin_path, filename)
            if os.path.exists(src):
                shutil.copy2(src, dst)
        
        shutil.rmtree(backup_dir, ignore_errors=True)
    
    def restart_enigma2(self):
        """Redémarre Enigma2"""
        # Créer un script de redémarrage
        script = """#!/bin/sh
sleep 2
killall -9 enigma2
"""
        script_path = "/tmp/restart_ebrostream.sh"
        with open(script_path, 'w') as f:
            f.write(script)
        os.chmod(script_path, 0o755)
        
        subprocess.Popen(['sh', script_path])
    
    # ==================== MÉTHODES EXISTANTES ====================
    
    def open_stalker_config(self):
        try:
            from .stalker_servers import StalkerServersScreen
            self.session.openWithCallback(self.on_servers_closed, StalkerServersScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir la configuration Stalker")
    
    def open_xtream_config(self):
        try:
            from .xtream_servers import XtreamServersScreen
            self.session.openWithCallback(self.on_servers_closed, XtreamServersScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir la configuration Xtream")
    
    def open_servers(self):
        try:
            from .servers_list import ServersListScreen
            self.session.openWithCallback(self.on_servers_closed, ServersListScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir Servers")
    
    def on_servers_closed(self, result=None):
        self.check_server_status()
    
    def open_live_tv(self):
        try:
            from .live import LiveScreen
            self.session.open(LiveScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir Live TV")
    
    def open_vod(self):
        try:
            from .vod import VodScreen
            self.session.open(VodScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir VOD")
    
    def open_series(self):
        try:
            from .series import SeriesScreen
            self.session.open(SeriesScreen)
        except ImportError as e:
            print(f"[EbroStream] Error: {e}")
            self.show_error("Impossible d'ouvrir Series")
    
    def open_settings(self):
        try:
            from .SettingsScreen import SettingsScreen
            config_file = "/etc/enigma2/EbroStream/config.json"
            config = {}
            try:
                if os.path.exists(config_file):
                    with open(config_file, 'r') as f:
                        config = json.load(f)
            except Exception as e:
                print(f"[EbroStream] Erreur chargement config: {e}")
            
            if "settings" not in config:
                config["settings"] = {}
            
            self.session.openWithCallback(self.on_settings_closed, SettingsScreen, config)
        except ImportError as e:
            print(f"[EbroStream] Error importing SettingsScreen: {e}")
            self.show_error("Impossible d'ouvrir Settings")
    
    def on_settings_closed(self, result=None):
        if result:
            config_file = "/etc/enigma2/EbroStream/config.json"
            try:
                os.makedirs(os.path.dirname(config_file), exist_ok=True)
                with open(config_file, 'w') as f:
                    json.dump(result, f, indent=2)
                print("[EbroStream] Configuration sauvegardée")
                self.show_message("✅ Paramètres sauvegardés", "INFO")
            except Exception as e:
                print(f"[EbroStream] Erreur sauvegarde config: {e}")
    
    def check_server_status(self):
        try:
            config_file = "/etc/enigma2/EbroStream/servers.json"
            
            if not os.path.exists(config_file):
                self.active_server = None
                self["status_info"].setText("⚠️ Pas de configuration")
                return
            
            with open(config_file, 'r') as f:
                data = json.load(f)
            
            if "servers" in data:
                servers = data.get("servers", [])
                for server in servers:
                    if server.get("active", False):
                        self.active_server = server
                        self["status_info"].setText("✅ Serveur actif")
                        return
            
            self.active_server = None
            self["status_info"].setText("⚠️ Aucun serveur actif")
            
        except Exception as e:
            print(f"[EbroStream] Server status error: {e}")
            self.active_server = None
            self["status_info"].setText("❌ Erreur configuration")
    
    def get_ip_address(self, interface='eth0'):
        try:
            import socket
            import fcntl
            import struct
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            ip = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', interface.encode()[:15]))
            s.close()
            return socket.inet_ntoa(ip[20:24])
        except:
            try:
                import socket
                hostname = socket.gethostname()
                ip = socket.gethostbyname(hostname)
                if ip.startswith('127.'):
                    return "Non connecté"
                return ip
            except:
                return "Non connecté"
    
    def update_ip_display(self):
        ip = self.get_ip_address()
        if ip and ip != "Non connecté":
            self["ip_display"].setText(f"🌐 IP: {ip}")
        else:
            self["ip_display"].setText("🌐 IP: Non connecté")
    
    def update_date_display(self):
        now = datetime.now()
        date_complete = now.strftime("%A %d %B %Y  %H:%M:%S")
        self["date_display"].setText(f"📅 {date_complete}")
    
    def initFocus(self):
        self.update_selection_colors()
    
    def update_selection_colors(self):
        for i, item in enumerate(self.menu_items):
            if item["button"].instance:
                if i == self.current_index:
                    item["button"].instance.setForegroundColor(gRGB(255, 255, 0))
                    item["button"].instance.setBackgroundColor(gRGB(34, 34, 34))
                else:
                    item["button"].instance.setForegroundColor(gRGB(200, 200, 200))
                    item["button"].instance.setBackgroundColor(gRGB(34, 34, 34))
    
    def get_current_item(self):
        return self.menu_items[self.current_index]
    
    def keyUp(self):
        self.current_index = (self.current_index - 1) % self.total_items
        self.update_selection_colors()
    
    def keyDown(self):
        self.current_index = (self.current_index + 1) % self.total_items
        self.update_selection_colors()
    
    def keyLeft(self):
        self.current_index = (self.current_index - 1) % self.total_items
        self.update_selection_colors()
    
    def keyRight(self):
        self.current_index = (self.current_index + 1) % self.total_items
        self.update_selection_colors()
    
    def keyOk(self):
        current = self.get_current_item()
        print(f"[EbroStream] OK - Selected: {current['name']}")
        
        if current.get("requires_server", False) and not self.active_server:
            self.show_error("⚠️ Aucun serveur actif!\nVeuillez configurer un serveur dans SERVERS.")
            return
        
        current["action"]()
    
    def show_error(self, message):
        try:
            from Screens.MessageBox import MessageBox
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
        except:
            print(f"[EbroStream] Error: {message}")
    
    def show_message(self, message, msg_type="INFO"):
        try:
            from Screens.MessageBox import MessageBox
            typ = MessageBox.TYPE_INFO if msg_type == "INFO" else MessageBox.TYPE_ERROR
            self.session.open(MessageBox, message, typ, timeout=3)
        except:
            print(f"[EbroStream] Message: {message}")
    
    def exit(self):
        if self.date_timer:
            self.date_timer.stop()
        if self.ip_timer:
            self.ip_timer.stop()
        if self.update_check_timer:
            self.update_check_timer.stop()
        print("[EbroStream] Exiting...")
        super().close()