#!/bin/sh
# Arrêter le serveur web EbroStream

if [ -f /tmp/ebrostream_web.pid ]; then
    kill $(cat /tmp/ebrostream_web.pid) 2>/dev/null
    rm -f /tmp/ebrostream_web.pid
fi
pkill -f "web/api.py" 2>/dev/null
echo "✅ Serveur web arrêté"
