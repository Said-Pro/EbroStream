#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EbroStream Web API Server
Port: 8080
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import sys
import uuid
from urllib.parse import urlparse

# Configuration
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"
PORT = 8080

class EbroStreamHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        parsed = urlparse(self.path)
        
        if parsed.path == '/':
            self.serve_web_interface()
        elif parsed.path == '/api/servers':
            self.get_servers()
        elif parsed.path == '/api/status':
            self.get_status()
        else:
            self.send_error(404)
    
    def do_POST(self):
        parsed = urlparse(self.path)
        
        if parsed.path == '/api/servers/stalker':
            self.add_stalker_server()
        elif parsed.path == '/api/servers/xtream':
            self.add_xtream_server()
        else:
            self.send_error(404)
    
    def do_DELETE(self):
        parsed = urlparse(self.path)
        
        if parsed.path.startswith('/api/servers/'):
            server_id = parsed.path.split('/')[-1]
            self.delete_server(server_id)
        else:
            self.send_error(404)
    
    def do_PUT(self):
        parsed = urlparse(self.path)
        
        if parsed.path.startswith('/api/servers/'):
            server_id = parsed.path.split('/')[-1]
            self.toggle_server(server_id)
        else:
            self.send_error(404)
    
    def get_servers(self):
        """Retourne la liste des serveurs"""
        servers = self.load_servers()
        # Masquer les mots de passe
        for s in servers:
            if 'password' in s:
                s['password'] = '********'
        self.send_json(200, {'success': True, 'servers': servers})
    
    def get_status(self):
        """Retourne le statut du serveur"""
        import socket
        try:
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
        except:
            ip = "unknown"
        
        self.send_json(200, {
            'success': True,
            'status': 'running',
            'ip': ip,
            'port': PORT
        })
    
    def add_stalker_server(self):
        """Ajoute un serveur Stalker"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        
        try:
            data = json.loads(post_data)
        except:
            self.send_json(400, {'success': False, 'error': 'Invalid JSON'})
            return
        
        # Validation
        name = data.get('name', '').strip()
        host = data.get('host', '').strip()
        mac = data.get('mac', '').strip()
        
        if not name or not host or not mac:
            self.send_json(400, {'success': False, 'error': 'Tous les champs sont requis'})
            return
        
        # Créer le serveur
        server = {
            'id': str(uuid.uuid4())[:8],
            'type': 'stalker',
            'name': name,
            'host': host,
            'mac': mac,
            'active': data.get('active', False)
        }
        
        # Désactiver les autres si celui-ci est actif
        servers = self.load_servers()
        if server['active']:
            for s in servers:
                s['active'] = False
        
        servers.append(server)
        
        if self.save_servers(servers):
            self.send_json(201, {'success': True, 'message': f'Serveur {name} ajouté'})
        else:
            self.send_json(500, {'success': False, 'error': 'Erreur sauvegarde'})
    
    def add_xtream_server(self):
        """Ajoute un serveur Xtream"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        
        try:
            data = json.loads(post_data)
        except:
            self.send_json(400, {'success': False, 'error': 'Invalid JSON'})
            return
        
        # Validation
        name = data.get('name', '').strip()
        host = data.get('host', '').strip()
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        
        if not name or not host or not username or not password:
            self.send_json(400, {'success': False, 'error': 'Tous les champs sont requis'})
            return
        
        # Créer le serveur
        server = {
            'id': str(uuid.uuid4())[:8],
            'type': 'xtream',
            'name': name,
            'host': host,
            'username': username,
            'password': password,
            'active': data.get('active', False)
        }
        
        # Désactiver les autres si celui-ci est actif
        servers = self.load_servers()
        if server['active']:
            for s in servers:
                s['active'] = False
        
        servers.append(server)
        
        if self.save_servers(servers):
            self.send_json(201, {'success': True, 'message': f'Serveur {name} ajouté'})
        else:
            self.send_json(500, {'success': False, 'error': 'Erreur sauvegarde'})
    
    def delete_server(self, server_id):
        """Supprime un serveur"""
        servers = self.load_servers()
        new_servers = [s for s in servers if s.get('id') != server_id]
        
        if len(new_servers) == len(servers):
            self.send_json(404, {'success': False, 'error': 'Serveur non trouvé'})
            return
        
        if self.save_servers(new_servers):
            self.send_json(200, {'success': True, 'message': 'Serveur supprimé'})
        else:
            self.send_json(500, {'success': False, 'error': 'Erreur sauvegarde'})
    
    def toggle_server(self, server_id):
        """Active/Désactive un serveur"""
        servers = self.load_servers()
        
        for server in servers:
            if server.get('id') == server_id:
                # Inverser l'état
                new_state = not server.get('active', False)
                server['active'] = new_state
                
                # Si activé, désactiver les autres
                if new_state:
                    for s in servers:
                        if s.get('id') != server_id:
                            s['active'] = False
                
                if self.save_servers(servers):
                    self.send_json(200, {'success': True, 'active': new_state})
                else:
                    self.send_json(500, {'success': False, 'error': 'Erreur sauvegarde'})
                return
        
        self.send_json(404, {'success': False, 'error': 'Serveur non trouvé'})
    
    def load_servers(self):
        """Charge les serveurs depuis le fichier JSON"""
        if not os.path.exists(CONFIG_FILE):
            return []
        
        try:
            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
                elif isinstance(data, dict) and 'servers' in data:
                    return data['servers']
                return []
        except:
            return []
    
    def save_servers(self, servers):
        """Sauvegarde les serveurs"""
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, 'w') as f:
                json.dump({'servers': servers, 'total': len(servers)}, f, indent=2)
            return True
        except:
            return False
    
    def serve_web_interface(self):
        """Sert l'interface web"""
        html = self.get_html()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def get_html(self):
        """Retourne le HTML de l'interface web"""
        return '''<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EbroStream - Gestion des Serveurs</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
        }
        h1 { color: #3498db; font-size: 2.5rem; margin-bottom: 10px; }
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: center;
        }
        .tab {
            padding: 12px 30px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            cursor: pointer;
            font-weight: bold;
        }
        .tab.active { background: #3498db; border-color: #3498db; }
        .form-container {
            display: none;
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 40px;
        }
        .form-container.active { display: block; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; color: #bdc3c7; }
        input, select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 8px;
            color: #fff;
            font-size: 1rem;
        }
        input:focus { outline: none; border-color: #3498db; }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
        .btn-primary { background: #3498db; color: white; }
        .btn-success { background: #2ecc71; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        .btn-warning { background: #f39c12; color: black; }
        .server-card {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
        }
        .badge-stalker { background: rgba(52,152,219,0.2); color: #3498db; }
        .badge-xtream { background: rgba(46,204,113,0.2); color: #2ecc71; }
        .badge-active { background: rgba(46,204,113,0.3); color: #2ecc71; }
        .badge-inactive { background: rgba(149,165,166,0.2); color: #95a5a6; }
        .server-actions { display: flex; gap: 10px; }
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: none;
        }
        .alert.success { background: rgba(46,204,113,0.2); border-left: 4px solid #2ecc71; display: block; }
        .alert.error { background: rgba(231,76,60,0.2); border-left: 4px solid #e74c3c; display: block; }
        .stats {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 20px 40px;
            text-align: center;
        }
        .stat-number { font-size: 2rem; font-weight: bold; color: #3498db; }
        @media (max-width: 768px) {
            .server-card { flex-direction: column; align-items: flex-start; }
            .server-actions { width: 100%; justify-content: flex-end; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📡 EbroStream - Gestion des Serveurs</h1>
            <p>Interface web pour la configuration des serveurs Stalker et Xtream</p>
        </header>
        
        <div class="stats">
            <div class="stat-card"><div class="stat-number" id="totalServers">0</div><div>Total Serveurs</div></div>
            <div class="stat-card"><div class="stat-number" id="activeServers">0</div><div>Serveurs Actifs</div></div>
        </div>
        
        <div class="tabs">
            <div class="tab active" onclick="showTab('stalker')">📡 Serveur Stalker</div>
            <div class="tab" onclick="showTab('xtream')">⚡ Serveur Xtream</div>
        </div>
        
        <div id="stalkerForm" class="form-container active">
            <h2>Ajouter un serveur Stalker</h2>
            <div class="form-group"><label>Nom du serveur</label><input type="text" id="stalkerName" placeholder="Mon Serveur"></div>
            <div class="form-group"><label>URL du serveur</label><input type="url" id="stalkerHost" placeholder="http://ip:port/c/"></div>
            <div class="form-group"><label>Adresse MAC</label><input type="text" id="stalkerMac" placeholder="00:1A:79:00:00:00"></div>
            <div class="form-group"><label><input type="checkbox" id="stalkerActive"> Marquer comme actif</label></div>
            <button class="btn btn-primary" onclick="addStalkerServer()">➕ Ajouter</button>
        </div>
        
        <div id="xtreamForm" class="form-container">
            <h2>Ajouter un serveur Xtream</h2>
            <div class="form-group"><label>Nom du serveur</label><input type="text" id="xtreamName" placeholder="Mon Serveur"></div>
            <div class="form-group"><label>Hôte</label><input type="text" id="xtreamHost" placeholder="ip:port"></div>
            <div class="form-group"><label>Nom d'utilisateur</label><input type="text" id="xtreamUsername" placeholder="username"></div>
            <div class="form-group"><label>Mot de passe</label><input type="password" id="xtreamPassword" placeholder="password"></div>
            <div class="form-group"><label><input type="checkbox" id="xtreamActive"> Marquer comme actif</label></div>
            <button class="btn btn-success" onclick="addXtreamServer()">⚡ Ajouter</button>
        </div>
        
        <div id="alert" class="alert"></div>
        
        <h2>📋 Serveurs configurés</h2>
        <div id="serversList"></div>
    </div>
    
    <script>
        async function loadServers() {
            try {
                const resp = await fetch('/api/servers');
                const data = await resp.json();
                if (data.success) displayServers(data.servers);
            } catch(e) { showAlert('Erreur: ' + e.message, 'error'); }
        }
        
        function displayServers(servers) {
            const container = document.getElementById('serversList');
            document.getElementById('totalServers').textContent = servers.length;
            document.getElementById('activeServers').textContent = servers.filter(s => s.active).length;
            
            if (servers.length === 0) {
                container.innerHTML = '<div style="text-align:center;padding:40px;">📭 Aucun serveur configuré</div>';
                return;
            }
            
            container.innerHTML = servers.map(s => `
                <div class="server-card">
                    <div>
                        <strong>${s.type === 'stalker' ? '📡' : '⚡'} ${escapeHtml(s.name)}</strong>
                        <span class="badge ${s.type === 'stalker' ? 'badge-stalker' : 'badge-xtream'}">${s.type.toUpperCase()}</span>
                        <span class="badge ${s.active ? 'badge-active' : 'badge-inactive'}">${s.active ? '✓ Actif' : '○ Inactif'}</span>
                        <div style="font-size:0.85rem;color:#95a5a6;margin-top:5px;">
                            ${s.type === 'stalker' ? `🌐 ${escapeHtml(s.host)}<br>🔑 ${escapeHtml(s.mac)}` : `🌐 ${escapeHtml(s.host)}<br>👤 ${escapeHtml(s.username)}`}
                        </div>
                    </div>
                    <div class="server-actions">
                        <button class="btn btn-warning" onclick="toggleServer('${s.id}', ${!s.active})">${s.active ? '⏸️ Désactiver' : '▶️ Activer'}</button>
                        <button class="btn btn-danger" onclick="deleteServer('${s.id}')">🗑️ Supprimer</button>
                    </div>
                </div>
            `).join('');
        }
        
        function escapeHtml(text) { return text.replace(/[&<>]/g, function(m){if(m==='&') return '&amp;'; if(m==='<') return '&lt;'; if(m==='>') return '&gt;'; return m;}); }
        
        function showAlert(msg, type) {
            const alert = document.getElementById('alert');
            alert.textContent = msg;
            alert.className = `alert ${type}`;
            setTimeout(() => alert.className = 'alert', 5000);
        }
        
        function showTab(tab) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.form-container').forEach(f => f.classList.remove('active'));
            if (tab === 'stalker') {
                document.querySelector('.tab:first-child').classList.add('active');
                document.getElementById('stalkerForm').classList.add('active');
            } else {
                document.querySelector('.tab:last-child').classList.add('active');
                document.getElementById('xtreamForm').classList.add('active');
            }
        }
        
        async function addStalkerServer() {
            const data = {
                name: document.getElementById('stalkerName').value.trim(),
                host: document.getElementById('stalkerHost').value.trim(),
                mac: document.getElementById('stalkerMac').value.trim(),
                active: document.getElementById('stalkerActive').checked
            };
            if (!data.name || !data.host || !data.mac) { showAlert('Tous les champs sont requis', 'error'); return; }
            try {
                const resp = await fetch('/api/servers/stalker', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
                const result = await resp.json();
                if (result.success) { showAlert(result.message, 'success'); loadServers(); document.getElementById('stalkerName').value=''; document.getElementById('stalkerHost').value=''; document.getElementById('stalkerMac').value=''; document.getElementById('stalkerActive').checked=false; }
                else showAlert(result.error, 'error');
            } catch(e) { showAlert('Erreur: ' + e.message, 'error'); }
        }
        
        async function addXtreamServer() {
            const data = {
                name: document.getElementById('xtreamName').value.trim(),
                host: document.getElementById('xtreamHost').value.trim(),
                username: document.getElementById('xtreamUsername').value.trim(),
                password: document.getElementById('xtreamPassword').value.trim(),
                active: document.getElementById('xtreamActive').checked
            };
            if (!data.name || !data.host || !data.username || !data.password) { showAlert('Tous les champs sont requis', 'error'); return; }
            try {
                const resp = await fetch('/api/servers/xtream', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
                const result = await resp.json();
                if (result.success) { showAlert(result.message, 'success'); loadServers(); document.getElementById('xtreamName').value=''; document.getElementById('xtreamHost').value=''; document.getElementById('xtreamUsername').value=''; document.getElementById('xtreamPassword').value=''; document.getElementById('xtreamActive').checked=false; }
                else showAlert(result.error, 'error');
            } catch(e) { showAlert('Erreur: ' + e.message, 'error'); }
        }
        
        async function toggleServer(id, active) {
            try {
                const resp = await fetch(`/api/servers/${id}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify({active}) });
                const result = await resp.json();
                if (result.success) loadServers();
                else showAlert(result.error, 'error');
            } catch(e) { showAlert('Erreur: ' + e.message, 'error'); }
        }
        
        async function deleteServer(id) {
            if (!confirm('Supprimer ce serveur ?')) return;
            try {
                const resp = await fetch(`/api/servers/${id}`, { method: 'DELETE' });
                const result = await resp.json();
                if (result.success) loadServers();
                else showAlert(result.error, 'error');
            } catch(e) { showAlert('Erreur: ' + e.message, 'error'); }
        }
        
        loadServers();
    </script>
</body>
</html>'''
    
    def send_json(self, code, data):
        response = json.dumps(data).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(response)))
        self.end_headers()
        self.wfile.write(response)
    
    def log_message(self, format, *args):
        pass

def run_server():
    """Démarre le serveur web"""
    try:
        server = HTTPServer(('0.0.0.0', PORT), EbroStreamHandler)
        print(f"\n✅ Serveur web EbroStream démarré sur le port {PORT}")
        
        # Afficher l'IP
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            print(f"🌐 Interface accessible à: http://{ip}:{PORT}")
        except:
            pass
        
        print("🛑 Ctrl+C pour arrêter\n")
        server.serve_forever()
    except Exception as e:
        print(f"❌ Erreur: {e}")

if __name__ == '__main__':
    run_server()
