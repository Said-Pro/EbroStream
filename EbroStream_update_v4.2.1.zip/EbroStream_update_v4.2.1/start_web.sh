#!/bin/sh
# Démarrer le serveur web EbroStream

# Arrêter une instance existante
pkill -f "web/api.py" 2>/dev/null
sleep 1

# Démarrer
cd /usr/lib/enigma2/python/Plugins/Extensions/EbroStream
python3 web/api.py > /tmp/ebrostream_web.log 2>&1 &
echo $! > /tmp/ebrostream_web.pid

echo "✅ Serveur web démarré (PID: $(cat /tmp/ebrostream_web.pid))"
