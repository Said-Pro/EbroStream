#!/bin/bash
# start_web.sh - Démarre l'interface web EbroStream

PORT=8080
PLUGIN_DIR="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
PID_FILE="/tmp/ebrostream_web.pid"
LOG_FILE="/tmp/ebrostream_web.log"

echo "=========================================="
echo "     EbroStream Web Interface v1.0        "
echo "=========================================="

# Vérifier Python3
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 n'est pas installé!"
    exit 1
fi

# Arrêter une instance existante
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 $OLD_PID 2>/dev/null; then
        echo "🛑 Arrêt de l'ancienne instance (PID: $OLD_PID)..."
        kill $OLD_PID
        sleep 2
    fi
    rm -f "$PID_FILE"
fi

# Créer le répertoire web si nécessaire
WEB_DIR="$PLUGIN_DIR/web"
mkdir -p "$WEB_DIR"

# Démarrer le serveur
cd "$PLUGIN_DIR"

echo "🚀 Démarrage du serveur web sur le port $PORT..."

# Utiliser directement api.py à la racine
nohup python3 "$PLUGIN_DIR/api.py" --port $PORT > "$LOG_FILE" 2>&1 &
NEW_PID=$!
echo $NEW_PID > "$PID_FILE"

# Attendre le démarrage
sleep 2

# Vérifier
if kill -0 $NEW_PID 2>/dev/null; then
    # Récupérer l'IP
    IP=$(ip -4 addr show | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v 127.0.0.1 | head -1)
    
    echo ""
    echo "✅ Serveur web démarré avec succès!"
    echo "   PID: $NEW_PID"
    echo "   Port: $PORT"
    echo "   URL: http://$IP:$PORT"
    echo "   Logs: $LOG_FILE"
    echo ""
    echo "📋 Commandes:"
    echo "   • ./stop_web.sh  : Arrêter le serveur"
    echo "   • tail -f $LOG_FILE : Voir les logs"
    echo ""
else
    echo "❌ Échec du démarrage du serveur web"
    echo "📋 Logs:"
    tail -20 "$LOG_FILE"
    exit 1
fi