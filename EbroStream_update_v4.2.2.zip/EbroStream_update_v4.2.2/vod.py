#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
vod.py - Écran VOD avec chargement forcé de toutes les pages
Contourne la limitation des serveurs Stalker qui retournent max_page=1
"""

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, gRGB, eTimer
import json
import os
import ssl
import urllib.request
import urllib.parse
import time


class VodScreen(Screen):

    skin = """
    <screen name="VodScreen"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder"
            backgroundColor="transparent">

        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png"
                 zPosition="-1"/>

        <widget name="title" position="0,60" size="1820,70"
                font="Bold;55" halign="center" valign="center"
                foregroundColor="#ffffff" transparent="1"/>

        <widget name="server_info" position="0,130" size="1920,35"
                font="Regular;26" halign="center" valign="center"
                foregroundColor="#aaaaaa" transparent="1"/>

        <widget name="category_label" position="50,175" size="300,45"
                font="Bold;32" halign="left" valign="center"
                foregroundColor="#f1f90b" transparent="1"/>

        <widget name="category_list" position="50,228" size="400,700"
                font="Regular;23" halign="left" valign="center"
                foregroundColorSelected="#ffffff"
                foregroundColor="#cccccc"
                backgroundColorSelected="#3a6ea5"
                backgroundColor="#572c6e"
                scrollbarMode="showOnDemand"/>

        <widget name="movies_label" position="500,175" size="1100,45"
                font="Bold;32" halign="left" valign="center"
                foregroundColor="#f1f90b" transparent="1"/>

        <widget name="page_info" position="1510,175" size="360,45"
                font="Regular;26" halign="right" valign="center"
                foregroundColor="#aaaaaa" transparent="1"/>

        <widget name="movies_list" position="500,228" size="1370,650"
                font="Regular;23" halign="left" valign="center"
                foregroundColorSelected="#ffffff"
                foregroundColor="#cccccc"
                backgroundColorSelected="#3a6ea5"
                backgroundColor="#572c6e"
                scrollbarMode="showOnDemand"/>

        <widget name="status" position="50,945" size="1820,40"
                font="Regular;28" halign="center" valign="center"
                foregroundColor="#00ff00" transparent="1"/>

        <widget name="info" position="50,900" size="1820,40"
                font="Regular;24" halign="center" valign="center"
                foregroundColor="#ffff00" transparent="1"/>

        <widget name="key_red"    position="400,1005"   size="220,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#c0392b" foregroundColor="white" transparent="0"/>

        <widget name="key_green"  position="700,1005"  size="220,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#27ae60" foregroundColor="white" transparent="0"/>

        <widget name="key_yellow" position="1000,1005"  size="220,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#f39c12" foregroundColor="black" transparent="0"/>

        <widget name="key_blue"   position="1300,1005"  size="220,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#2980b9" foregroundColor="white" transparent="0"/>

        <widget name="help" position="1100,950" size="770,35"
                font="Regular;24" halign="right" valign="center"
                foregroundColor="#888888" transparent="1"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"]          = Label("🎬 VOD — Vidéo à la Demande")
        self["server_info"]    = Label("")
        self["category_label"] = Label("CATÉGORIES")
        self["movies_label"]   = Label("FILMS")
        self["page_info"]      = Label("")
        self["status"]         = Label("Chargement…")
        self["info"]           = Label("")
        self["key_red"]        = Label("🔴 Quitter")
        self["key_green"]      = Label("✅ Lire")
        self["key_yellow"]     = Label("◀ Page -")
        self["key_blue"]       = Label("▶ Page +")
        self["help"]           = Label("◄►: Focus  ▲▼: Navig.  OK: Sélect.  EXIT: Quitter")

        self["category_list"] = MenuList([], enableWrapAround=True)
        self["movies_list"]   = MenuList([], enableWrapAround=True)

        self.active_server = None
        self.server_type   = None
        self.portal        = None
        self.mac           = None
        self.token         = None
        self.base_url      = None
        self.username      = None
        self.password      = None

        self.categories     = []
        self.movies         = []
        self.current_cat_id = None
        self.current_focus  = "categories"

        self.current_page = 1
        self.max_page     = 1
        self.total_movies = 0
        self.per_page     = 25

        self._all_movies_cache = {}
        self._loading_complete = False

        self.playing = False
        self.overlay_visible = True
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hide_overlay)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up":       self.keyUp,
                "down":     self.keyDown,
                "left":     self.keyLeft,
                "right":    self.keyRight,
                "ok":       self.keyOk,
                "cancel":   self.exit,
                "red":      self.exit,
                "green":    self.keyGreen,
                "yellow":   self.keyYellow,
                "blue":     self.keyBlue,
                "pageUp":   self.prevPage,
                "pageDown": self.nextPage,
            }, -1
        )

        self.onLayoutFinish.append(self.start)

    def show_overlay(self):
        if not self.playing:
            return
        self.show()
        self.overlay_visible = True
        self.hide_timer.stop()
        self.hide_timer.start(5000, True)

    def hide_overlay(self):
        if self.playing and self.overlay_visible:
            self.hide()
            self.overlay_visible = False

    def start(self):
        if self._load_active_server():
            if self.server_type == 'stalker':
                self._stalker_handshake()
            elif self.server_type == 'xtream':
                self._xtream_load_vod_categories()
        else:
            self["status"].setText("❌ Configurez un serveur dans 'Servers'")

    def _load_active_server(self):
        config_file = "/etc/enigma2/EbroStream/servers.json"
        if not os.path.exists(config_file):
            return False
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for srv in data.get("servers", []):
                if srv.get("active", False):
                    self.active_server = srv
                    self.server_type   = srv.get("type", "stalker")
                    name = srv.get("name", "Serveur")
                    self["server_info"].setText(
                        f"🌐 {name}  ({'Stalker' if self.server_type == 'stalker' else 'Xtream'})"
                    )
                    if self.server_type == "stalker":
                        self.portal = srv["host"].rstrip("/") + "/server/load.php"
                        self.mac    = srv.get("mac", "")
                        print(f"[VOD] Stalker portal: {self.portal}")
                    elif self.server_type == "xtream":
                        self.base_url = srv["host"].rstrip("/")
                        self.username = srv.get("username") or srv.get("user", "")
                        self.password = srv.get("password", "")
                    return True
            self["status"].setText("⚠️ Aucun serveur actif")
            return False
        except Exception as e:
            print(f"[VOD] Erreur config: {e}")
            self["status"].setText("❌ Erreur configuration")
            return False

    def _get_stalker_headers(self):
        h = {
            "User-Agent":   "Mozilla/5.0",
            "X-User-Agent": "Model: MAG254",
            "Referer":      self.portal,
            "Cookie":       f"mac={self.mac}; stb_lang=en; timezone=UTC",
        }
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _stalker_handshake(self):
        try:
            self["status"].setText("Connexion Stalker…")
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "stb", "action": "handshake",
                "token": "", "JsHttpRequest": "1-xml",
            })
            req  = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0", "X-User-Agent": "Model: MAG254",
                "Referer": self.portal,
                "Cookie": f"mac={self.mac}; stb_lang=en; timezone=UTC",
            })
            resp = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=15)
            data = json.loads(resp.read().decode())
            token = data.get("js", {}).get("token")
            if not token:
                self["status"].setText("❌ Authentification Stalker échouée")
                return
            self.token = token
            print(f"[VOD] Stalker token obtenu")
            self._stalker_load_vod_categories()
        except Exception as e:
            print(f"[VOD] Handshake: {e}")
            self["status"].setText(f"❌ Connexion: {str(e)[:50]}")

    def _stalker_load_vod_categories(self):
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "vod", "action": "get_categories", "JsHttpRequest": "1-xml",
            })
            resp = urllib.request.urlopen(
                urllib.request.Request(url, headers=self._get_stalker_headers()),
                context=ssl._create_unverified_context(), timeout=15
            )
            raw = json.loads(resp.read().decode()).get("js", [])
            if isinstance(raw, dict):
                raw = raw.get("data", [])
            self.categories = [{"id": "all", "name": "📁 Toutes les catégories"}]
            for cat in raw:
                if isinstance(cat, dict):
                    self.categories.append({
                        "id":   cat.get("id", ""),
                        "name": cat.get("title", cat.get("name", "Catégorie")),
                    })
            self._update_category_list()
            self["status"].setText(f"✅ {len(self.categories) - 1} catégories")
            print(f"[VOD] {len(self.categories)} catégories chargées")
        except Exception as e:
            print(f"[VOD] Stalker catégories: {e}")
            self["status"].setText(f"❌ Catégories: {str(e)[:50]}")

    def _stalker_load_all_movies_forced(self, category_id):
        """
        Charge TOUS les films en ignorant max_page=1
        Continue à charger les pages tant qu'il y a des films
        """
        cache_key = f"{category_id}"
        
        if cache_key in self._all_movies_cache:
            print(f"[VOD] Utilisation du cache pour catégorie {cache_key}")
            return self._all_movies_cache[cache_key]
        
        all_movies = []
        page = 1
        max_pages_to_try = 50  # Maximum 50 pages (environ 700 films si 14 par page)
        
        self["status"].setText(f"Chargement de tous les films... (page {page})")
        
        while page <= max_pages_to_try:
            try:
                params = {
                    "type": "vod",
                    "action": "get_ordered_list",
                    "p": str(page),
                    "JsHttpRequest": "1-xml"
                }
                if category_id and category_id != "all":
                    params["category"] = str(category_id)
                
                url = self.portal + "?" + urllib.parse.urlencode(params)
                print(f"[VOD] Chargement page {page}...")
                
                req = urllib.request.Request(url, headers=self._get_stalker_headers())
                resp = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=15)
                data = json.loads(resp.read().decode())
                js = data.get("js", {})
                
                if isinstance(js, dict):
                    movies_page = js.get("data", js.get("movies", []))
                    total_items = int(js.get("total_items", 0))
                    max_page_from_server = int(js.get("max_page", 1))
                elif isinstance(js, list):
                    movies_page = js
                    total_items = len(movies_page)
                    max_page_from_server = 1
                else:
                    print(f"[VOD] Format de réponse inattendu à la page {page}")
                    break
                
                print(f"[VOD] Page {page}: {len(movies_page)} films, Total annoncé: {total_items}, Max page serveur: {max_page_from_server}")
                
                if not movies_page:
                    print(f"[VOD] Plus de films à la page {page}, arrêt")
                    break
                
                all_movies.extend(movies_page)
                
                # Critères d'arrêt :
                # 1. Si le serveur dit que c'est la dernière page ET qu'on a moins de 14 films
                # 2. Si on a moins de 14 films ET que c'est la page 1 (serveur buggé)
                # 3. Si on a atteint le nombre total annoncé
                
                if max_page_from_server > 1 and page >= max_page_from_server:
                    print(f"[VOD] Page max atteinte selon le serveur: {max_page_from_server}")
                    break
                
                if len(movies_page) < 14 and page > 1:
                    print(f"[VOD] Dernière page détectée ({len(movies_page)} < 14)")
                    break
                
                # Si c'est la page 1 et qu'on a 14 films, on continue quand même
                # car le serveur peut avoir plus de pages malgré max_page=1
                if page == 1 and len(movies_page) == 14 and total_items > 14:
                    print(f"[VOD] Page 1 donne 14 films mais total annoncé={total_items}, continuation...")
                
                page += 1
                self["status"].setText(f"Chargement des films... page {page} (total: {len(all_movies)})")
                time.sleep(0.3)  # Pause pour éviter de surcharger le serveur
                
            except Exception as e:
                print(f"[VOD] Erreur chargement page {page}: {e}")
                break
        
        print(f"[VOD] === RÉSULTAT FINAL ===")
        print(f"[VOD] Catégorie {category_id}: {len(all_movies)} films chargés sur {total_items if 'total_items' in dir() else '?'} annoncés")
        
        if len(all_movies) == 14 and total_items > 14:
            self["info"].setText("⚠️ Serveur limité - impossible de charger plus de 14 films")
        
        self._all_movies_cache[cache_key] = all_movies
        return all_movies

    def _stalker_load_vod_movies(self, category_id, page=1):
        try:
            # Charger tous les films de la catégorie
            all_movies = self._stalker_load_all_movies_forced(category_id)
            
            self.total_movies = len(all_movies)
            
            if self.total_movies == 0:
                self.movies = []
                self.max_page = 1
                self._display_movies()
                self["status"].setText("❌ Aucun film trouvé")
                return
            
            self.max_page = max(1, (self.total_movies + self.per_page - 1) // self.per_page)
            
            if page < 1:
                page = 1
            if page > self.max_page:
                page = self.max_page
            
            self.current_page = page
            
            start_idx = (page - 1) * self.per_page
            end_idx = min(start_idx + self.per_page, self.total_movies)
            
            self.movies = all_movies[start_idx:end_idx]
            self._display_movies()
            
        except Exception as e:
            print(f"[VOD] Stalker films error: {e}")
            self["status"].setText(f"❌ Films: {str(e)[:50]}")

    def _stalker_get_movie_url(self, movie):
        try:
            cmd = movie.get("cmd", "")
            resp = urllib.request.urlopen(
                urllib.request.Request(
                    self.portal + "?" + urllib.parse.urlencode({
                        "type": "vod", "action": "create_link",
                        "cmd": cmd, "series": "",
                        "forced_storage": "undefined", "disable_ad": "0",
                        "download": "0", "JsHttpRequest": "1-xml",
                    }),
                    headers=self._get_stalker_headers()
                ),
                context=ssl._create_unverified_context(), timeout=15
            )
            link = json.loads(resp.read().decode()).get("js", {}).get("cmd", "")
            if link:
                if link.startswith("ffmpeg "):
                    link = link.replace("ffmpeg ", "").strip()
                if link.startswith(("http://", "https://", "rtsp://", "rtmp://")):
                    return link
        except Exception as e:
            print(f"[VOD] create_link: {e}")
        
        cmd = movie.get("cmd", "")
        if cmd.startswith("ffmpeg "):
            cmd = cmd.replace("ffmpeg ", "").strip()
        return cmd if cmd.startswith(("http://", "https://", "rtsp://", "rtmp://")) else None

    # ==================== XTREAM ====================
    
    def _xtream_load_vod_categories(self):
        try:
            self["status"].setText("Chargement catégories VOD…")
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_vod_categories"
            resp = urllib.request.urlopen(
                urllib.request.Request(url),
                context=ssl._create_unverified_context(), timeout=15
            )
            data = json.loads(resp.read().decode())
            self.categories = [{"id": "all", "name": "📁 Toutes les catégories"}]
            for cat in data:
                if isinstance(cat, dict):
                    self.categories.append({
                        "id":   cat.get("category_id", ""),
                        "name": cat.get("category_name", "Catégorie"),
                    })
            self._update_category_list()
            self["status"].setText(f"✅ {len(self.categories) - 1} catégories")
        except Exception as e:
            print(f"[VOD] Xtream catégories: {e}")
            self["status"].setText(f"❌ Catégories: {str(e)[:50]}")

    def _xtream_load_vod_movies(self, category_id, page=1):
        try:
            self["status"].setText("Chargement films VOD…")
            base = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_vod_streams"
            if category_id and category_id != "all":
                base += f"&category_id={category_id}"
            
            resp = urllib.request.urlopen(
                urllib.request.Request(base),
                context=ssl._create_unverified_context(), timeout=20
            )
            all_movies = json.loads(resp.read().decode())
            
            if not isinstance(all_movies, list):
                all_movies = []
            
            self.total_movies = len(all_movies)
            self.max_page = max(1, (self.total_movies + self.per_page - 1) // self.per_page)
            
            if page < 1:
                page = 1
            if page > self.max_page:
                page = self.max_page
            
            self.current_page = page
            
            start_idx = (page - 1) * self.per_page
            end_idx = min(start_idx + self.per_page, self.total_movies)
            
            self.movies = all_movies[start_idx:end_idx]
            self._display_movies()
            
        except Exception as e:
            print(f"[VOD] Xtream films: {e}")
            self["status"].setText(f"❌ Films: {str(e)[:50]}")

    def _xtream_get_movie_url(self, movie):
        video_id = movie.get("stream_id") or movie.get("video_id", "")
        extension = movie.get("container_extension", "mp4")
        if not video_id:
            return None
        from urllib.parse import urlparse
        parsed = urlparse(self.base_url)
        base = f"{parsed.scheme}://{parsed.netloc}" if parsed.scheme and parsed.netloc else f"http://{self.base_url}"
        return f"{base}/movie/{self.username}/{self.password}/{video_id}.{extension}"

    # ==================== AFFICHAGE ====================
    
    def _update_category_list(self):
        self["category_list"].setList([c["name"] for c in self.categories])
        self["category_list"].moveToIndex(0)

    def _display_movies(self):
        items = []
        for m in self.movies:
            if self.server_type == "stalker":
                name = m.get("name", m.get("title", "Film inconnu"))
                year = m.get("year", "")
                text = f"🎬 {name}"
                if year:
                    text += f" ({year})"
            else:
                name = m.get("name", "Film inconnu")
                year = m.get("year", m.get("releaseDate", ""))
                rating = m.get("rating", m.get("rating_5based", ""))
                text = f"🎬 {name}"
                if year:
                    text += f" ({year})"
                if rating:
                    try:
                        text += f" ⭐{float(rating):.1f}"
                    except (ValueError, TypeError):
                        pass
            items.append(text)

        self["movies_list"].setList(items)
        if items:
            self["movies_list"].moveToIndex(0)

        cat_name = ""
        if self.current_cat_id:
            for c in self.categories:
                if c["id"] == self.current_cat_id:
                    cat_name = c["name"].split(" ", 1)[-1] if " " in c["name"] else c["name"]
                    break

        self["movies_label"].setText(
            f"{cat_name.upper()} ({self.total_movies})" if cat_name
            else f"FILMS ({self.total_movies})"
        )
        
        if self.max_page > 1:
            start_item = (self.current_page - 1) * self.per_page + 1
            end_item = min(self.current_page * self.per_page, self.total_movies)
            self["page_info"].setText(f"Page {self.current_page}/{self.max_page} | {start_item}-{end_item} / {self.total_movies}")
            self["key_yellow"].setText("◀ Page -")
            self["key_blue"].setText("▶ Page +")
        else:
            if self.total_movies > 0:
                self["page_info"].setText(f"📺 {self.total_movies} films")
            else:
                self["page_info"].setText("📺 Aucun film")
            self["key_yellow"].setText("")
            self["key_blue"].setText("")

        self["status"].setText(f"✅ {len(items)} films chargés")
        self.updateFocusVisual()

    def _load_movies_for_category(self, page=1):
        if self.server_type == "stalker":
            self._stalker_load_vod_movies(self.current_cat_id, page)
        elif self.server_type == "xtream":
            self._xtream_load_vod_movies(self.current_cat_id, page)

    def updateFocusVisual(self):
        try:
            if self.current_focus == "categories":
                self["category_label"].instance.setForegroundColor(gRGB(255, 255, 255))
                self["movies_label"].instance.setForegroundColor(gRGB(170, 0, 68))
            else:
                self["category_label"].instance.setForegroundColor(gRGB(170, 0, 68))
                self["movies_label"].instance.setForegroundColor(gRGB(255, 255, 255))
        except Exception:
            pass

    def _play_movie(self, movie_idx):
        if movie_idx < 0 or movie_idx >= len(self.movies):
            return

        movie = self.movies[movie_idx]

        if self.server_type == "stalker":
            name = movie.get("name", movie.get("title", "Film"))
            stream_url = self._stalker_get_movie_url(movie)
        else:
            name = movie.get("name", "Film")
            stream_url = self._xtream_get_movie_url(movie)

        if not stream_url:
            self["status"].setText("❌ Impossible de résoudre l'URL du film")
            return

        print(f"[VOD] Lecture: {name}")
        try:
            sref = eServiceReference(4097, 0, stream_url)
            sref.setName(name)
            sref.setData(0, 1)

            self.session.nav.playService(sref)
            self.playing = True
            self["status"].setText(f"▶️ Lecture: {name}")
            self["info"].setText(f"🔊 {name} en cours...")
            self.show_overlay()

        except Exception as e:
            print(f"[VOD] Erreur lecture: {e}")
            self["status"].setText(f"❌ Erreur lecture: {str(e)[:50]}")

    # ==================== NAVIGATION ====================
    
    def keyUp(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "categories":
            self["category_list"].up()
        else:
            self["movies_list"].up()
        if self.playing:
            self.show_overlay()

    def keyDown(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "categories":
            self["category_list"].down()
        else:
            self["movies_list"].down()
        if self.playing:
            self.show_overlay()

    def keyLeft(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        self.current_focus = "categories"
        self.updateFocusVisual()
        if self.playing:
            self.show_overlay()

    def keyRight(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self["movies_list"].getList():
            self.current_focus = "movies"
            self.updateFocusVisual()
        if self.playing:
            self.show_overlay()

    def keyOk(self):
        if self.playing:
            if not self.overlay_visible:
                self.show_overlay()
                return
        if self.current_focus == "categories":
            idx = self["category_list"].getSelectedIndex()
            if 0 <= idx < len(self.categories):
                cat = self.categories[idx]
                self.current_cat_id = cat["id"]
                self.current_page = 1
                self._all_movies_cache = {}
                self["status"].setText(f"📂 Chargement: {cat['name']}…")
                self._load_movies_for_category(1)
                self.current_focus = "movies"
                self.updateFocusVisual()
        else:
            idx = self["movies_list"].getSelectedIndex()
            self._play_movie(idx)
        if self.playing:
            self.show_overlay()

    def keyGreen(self):
        if self.playing:
            if not self.overlay_visible:
                self.show_overlay()
                return
        if self.current_focus == "movies":
            idx = self["movies_list"].getSelectedIndex()
            self._play_movie(idx)
        if self.playing:
            self.show_overlay()

    def keyYellow(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        self.prevPage()
        if self.playing:
            self.show_overlay()

    def keyBlue(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        self.nextPage()
        if self.playing:
            self.show_overlay()

    def prevPage(self):
        if self.current_page > 1:
            self._load_movies_for_category(self.current_page - 1)

    def nextPage(self):
        if self.current_page < self.max_page:
            self._load_movies_for_category(self.current_page + 1)

    def exit(self):
        if self.playing:
            self.session.nav.stopService()
        print("[VOD] Fermeture")
        self.close()