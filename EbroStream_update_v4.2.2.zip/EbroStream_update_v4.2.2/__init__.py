# __init__.py
#!/usr/bin/python
# -*- coding: utf-8 -*-

from .main import EbroStreamMain
from .live import LiveScreen
from .vod import VodScreen
from .series import SeriesScreen
from .servers_list import ServersListScreen
from .stalker_servers import StalkerServersScreen  # Ajouté
from .xtream_servers import XtreamServersScreen    # Ajouté
from .server_manager import ServerManager
from .settings_menu import SettingsMenuScreen
from .settings import SettingsScreen

__version__ = "4.0"
__author__ = "Saïd M.S"
__description__ = "IPTV Client for Stalker & Xtream"

__all__ = [
    'EbroStreamMain',
    'LiveScreen',
    'VodScreen',
    'SeriesScreen',
    'ServersListScreen',
    'StalkerServersScreen',   # Ajouté
    'XtreamServersScreen',    # Ajouté
    'ServerManager',
    'ConfigurationScreen',
    'SettingsMenuScreen',
    'SettingsScreen',
    'EditServerSimpleScreen',
]