#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Server Manager for EbroStream Plugin
Gestionnaire unifié des serveurs Stalker et Xtream
"""

import json
import os
import re
import ssl
import urllib.request
import urllib.parse
import uuid
from datetime import datetime

class ServerManager:
    """Gestionnaire unifié des serveurs Stalker et Xtream"""
    
    def __init__(self, config_path=None):
        if config_path is None:
            self.config_dir = "/etc/enigma2/EbroStream/"
            self.config_file_name = "servers.json"
            self.config_path = os.path.join(self.config_dir, self.config_file_name)
        else:
            self.config_path = config_path
            self.config_dir = os.path.dirname(config_path)
        
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir, exist_ok=True)
        
        self.servers = []
        self.active_server = None
        self.load_config()
    
    def load_config(self):
        """Charge la configuration"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                if isinstance(data, list):
                    self.servers = data
                elif isinstance(data, dict) and "servers" in data:
                    self.servers = data["servers"]
                else:
                    self.servers = []
                
                # Normaliser et logger les serveurs chargés
                for i, server in enumerate(self.servers):
                    self._normalize_server(server)
                    print(f"[ServerManager] Serveur {i}: {server.get('name')} - Type: {server.get('type')} - Host: {server.get('host')}")
                
                # Trouver le serveur actif
                for server in self.servers:
                    if server.get("active", False):
                        self.active_server = server
                        print(f"[ServerManager] Serveur actif: {server.get('name')} - Host: {server.get('host')}")
                        break
                
                return True
            else:
                # Créer un fichier de config vide
                self.servers = []
                self.save_config()
                return True
                
        except Exception as e:
            print(f"[ServerManager] Erreur chargement: {e}")
            self.servers = []
            return False
    
    def save_config(self):
        """Sauvegarde la configuration"""
        try:
            data = {
                "servers": self.servers,
                "metadata": {
                    "last_modified": datetime.now().isoformat(),
                    "total_servers": len(self.servers),
                    "version": "2.0"
                }
            }
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            print(f"[ServerManager] Configuration sauvegardée: {len(self.servers)} serveurs")
            return True
            
        except Exception as e:
            print(f"[ServerManager] Erreur sauvegarde: {e}")
            return False
    
    def _normalize_server(self, server):
        """Normalise les données d'un serveur"""
        if "id" not in server:
            server["id"] = str(uuid.uuid4())[:8]
        
        if "type" not in server:
            server["type"] = "stalker"
        
        if "name" not in server:
            server["name"] = "Serveur sans nom"
        
        # IMPORTANT: S'assurer que host est une chaîne non vide
        if "host" not in server or not server["host"]:
            server["host"] = ""
        
        if server["type"] == "stalker":
            if "mac" not in server:
                server["mac"] = "00:1A:79:00:00:00"
            else:
                server["mac"] = self.format_mac_address(server["mac"])
            if "username" not in server:
                server["username"] = ""
            if "password" not in server:
                server["password"] = ""
        else:  # xtream
            if "mac" not in server:
                server["mac"] = "00:1A:79:00:00:00"
            if "username" not in server:
                server["username"] = server.get("user", "")
            if "password" not in server:
                server["password"] = ""
        
        if "active" not in server:
            server["active"] = False
    
    def get_servers(self, server_type=None):
        """Retourne la liste des serveurs"""
        if server_type and server_type != 'all':
            return [s for s in self.servers if s.get("type") == server_type]
        return self.servers
    
    def get_active_server(self):
        """Retourne le serveur actif"""
        for server in self.servers:
            if server.get("active", False):
                return server
        return None
    
    def add_server(self, **kwargs):
        """Ajoute un nouveau serveur"""
        server_type = kwargs.get("server_type", "stalker")
        name = kwargs.get("name", "").strip()
        host = kwargs.get("host", "").strip()
        
        if not name:
            return {'success': False, 'message': "Le nom est requis"}
        if not host:
            return {'success': False, 'message': "L'URL du serveur est requise"}
        
        # Vérifier les doublons
        for server in self.servers:
            if server["name"] == name:
                return {'success': False, 'message': f"Le serveur '{name}' existe déjà"}
        
        new_server = {
            "id": str(uuid.uuid4())[:8],
            "type": server_type,
            "name": name,
            "host": host,
            "active": False
        }
        
        if server_type == "stalker":
            mac = kwargs.get("mac", "00:1A:79:00:00:00")
            new_server["mac"] = self.format_mac_address(mac)
            new_server["username"] = ""
            new_server["password"] = ""
        else:
            new_server["mac"] = "00:1A:79:00:00:00"
            new_server["username"] = kwargs.get("username", "").strip()
            new_server["password"] = kwargs.get("password", "").strip()
            
            if not new_server["username"]:
                return {'success': False, 'message': "Nom d'utilisateur requis pour Xtream"}
            if not new_server["password"]:
                return {'success': False, 'message': "Mot de passe requis pour Xtream"}
        
        self.servers.insert(0, new_server)
        
        if len(self.servers) == 1:
            new_server["active"] = True
            self.active_server = new_server
        
        if self.save_config():
            return {'success': True, 'message': f"Serveur '{name}' ajouté avec succès!", 'server': new_server}
        else:
            self.servers.pop(0)
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def update_server(self, index, **kwargs):
        """Met à jour un serveur"""
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}
        
        server = self.servers[index]
        
        if "name" in kwargs and kwargs["name"]:
            server["name"] = kwargs["name"].strip()
        
        if "host" in kwargs and kwargs["host"]:
            server["host"] = kwargs["host"].strip()
        
        if server["type"] == "stalker" and "mac" in kwargs:
            server["mac"] = self.format_mac_address(kwargs["mac"])
        
        if server["type"] == "xtream":
            if "user" in kwargs and kwargs["user"]:
                server["username"] = kwargs["user"].strip()
            if "password" in kwargs and kwargs["password"]:
                server["password"] = kwargs["password"].strip()
        
        if "active" in kwargs:
            server["active"] = kwargs["active"]
            if server["active"]:
                for s in self.servers:
                    if s != server:
                        s["active"] = False
                self.active_server = server
        
        if self.save_config():
            return {'success': True, 'message': "Serveur mis à jour"}
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def delete_server(self, index):
        """Supprime un serveur"""
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}
        
        server = self.servers[index]
        server_name = server["name"]
        was_active = server["active"]
        
        del self.servers[index]
        
        if was_active and self.servers:
            self.servers[0]["active"] = True
            self.active_server = self.servers[0]
        elif was_active:
            self.active_server = None
        
        if self.save_config():
            return {'success': True, 'message': f"Serveur '{server_name}' supprimé"}
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def format_mac_address(self, mac):
        """Formate une adresse MAC"""
        if not mac:
            return "00:00:00:00:00:00"
        
        mac = mac.strip().upper()
        mac = re.sub(r'[^0-9A-F]', '', mac)
        
        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]
        
        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])
    
    def validate_mac_address(self, mac):
        """Valide une adresse MAC"""
        pattern = r'^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$'
        return bool(re.match(pattern, mac))