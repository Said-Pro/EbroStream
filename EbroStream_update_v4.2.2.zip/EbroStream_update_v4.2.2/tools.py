#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import os
import ssl
import urllib.request
import urllib.parse
import time

class StalkerTools:
    """Outils pour interagir avec l'API Stalker"""
    
    @staticmethod
    def test_connection(host, mac, timeout=10):
        """Teste la connexion au serveur Stalker"""
        try:
            portal = host.rstrip("/") + "/server/load.php"
            
            url = portal + "?" + urllib.parse.urlencode({
                "type": "stb",
                "action": "handshake",
                "token": "",
                "JsHttpRequest": "1-xml"
            })
            
            headers = {
                "User-Agent": "Mozilla/5.0",
                "X-User-Agent": "Model: MAG254",
                "Referer": portal,
                "Cookie": f"mac={mac}; stb_lang=en; timezone=UTC"
            }
            
            req = urllib.request.Request(url, headers=headers)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=timeout)
            
            data = json.loads(response.read().decode())
            return data.get("js", {}).get("token") is not None
            
        except Exception as e:
            print(f"Erreur connexion: {e}")
            return False
    
    @staticmethod
    def get_all_channels(portal, mac, token, genre_id, max_pages=20):
        """Récupère toutes les chaînes d'un bouquet"""
        all_channels = []
        
        for page in range(1, max_pages + 1):
            try:
                url = portal + "?" + urllib.parse.urlencode({
                    "type": "itv",
                    "action": "get_ordered_list",
                    "genre": str(genre_id),
                    "p": str(page),
                    "JsHttpRequest": "1-xml"
                })
                
                headers = {
                    "User-Agent": "Mozilla/5.0",
                    "X-User-Agent": "Model: MAG254",
                    "Referer": portal,
                    "Cookie": f"mac={mac}; stb_lang=en",
                    "Authorization": f"Bearer {token}"
                }
                
                req = urllib.request.Request(url, headers=headers)
                context = ssl._create_unverified_context()
                response = urllib.request.urlopen(req, context=context, timeout=10)
                
                data = json.loads(response.read().decode())
                js = data.get("js", {})
                
                channels = []
                if isinstance(js, dict):
                    if "data" in js:
                        channels = js.get("data", [])
                    elif "channels" in js:
                        channels = js.get("channels", [])
                elif isinstance(js, list):
                    channels = js
                
                if not channels:
                    break
                
                all_channels.extend(channels)
                
                if isinstance(js, dict) and js.get("max_page", 0) == page:
                    break
                    
                time.sleep(0.1)
                
            except Exception as e:
                print(f"Erreur page {page}: {e}")
                break
        
        return all_channels
    
    @staticmethod
    def analyze_response_structure(response_data):
        """Analyse la structure de la réponse API"""
        analysis = {
            "type": type(response_data).__name__,
            "keys": [],
            "sample_data": None
        }
        
        if isinstance(response_data, dict):
            analysis["keys"] = list(response_data.keys())
            if analysis["keys"]:
                first_key = analysis["keys"][0]
                if isinstance(response_data[first_key], (dict, list)):
                    analysis["sample_data"] = type(response_data[first_key]).__name__
                else:
                    analysis["sample_data"] = str(response_data[first_key])[:100]
        
        elif isinstance(response_data, list):
            analysis["keys"] = ["list_items"]
            if response_data:
                analysis["sample_data"] = type(response_data[0]).__name__
        
        return analysis


class XtreamTools:
    """Outils pour interagir avec l'API Xtream"""
    
    @staticmethod
    def test_connection(host, username, password, timeout=10):
        """Teste la connexion au serveur Xtream"""
        try:
            import requests
            
            test_url = f"{host}/player_api.php?username={username}&password={password}"
            
            response = requests.get(test_url, timeout=timeout)
            data = response.json()
            
            return "user_info" in data
            
        except Exception as e:
            print(f"Erreur connexion Xtream: {e}")
            return False
    
    @staticmethod
    def get_categories(host, username, password):
        """Récupère les catégories Live TV"""
        try:
            import requests
            
            url = f"{host}/player_api.php?username={username}&password={password}&action=get_live_categories"
            
            response = requests.get(url, timeout=10)
            return response.json()
            
        except Exception as e:
            print(f"Erreur catégories Xtream: {e}")
            return []
    
    @staticmethod
    def get_streams(host, username, password, category_id=None):
        """Récupère les streams"""
        try:
            import requests
            
            if category_id:
                url = f"{host}/player_api.php?username={username}&password={password}&action=get_live_streams&category_id={category_id}"
            else:
                url = f"{host}/player_api.php?username={username}&password={password}&action=get_live_streams"
            
            response = requests.get(url, timeout=10)
            return response.json()
            
        except Exception as e:
            print(f"Erreur streams Xtream: {e}")
            return []
    
    @staticmethod
    def get_vod_categories(host, username, password):
        """Récupère les catégories VOD"""
        try:
            import requests
            
            url = f"{host}/player_api.php?username={username}&password={password}&action=get_vod_categories"
            
            response = requests.get(url, timeout=10)
            return response.json()
            
        except Exception as e:
            print(f"Erreur VOD catégories Xtream: {e}")
            return []
    
    @staticmethod
    def get_vod_streams(host, username, password, category_id=None):
        """Récupère les streams VOD"""
        try:
            import requests
            
            if category_id:
                url = f"{host}/player_api.php?username={username}&password={password}&action=get_vod_streams&category_id={category_id}"
            else:
                url = f"{host}/player_api.php?username={username}&password={password}&action=get_vod_streams"
            
            response = requests.get(url, timeout=10)
            return response.json()
            
        except Exception as e:
            print(f"Erreur VOD streams Xtream: {e}")
            return []


class CommonTools:
    """Outils communs"""
    
    @staticmethod
    def validate_url(url):
        """Valide une URL"""
        import re
        pattern = re.compile(
            r'^(https?://)?'  # http:// ou https://
            r'(([A-Z0-9]([A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domaine
            r'localhost|'  # localhost
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ou IP
            r'(?::\d+)?'  # port
            r'(?:/?|[/?]\S+)$', re.IGNORECASE)
        return re.match(pattern, url) is not None
    
    @staticmethod
    def validate_mac(mac):
        """Valide une adresse MAC"""
        import re
        pattern = re.compile(r'^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$')
        return re.match(pattern, mac) is not None
    
    @staticmethod
    def format_mac(mac):
        """Formate une adresse MAC"""
        if not mac:
            return "00:00:00:00:00:00"
        
        mac = mac.strip().upper()
        mac = re.sub(r'[^0-9A-F]', '', mac)
        
        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]
        
        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])
    
    @staticmethod
    def get_file_size(file_path):
        """Retourne la taille d'un fichier"""
        try:
            return os.path.getsize(file_path)
        except:
            return 0
    
    @staticmethod
    def human_readable_size(size):
        """Convertit une taille en format lisible"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.2f} {unit}"
            size /= 1024.0
        return f"{size:.2f} PB"
    
    @staticmethod
    def create_directory(path):
        """Crée un répertoire s'il n'existe pas"""
        try:
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
            return True
        except Exception as e:
            print(f"Erreur création répertoire {path}: {e}")
            return False
    
    @staticmethod
    def write_json_file(file_path, data):
        """Écrit des données dans un fichier JSON"""
        try:
            directory = os.path.dirname(file_path)
            CommonTools.create_directory(directory)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Erreur écriture JSON {file_path}: {e}")
            return False
    
    @staticmethod
    def read_json_file(file_path):
        """Lit des données depuis un fichier JSON"""
        try:
            if not os.path.exists(file_path):
                return {}
            
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Erreur lecture JSON {file_path}: {e}")
            return {}