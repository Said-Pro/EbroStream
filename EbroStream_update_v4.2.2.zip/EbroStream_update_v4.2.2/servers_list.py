#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import json
from datetime import datetime

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigSubsection, ConfigText, ConfigPassword, ConfigSelection, getConfigListEntry
from enigma import gRGB

class ServersListScreen(Screen):
    """Écran de gestion des serveurs avec affichage en grille 4x4 et pagination"""

    GRID_COLS = 4
    GRID_ROWS = 3
    SERVERS_PER_PAGE = GRID_COLS * GRID_ROWS  # 12

    GRID_START_X = 100
    GRID_START_Y = 200
    CELL_WIDTH = 400
    CELL_HEIGHT = 180
    SPACING_X = 30
    SPACING_Y = 30

    ICON_WIDTH = 280
    ICON_HEIGHT = 100
    
    ICON_X_OFFSET = (CELL_WIDTH - ICON_WIDTH) // 2
    ICON_Y_OFFSET = 15
    LABEL_Y_OFFSET = CELL_HEIGHT - 40
    LABEL_HEIGHT = 35

    ICON_STALKER = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/iconS.png"
    ICON_XTREAM = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/iconX.png"
    ICON_DEFAULT = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/icon_default.png"

    CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"] = Label("🌐 SERVER SELECTION")
        self["subtitle"] = Label("Select your server")
        self["status"] = Label("")
        self["page_info"] = Label("")

        # Boutons principaux
        self["btn_add"] = Button("➕ ADD")
        self["btn_connect"] = Button("✅ CONNECT")
        self["btn_edit"] = Button("✏️ EDIT")
        self["btn_delete"] = Button("🗑️ DELETE")
        self["btn_prev"] = Button("◀ PREV")
        self["btn_next"] = Button("NEXT ▶")

        self.grid_backgrounds = []
        self.grid_pixmaps = []
        self.grid_labels = []

        for i in range(self.SERVERS_PER_PAGE):
            bg_name = f"grid_bg_{i}"
            pixmap_name = f"grid_pixmap_{i}"
            label_name = f"grid_label_{i}"

            self[bg_name] = Pixmap()
            self[pixmap_name] = Pixmap()
            self[label_name] = Label("")

            self.grid_backgrounds.append(bg_name)
            self.grid_pixmaps.append(pixmap_name)
            self.grid_labels.append(label_name)

        self.servers = []
        self.selected_index = 0
        self.current_page = 0

        self.load_servers()

        self.skin = self.generate_skin()

        self.onLayoutFinish.append(self.update_display)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "cancel": self.close,
                "red": self.delete_server,
                "green": self.add_server,
                "yellow": self.edit_server,
                "blue": self.connect_server,
            },
            -1
        )

        print(f"[ServersList] Screen initialisé avec {len(self.servers)} serveurs")

    # ==================== PAGINATION ====================

    def get_total_pages(self):
        if len(self.servers) == 0:
            return 1
        return (len(self.servers) + self.SERVERS_PER_PAGE - 1) // self.SERVERS_PER_PAGE

    def get_page_servers(self):
        start = self.current_page * self.SERVERS_PER_PAGE
        end = start + self.SERVERS_PER_PAGE
        return self.servers[start:end]

    def next_page(self):
        if self.current_page + 1 < self.get_total_pages():
            self.current_page += 1
            self.update_display()

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.update_display()

    # ==================== GRILLE ====================

    def generate_skin(self):
        grid_widgets = ""

        for row in range(self.GRID_ROWS):
            for col in range(self.GRID_COLS):
                idx = row * self.GRID_COLS + col
                x = self.GRID_START_X + col * (self.CELL_WIDTH + self.SPACING_X)
                y = self.GRID_START_Y + row * (self.CELL_HEIGHT + self.SPACING_Y)
                
                icon_x = x + self.ICON_X_OFFSET
                icon_y = y + self.ICON_Y_OFFSET
                label_x = x
                label_y = y + self.LABEL_Y_OFFSET

                grid_widgets += f'''
    <widget name="grid_bg_{idx}" position="{x},{y}" size="{self.CELL_WIDTH},{self.CELL_HEIGHT}" 
            zPosition="1" backgroundColor="#2a2a2a" borderColor="#555555" borderWidth="2" transparent="1" />
    <widget name="grid_pixmap_{idx}" position="{icon_x},{icon_y}" size="{self.ICON_WIDTH},{self.ICON_HEIGHT}" 
            zPosition="2" transparent="1" alphatest="on" scale="1" />
    <eLabel position="{x + 20},{y + self.ICON_Y_OFFSET + self.ICON_HEIGHT + 8}" size="{self.CELL_WIDTH - 40},1" backgroundColor="#666666" zPosition="2" />
    <widget name="grid_label_{idx}" position="{label_x},{label_y}" size="{self.CELL_WIDTH},{self.LABEL_HEIGHT}" 
            font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" 
            backgroundColor="#00000000" transparent="1" zPosition="3" />
'''

        skin = f'''
<screen name="ServersListScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="#010103">
    
    <widget name="title" position="0,60" size="1920,40" font="Bold;52" halign="center" valign="center" foregroundColor="#00ff00" transparent="1" />
    
    <eLabel position="100,100" size="1720,2" backgroundColor="#333333" />
    
    <widget name="page_info" position="100,110" size="1720,40" font="Regular;24" halign="center" valign="center" foregroundColor="#888888" transparent="1" />
    
    <widget name="status" position="100,860" size="1720,40" font="Regular;25" halign="center" valign="center" foregroundColor="#d0de07" transparent="1" />
    
    <widget name="btn_add" position="400,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#2ecc71" transparent="0" />
    <widget name="btn_connect" position="700,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#3498db" transparent="0" />
    <widget name="btn_edit" position="1000,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#f39c12" transparent="0" />
    <widget name="btn_delete" position="1300,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#e74c3c" transparent="0" />
    
    <widget name="btn_prev" position="150,840" size="200,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#9b59b6" transparent="0" />
    <widget name="btn_next" position="1560,840" size="200,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#9b59b6" transparent="0" />
    
    {grid_widgets}

    <!-- Background Image -->
        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png"
                 zPosition="-1"/>

</screen>
'''
        return skin

    def update_display(self):
        self.update_page_info()
        self.update_grid_display()
        self.update_navigation_buttons()

    def update_page_info(self):
        total_pages = self.get_total_pages()
        if total_pages > 1:
            self["page_info"].setText(f"📄 Page {self.current_page + 1} / {total_pages} ({len(self.servers)} server(s))")
        else:
            self["page_info"].setText(f"📄 {len(self.servers)} server(s)")

    def update_navigation_buttons(self):
        total_pages = self.get_total_pages()
        if self.current_page == 0:
            self["btn_prev"].setText("◀ PREV (none)")
        else:
            self["btn_prev"].setText("◀ PREV")
            
        if self.current_page >= total_pages - 1:
            self["btn_next"].setText("NEXT (none) ▶")
        else:
            self["btn_next"].setText("NEXT ▶")

    def update_grid_display(self):
        try:
            page_servers = self.get_page_servers()
            start_global = self.current_page * self.SERVERS_PER_PAGE

            for i in range(self.SERVERS_PER_PAGE):
                bg_name = self.grid_backgrounds[i]
                pixmap_name = self.grid_pixmaps[i]
                label_name = self.grid_labels[i]

                if i < len(page_servers):
                    server = page_servers[i]
                    global_idx = start_global + i
                    server_name = server.get('name', f'Server {global_idx+1}')
                    server_type = server.get('type', 'stalker')
                    is_active = server.get('active', False)
                    is_selected = (global_idx == self.selected_index)

                    if len(server_name) > 28:
                        server_name = server_name[:25] + "..."

                    self[bg_name].show()
                    
                    if is_selected:
                        color = gRGB(60, 75, 50)
                    elif is_active:
                        color = gRGB(30, 70, 30)
                    else:
                        color = gRGB(42, 42, 54)
                    
                    if self[bg_name].instance:
                        self[bg_name].instance.setBackgroundColor(color)
                        if is_selected:
                            self[bg_name].instance.setBorderColor(gRGB(100, 255, 100))
                        else:
                            self[bg_name].instance.setBorderColor(gRGB(85, 85, 85))

                    self[pixmap_name].show()
                    self.set_icon(self[pixmap_name], server_type)

                    display_text = f"✓ {server_name}" if is_active else f"○ {server_name}"
                    self[label_name].setText(display_text)
                    
                    if is_selected:
                        self[label_name].instance.setForegroundColor(gRGB(255, 255, 100))
                    elif is_active:
                        self[label_name].instance.setForegroundColor(gRGB(0, 255, 0))
                    else:
                        self[label_name].instance.setForegroundColor(gRGB(200, 200, 200))
                    
                    self[label_name].show()

                else:
                    if len(self.servers) == 0 and self.current_page == 0 and i == 0:
                        self[bg_name].show()
                        if self[bg_name].instance:
                            self[bg_name].instance.setBackgroundColor(gRGB(45, 45, 55))
                        self[pixmap_name].hide()
                        self[label_name].setText("⊕ CLICK ADD")
                        self[label_name].instance.setForegroundColor(gRGB(100, 100, 255))
                        self[label_name].show()
                    else:
                        self[bg_name].hide()
                        self[pixmap_name].hide()
                        self[label_name].hide()

        except Exception as e:
            print(f"[ServersList] Erreur dans update_grid_display: {e}")

    def set_icon(self, pixmap_widget, server_type):
        try:
            if server_type.lower() in ('stalker', 'stb', 'mac'):
                icon_path = self.ICON_STALKER
            else:
                icon_path = self.ICON_XTREAM

            if os.path.exists(icon_path):
                pixmap_widget.instance.setPixmapFromFile(icon_path)
                pixmap_widget.instance.setScale(1)
            else:
                pixmap_widget.hide()
        except Exception as e:
            print(f"[ServersList] Erreur chargement icône: {e}")

    # ==================== GESTION DES SERVEURS ====================

    def load_servers(self):
        try:
            if not os.path.exists(self.CONFIG_FILE):
                self.servers = []
                self["status"].setText("⚠️ No server found - Click ADD")
                return

            with open(self.CONFIG_FILE, 'r') as f:
                data = json.load(f)

            # Lecture flexible du format
            if isinstance(data, list):
                self.servers = data
            elif isinstance(data, dict) and "servers" in data:
                self.servers = data["servers"]
            else:
                self.servers = []

            # Normalisation des champs
            for server in self.servers:
                if 'type' not in server:
                    server['type'] = 'stalker'
                if 'active' not in server:
                    server['active'] = False
                if 'name' not in server:
                    server['name'] = 'Unknown Server'
                # Uniformiser les noms de champs
                if 'host' not in server and 'url' in server:
                    server['host'] = server['url']
                if 'url' not in server and 'host' in server:
                    server['url'] = server['host']

            if len(self.servers) == 0:
                self.selected_index = 0
                self.current_page = 0
                self["status"].setText("⚠️ No server found - Click ADD")
            else:
                active_index = -1
                for i, s in enumerate(self.servers):
                    if s.get('active', False):
                        active_index = i
                        break
                
                if active_index >= 0:
                    self.selected_index = active_index
                    self.current_page = active_index // self.SERVERS_PER_PAGE
                else:
                    self.selected_index = 0
                    self.current_page = 0
                    
                active_count = sum(1 for s in self.servers if s.get('active', False))
                self["status"].setText(f"✅ {len(self.servers)} server(s) loaded ({active_count} active)")

        except Exception as e:
            print(f"[ServersList] Erreur chargement: {e}")
            self.servers = []
            self["status"].setText("❌ Error loading servers")

    def save_servers(self):
        """Sauvegarde la liste des serveurs"""
        try:
            os.makedirs(os.path.dirname(self.CONFIG_FILE), exist_ok=True)
            data = {"servers": self.servers, "last_updated": str(datetime.now())}
            with open(self.CONFIG_FILE, 'w') as f:
                json.dump(data, f, indent=4)
            print(f"[ServersList] Sauvegarde réussie: {len(self.servers)} serveurs")
            return True
        except Exception as e:
            print(f"[ServersList] Erreur sauvegarde: {e}")
            return False

    def get_current_server(self):
        if 0 <= self.selected_index < len(self.servers):
            return self.servers[self.selected_index]
        return None

    # ==================== ACTIONS ====================

    def keyUp(self):
        new_idx = self.selected_index - self.GRID_COLS
        if new_idx >= 0:
            self.selected_index = new_idx
            if new_idx // self.SERVERS_PER_PAGE != self.current_page:
                self.current_page = new_idx // self.SERVERS_PER_PAGE
                self.update_display()
            else:
                self.update_grid_display()
                self.update_navigation_buttons()

    def keyDown(self):
        new_idx = self.selected_index + self.GRID_COLS
        if new_idx < len(self.servers):
            self.selected_index = new_idx
            if new_idx // self.SERVERS_PER_PAGE != self.current_page:
                self.current_page = new_idx // self.SERVERS_PER_PAGE
                self.update_display()
            else:
                self.update_grid_display()
                self.update_navigation_buttons()

    def keyLeft(self):
        if self.selected_index % self.GRID_COLS > 0:
            self.selected_index -= 1
            self.update_grid_display()
            self.update_navigation_buttons()

    def keyRight(self):
        if (self.selected_index % self.GRID_COLS) < self.GRID_COLS - 1:
            new_idx = self.selected_index + 1
            if new_idx < len(self.servers):
                self.selected_index = new_idx
                self.update_grid_display()
                self.update_navigation_buttons()

    def keyOk(self):
        self.connect_server()

    def connect_server(self):
        """Active le serveur sélectionné - CORRIGÉ pour mise à jour immédiate"""
        server = self.get_current_server()
        if not server:
            self.show_message("❌ No server selected", "ERROR")
            return

        # Désactiver tous les serveurs
        for s in self.servers:
            s['active'] = False
        
        # Activer le serveur sélectionné
        server['active'] = True
        
        print(f"[ServersList] Activation du serveur: {server.get('name')}")

        # Sauvegarder dans le fichier
        if self.save_servers():
            # Mise à jour immédiate de l'affichage
            self.update_display()
            self.show_message(f"✅ Server activated:\n{server.get('name', '')}", "INFO")
        else:
            self.show_message("❌ Save error", "ERROR")

    def add_server(self):
        """Ouvre un formulaire pour ajouter un serveur"""
        self.session.openWithCallback(self.on_server_form_closed, ServerFormScreen, mode="add")

    def edit_server(self):
        """Ouvre un formulaire pour éditer le serveur sélectionné"""
        server = self.get_current_server()
        if not server:
            self.show_message("❌ No server selected", "ERROR")
            return
        self.session.openWithCallback(self.on_server_form_closed, ServerFormScreen, mode="edit", server_data=server, server_index=self.selected_index)

    def on_server_form_closed(self, result):
        """Callback après fermeture du formulaire"""
        if result:
            self.load_servers()
            self.update_display()
            self.show_message("✅ Operation completed", "INFO")

    def delete_server(self):
        server = self.get_current_server()
        if not server:
            self.show_message("❌ No server selected", "ERROR")
            return

        server_name = server.get('name', 'Server')
        self.session.openWithCallback(
            lambda result: self.confirm_delete(result, server_name),
            MessageBox,
            f"🗑️ Delete '{server_name}' ?\n\nThis action is irreversible!",
            MessageBox.TYPE_YESNO
        )

    def confirm_delete(self, result, server_name):
        if result:
            del self.servers[self.selected_index]
            
            if self.selected_index >= len(self.servers):
                self.selected_index = max(0, len(self.servers) - 1)
            
            new_total_pages = self.get_total_pages()
            if self.current_page >= new_total_pages and new_total_pages > 0:
                self.current_page = new_total_pages - 1
            elif new_total_pages == 0:
                self.current_page = 0
                self.selected_index = 0

            if self.save_servers():
                self.update_display()
                self.show_message(f"✅ '{server_name}' deleted", "INFO")
            else:
                self.show_message("❌ Delete error", "ERROR")

    def show_message(self, message, msg_type="INFO"):
        typ = MessageBox.TYPE_INFO if msg_type == "INFO" else MessageBox.TYPE_ERROR
        self.session.open(MessageBox, message, typ, timeout=3)

    def close(self):
        print("[ServersList] Fermeture")
        super().close()


# ==================== FORMULAIRE D'AJOUT/ÉDITION ====================

class ServerFormScreen(ConfigListScreen, Screen):
    """Formulaire pour ajouter ou modifier un serveur"""

    skin = """
        <screen position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="#010103">
            <widget name="title" position="0,80" size="1920,50" font="Bold;52" halign="center" valign="center" foregroundColor="#2ecc71" transparent="1" />
            <eLabel position="100,150" size="1720,2" backgroundColor="#333333" />
            <eLabel position="100,180" size="1720,500" backgroundColor="#19181c" transparent="1" zPosition="1"/>
            <widget name="config" position="120,200" size="1680,450" itemHeight="60" backgroundColor="#19181c" scrollbarMode="showOnDemand" foregroundColor="white" zPosition="2"/>
            <widget name="btn_save" position="560,750" size="300,80" font="Bold;32" halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <widget name="btn_cancel" position="1060,750" size="300,80" font="Bold;32" halign="center" valign="center" backgroundColor="#e74c3c" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session, mode="add", server_data=None, server_index=None):
        Screen.__init__(self, session)
        
        self.mode = mode  # "add" ou "edit"
        self.server_index = server_index
        self.server_data = server_data or {}
        
        # Titre
        if mode == "edit":
            self["title"] = Label("✏️ EDIT SERVER")
        else:
            self["title"] = Label("➕ ADD NEW SERVER")
        
        # Configuration
        self.config_data = ConfigSubsection()
        self.config_data.server_name = ConfigText(default=self.server_data.get('name', ''), fixed_size=False)
        self.config_data.server_type = ConfigSelection(
            choices=[("stalker", "Stalker Portal"), ("xtream", "Xtream Codes")],
            default=self.server_data.get('type', 'stalker')
        )
        self.config_data.server_host = ConfigText(default=self.server_data.get('host', self.server_data.get('url', 'http://')), fixed_size=False)
        self.config_data.server_mac = ConfigText(default=self.server_data.get('mac', '00:1A:79:XX:XX:XX'), fixed_size=False)
        self.config_data.server_user = ConfigText(default=self.server_data.get('username', self.server_data.get('user', '')), fixed_size=False)
        self.config_data.server_pass = ConfigPassword(default=self.server_data.get('password', ''), fixed_size=False)
        
        ConfigListScreen.__init__(self, [], session=session)
        self.createConfigList()
        
        self["btn_save"] = Button("💾 SAVE")
        self["btn_cancel"] = Button("❌ CANCEL")
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel,
            "ok": self.keyOK,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
        }, -2)
        
        print(f"[ServerForm] Mode: {mode}")
    
    def createConfigList(self):
        config_list = []
        config_list.append(getConfigListEntry("📛 Server Name", self.config_data.server_name))
        config_list.append(getConfigListEntry("📋 Server Type", self.config_data.server_type))
        config_list.append(getConfigListEntry("🌐 Server URL", self.config_data.server_host))
        
        if self.config_data.server_type.value == "stalker":
            config_list.append(getConfigListEntry("🔑 MAC Address", self.config_data.server_mac))
        else:
            config_list.append(getConfigListEntry("👤 Username", self.config_data.server_user))
            config_list.append(getConfigListEntry("🔒 Password", self.config_data.server_pass))
        
        self["config"].setList(config_list)
    
    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        if self["config"].getCurrent() and "Type" in self["config"].getCurrent()[0]:
            self.createConfigList()
    
    def keyRight(self):
        ConfigListScreen.keyRight(self)
        if self["config"].getCurrent() and "Type" in self["config"].getCurrent()[0]:
            self.createConfigList()
    
    def keyOK(self):
        current = self["config"].getCurrent()
        if current and hasattr(current[1], 'value'):
            self.openVirtualKeyBoard(current[1])
    
    def openVirtualKeyBoard(self, config_entry):
        current_text = config_entry.value
        self.session.openWithCallback(
            lambda text: self.keyboardCallback(text, config_entry),
            VirtualKeyBoard,
            title="Enter value",
            text=current_text
        )
    
    def keyboardCallback(self, text, config_entry):
        if text is not None:
            config_entry.value = text
            self.createConfigList()
    
    def save(self):
        name = self.config_data.server_name.value.strip()
        server_type = self.config_data.server_type.value
        host = self.config_data.server_host.value.strip()
        
        # Validation
        errors = []
        if not name:
            errors.append("Server name is required")
        if not host:
            errors.append("Server URL is required")
        elif not host.startswith(('http://', 'https://')):
            errors.append("URL must start with http:// or https://")
        
        if server_type == "stalker":
            mac = self.config_data.server_mac.value.strip()
            if not mac:
                errors.append("MAC address is required for Stalker")
        else:
            user = self.config_data.server_user.value.strip()
            password = self.config_data.server_pass.value.strip()
            if not user:
                errors.append("Username is required for Xtream")
            if not password:
                errors.append("Password is required for Xtream")
        
        if errors:
            self.session.open(MessageBox, "\n".join(errors), MessageBox.TYPE_ERROR)
            return
        
        # Construction du serveur
        server = {
            'name': name,
            'type': server_type,
            'host': host,
            'active': False
        }
        
        if server_type == "stalker":
            server['mac'] = self.config_data.server_mac.value.strip()
        else:
            server['username'] = self.config_data.server_user.value.strip()
            server['password'] = self.config_data.server_pass.value.strip()
        
        # Charger les serveurs existants
        config_file = "/etc/enigma2/EbroStream/servers.json"
        servers = []
        
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        servers = data
                    elif isinstance(data, dict) and "servers" in data:
                        servers = data["servers"]
        except Exception as e:
            print(f"[ServerForm] Erreur chargement: {e}")
        
        # Ajouter ou modifier
        if self.mode == "edit" and self.server_index is not None and self.server_index < len(servers):
            # Conserver l'état actif
            server['active'] = servers[self.server_index].get('active', False)
            servers[self.server_index] = server
            message = f"✅ Server '{name}' updated!"
        else:
            servers.append(server)
            message = f"✅ Server '{name}' added!"
        
        # Sauvegarder
        try:
            os.makedirs(os.path.dirname(config_file), exist_ok=True)
            with open(config_file, 'w') as f:
                json.dump({"servers": servers, "last_updated": str(datetime.now())}, f, indent=4)
            
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=2)
            self.close(True)
        except Exception as e:
            print(f"[ServerForm] Erreur sauvegarde: {e}")
            self.session.open(MessageBox, f"❌ Save error: {e}", MessageBox.TYPE_ERROR)
    
    def cancel(self):
        self.close(False)
    
    def close(self, result=None):
        print(f"[ServerForm] Fermeture, résultat: {result}")
        super().close(result)