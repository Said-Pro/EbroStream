#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
series.py - Écran Séries TV
Support complet Stalker Middleware et Xtream Codes API
Navigation : catégories → séries → saisons → épisodes → lecture

Structure à 4 colonnes de largeur égale :
  - Colonne 1 : Catégories
  - Colonne 2 : Séries
  - Colonne 3 : Saisons
  - Colonne 4 : Épisodes
"""

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, gRGB, eTimer
import json
import os
import ssl
import urllib.request
import urllib.parse
import time


class SeriesScreen(Screen):
    """
    Écran Séries — 4 colonnes de largeur égale
    """

    skin = """
    <screen name="SeriesScreen"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder"
            backgroundColor="transparent">

        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png"
                 zPosition="-1"/>

        <widget name="title" position="0,60" size="1920,70"
                font="Bold;55" halign="center" valign="center"
                foregroundColor="#ffffff" transparent="1"/>

        <widget name="server_info" position="0,130" size="1920,35"
                font="Regular;26" halign="center" valign="center"
                foregroundColor="#aaaaaa" transparent="1"/>

        <!-- Colonne 1: Catégories -->
        <widget name="category_label" position="40,175" size="430,45"
                font="Bold;28" halign="center" valign="center"
                foregroundColor="#f1f90b" transparent="1"/>

        <widget name="category_list" position="40,228" size="430,700"
                font="Regular;23" halign="left" valign="center"
                foregroundColorSelected="#ffffff"
                foregroundColor="#cccccc"
                backgroundColorSelected="#3a6ea5"
                backgroundColor="#572c6e"
                scrollbarMode="showOnDemand"/>

        <!-- Colonne 2: Séries -->
        <widget name="series_label" position="500,175" size="430,45"
                font="Bold;28" halign="center" valign="center"
                foregroundColor="#f1f90b" transparent="1"/>

        <widget name="series_list" position="500,228" size="430,700"
                font="Regular;23" halign="left" valign="center"
                foregroundColorSelected="#ffffff"
                foregroundColor="#cccccc"
                backgroundColorSelected="#3a6ea5"
                backgroundColor="#572c6e"
                scrollbarMode="showOnDemand"/>

        <!-- Colonne 3: Saisons -->
        <widget name="seasons_label" position="960,175" size="430,45"
                font="Bold;28" halign="center" valign="center"
                foregroundColor="#f1f90b" transparent="1"/>

        <widget name="seasons_list" position="960,228" size="430,700"
                font="Regular;23" halign="left" valign="center"
                foregroundColorSelected="#ffffff"
                foregroundColor="#cccccc"
                backgroundColorSelected="#3a6ea5"
                backgroundColor="#572c6e"
                scrollbarMode="showOnDemand"/>

        <!-- Colonne 4: Épisodes -->
        <widget name="episodes_label" position="1420,175" size="460,45"
                font="Bold;28" halign="center" valign="center"
                foregroundColor="#f1f90b" transparent="1"/>

        <widget name="episodes_list" position="1420,228" size="460,700"
                font="Regular;23" halign="left" valign="center"
                foregroundColorSelected="#ffffff"
                foregroundColor="#cccccc"
                backgroundColorSelected="#3a6ea5"
                backgroundColor="#572c6e"
                scrollbarMode="showOnDemand"/>

        <!-- Informations -->
        <widget name="page_info" position="0,175" size="1920,45"
                font="Regular;24" halign="center" valign="center"
                foregroundColor="#aaaaaa" transparent="1"/>

        <widget name="status" position="40,945" size="1840,40"
                font="Regular;26" halign="center" valign="center"
                foregroundColor="#00ff00" transparent="1"/>

        <widget name="info" position="40,900" size="1840,40"
                font="Regular;24" halign="center" valign="center"
                foregroundColor="#ffff00" transparent="1"/>

        <!-- Boutons -->
        <widget name="key_red"    position="40,1005"   size="200,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#c0392b" foregroundColor="white" transparent="0"/>

        <widget name="key_green"  position="280,1005"  size="200,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#27ae60" foregroundColor="white" transparent="0"/>

        <widget name="key_yellow" position="520,1005"  size="200,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#f39c12" foregroundColor="black" transparent="0"/>

        <widget name="key_blue"   position="760,1005"  size="200,55"
                font="Regular;26" halign="center" valign="center"
                backgroundColor="#2980b9" foregroundColor="white" transparent="0"/>

        <widget name="help" position="1100,1015" size="780,35"
                font="Regular;24" halign="right" valign="center"
                foregroundColor="#888888" transparent="1"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        # ── Widgets ──────────────────────────────────────────────
        self["title"]          = Label("📺 Séries TV")
        self["server_info"]    = Label("")
        self["category_label"] = Label("CATÉGORIES")
        self["series_label"]   = Label("SÉRIES")
        self["seasons_label"]  = Label("SAISONS")
        self["episodes_label"] = Label("ÉPISODES")
        self["page_info"]      = Label("")
        self["status"]         = Label("Chargement…")
        self["info"]           = Label("")
        self["key_red"]        = Label("🔴 Quitter")
        self["key_green"]      = Label("✅ Lire")
        self["key_yellow"]     = Label("◀ Page -")
        self["key_blue"]       = Label("▶ Page +")
        self["help"]           = Label("◄►: Navig.  ▲▼: Déplacer  OK: Sélect.  Vert: Lire")

        # ── Listes ───────────────────────────────────────────────
        self["category_list"] = MenuList([], enableWrapAround=True)
        self["series_list"]   = MenuList([], enableWrapAround=True)
        self["seasons_list"]  = MenuList([], enableWrapAround=True)
        self["episodes_list"] = MenuList([], enableWrapAround=True)

        # ── Connexion ────────────────────────────────────────────
        self.active_server  = None
        self.server_type    = None

        # Stalker
        self.portal         = None
        self.mac            = None
        self.token          = None

        # Xtream
        self.base_url       = None
        self.username       = None
        self.password       = None

        # ── Données ──────────────────────────────────────────────
        self.categories     = []
        self.series         = []
        self.seasons        = []
        self.episodes       = []
        
        self.current_cat_id = None
        self.current_series_id = None
        self.current_series_name = ""
        self.current_season_num = None

        # Pagination pour les séries
        self.current_page   = 1
        self.max_page       = 1
        self.total_series   = 0
        self.per_page       = 50

        # Cache
        self._all_xtream_series = []
        self._seasons_cache = {}
        self._episodes_cache = {}

        self.current_focus  = "categories"

        # ── Gestion overlay (lecture) ────────────────────────────
        self.playing = False
        self.overlay_visible = True
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hide_overlay)

        # ── Actions ──────────────────────────────────────────────
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up":       self.keyUp,
                "down":     self.keyDown,
                "left":     self.keyLeft,
                "right":    self.keyRight,
                "ok":       self.keyOk,
                "cancel":   self.exit,
                "red":      self.exit,
                "green":    self.keyGreen,
                "yellow":   self.keyYellow,
                "blue":     self.keyBlue,
                "pageUp":   self.prevPage,
                "pageDown": self.nextPage,
            }, -1
        )

        self.onLayoutFinish.append(self.start)

    def show_overlay(self):
        if not self.playing:
            return
        self.show()
        self.overlay_visible = True
        self.hide_timer.stop()
        self.hide_timer.start(5000, True)

    def hide_overlay(self):
        if self.playing and self.overlay_visible:
            self.hide()
            self.overlay_visible = False

    def start(self):
        if self._load_active_server():
            if self.server_type == 'stalker':
                self._stalker_handshake()
            elif self.server_type == 'xtream':
                self._xtream_load_series_categories()
        else:
            self["status"].setText("❌ Configurez un serveur dans 'Servers'")

    def _load_active_server(self):
        config_file = "/etc/enigma2/EbroStream/servers.json"
        if not os.path.exists(config_file):
            return False
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for srv in data.get("servers", []):
                if srv.get("active", False):
                    self.active_server = srv
                    self.server_type   = srv.get("type", "stalker")
                    name = srv.get("name", "Serveur")
                    self["server_info"].setText(
                        f"🌐 {name}  ({'Stalker' if self.server_type == 'stalker' else 'Xtream'})"
                    )
                    if self.server_type == "stalker":
                        self.portal = srv["host"].rstrip("/") + "/server/load.php"
                        self.mac    = srv.get("mac", "")
                        print(f"[Series] Stalker portal: {self.portal}")
                    elif self.server_type == "xtream":
                        self.base_url = srv["host"].rstrip("/")
                        self.username = srv.get("username") or srv.get("user", "")
                        self.password = srv.get("password", "")
                        print(f"[Series] Xtream URL: {self.base_url}")
                    return True
            self["status"].setText("⚠️ Aucun serveur actif")
            return False
        except Exception as e:
            print(f"[Series] Erreur config: {e}")
            return False

    def _get_stalker_headers(self):
        headers = {
            "User-Agent":   "Mozilla/5.0",
            "X-User-Agent": "Model: MAG254",
            "Referer":      self.portal,
            "Cookie":       f"mac={self.mac}; stb_lang=en; timezone=UTC",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _stalker_handshake(self):
        try:
            self["status"].setText("Connexion Stalker…")
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "stb", "action": "handshake",
                "token": "", "JsHttpRequest": "1-xml",
            })
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0", "X-User-Agent": "Model: MAG254",
                "Referer": self.portal,
                "Cookie": f"mac={self.mac}; stb_lang=en; timezone=UTC",
            })
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            self.token = data.get("js", {}).get("token")
            if not self.token:
                self["status"].setText("❌ Authentification échouée")
                return
            print(f"[Series] Token Stalker obtenu")
            self._stalker_load_series_categories()
        except Exception as e:
            print(f"[Series] Handshake error: {e}")
            self["status"].setText(f"❌ Connexion: {str(e)[:50]}")

    def _stalker_load_series_categories(self):
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "series", "action": "get_categories",
                "JsHttpRequest": "1-xml",
            })
            req = urllib.request.Request(url, headers=self._get_stalker_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())

            raw = data.get("js", [])
            if isinstance(raw, dict):
                raw = raw.get("data", [])

            self.categories = [{"id": "all", "name": "📁 Toutes les séries"}]
            for cat in raw:
                if isinstance(cat, dict):
                    self.categories.append({
                        "id":   cat.get("id", ""),
                        "name": cat.get("title", cat.get("name", "Catégorie")),
                    })

            self._update_category_list()
            self["status"].setText(f"✅ {len(self.categories) - 1} genres")
        except Exception as e:
            print(f"[Series] Stalker catégories: {e}")
            self["status"].setText(f"❌ Catégories: {str(e)[:50]}")

    def _stalker_load_series(self, category_id, page=1):
        try:
            self["status"].setText(f"Chargement séries page {page}…")
            params = {
                "type": "series", "action": "get_ordered_list",
                "p": str(page), "JsHttpRequest": "1-xml",
            }
            if category_id and category_id != "all":
                params["category"] = str(category_id)

            url = self.portal + "?" + urllib.parse.urlencode(params)
            req = urllib.request.Request(url, headers=self._get_stalker_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            js = data.get("js", {})

            if isinstance(js, dict):
                series_raw = js.get("data", js.get("movies", []))
                self.total_series = int(js.get("total_items", len(series_raw)))
                self.max_page = int(js.get("max_page", 1))
            elif isinstance(js, list):
                series_raw = js
                self.total_series = len(series_raw)
                self.max_page = 1
            else:
                series_raw = []

            self.series = series_raw
            self.current_page = page
            self._display_series()
            
            # Réinitialiser les colonnes suivantes
            self.seasons = []
            self.episodes = []
            self.current_series_id = None
            self.current_series_name = ""
            self.current_season_num = None
            self._update_seasons_list()
            self._update_episodes_list()
            
        except Exception as e:
            print(f"[Series] Stalker séries: {e}")
            self["status"].setText(f"❌ Séries: {str(e)[:50]}")

    def _stalker_load_seasons(self, series_id, series_name):
        """Charge les saisons d'une série Stalker avec gestion d'erreur améliorée"""
        try:
            # Vérifier le cache
            cache_key = f"stalker_{series_id}"
            if cache_key in self._seasons_cache:
                self.seasons = self._seasons_cache[cache_key]
                self._update_seasons_list()
                return
            
            self["status"].setText(f"Chargement des saisons de {series_name}…")
            
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "series", "action": "get_seasons",
                "movie_id": str(series_id), "JsHttpRequest": "1-xml",
            })
            
            print(f"[Series] URL saisons: {url}")
            
            req = urllib.request.Request(url, headers=self._get_stalker_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            
            # Lire la réponse brute
            raw_response = resp.read().decode('utf-8')
            print(f"[Series] Réponse brute saisons: {raw_response[:200]}...")
            
            # Vérifier si la réponse est vide
            if not raw_response or raw_response.strip() == "":
                print("[Series] Réponse vide pour les saisons")
                self.seasons = []
                self._update_seasons_list()
                self["status"].setText("⚠️ Aucune saison disponible")
                return
            
            # Essayer de parser le JSON
            try:
                data = json.loads(raw_response)
            except json.JSONDecodeError as e:
                print(f"[Series] Erreur JSON saisons: {e}")
                # Essayer de nettoyer la réponse
                import re
                # Chercher du JSON dans la réponse
                json_match = re.search(r'\{.*\}', raw_response, re.DOTALL)
                if json_match:
                    try:
                        data = json.loads(json_match.group())
                    except:
                        data = {}
                else:
                    data = {}

            seasons_raw = data.get("js", [])
            if isinstance(seasons_raw, dict):
                seasons_raw = seasons_raw.get("data", [])

            self.seasons = []
            for s in seasons_raw:
                try:
                    if isinstance(s, dict):
                        num = s.get("season_number")
                        if num is None:
                            num = s.get("id", "?")
                        name_val = s.get("name")
                        ep_count = s.get("count")
                        if ep_count is None:
                            ep_count = s.get("episodes_count", 0)
                        
                        num_str = str(num) if num is not None else "?"
                        
                        display_name = f"Saison {num_str}"
                        if ep_count and int(ep_count) > 0:
                            display_name += f" ({ep_count} épisodes)"
                        elif name_val and name_val != f"Saison {num_str}":
                            display_name = name_val
                        
                        self.seasons.append({
                            "id": num_str,
                            "name": display_name,
                            "season_num": num_str,
                            "raw_data": s
                        })
                    else:
                        s_str = str(s) if s is not None else "?"
                        self.seasons.append({
                            "id": s_str,
                            "name": f"Saison {s_str}",
                            "season_num": s_str,
                            "raw_data": None
                        })
                except Exception as e:
                    print(f"[Series] Erreur traitement saison: {e}")
                    continue
            
            # Si aucune saison trouvée, essayer d'utiliser get_episodes directement
            if not self.seasons:
                print("[Series] Aucune saison trouvée, tentative de chargement direct des épisodes...")
                self._stalker_load_episodes_direct(series_id, series_name)
                return
            
            self._seasons_cache[cache_key] = self.seasons
            self._update_seasons_list()
            self["status"].setText(f"✅ {len(self.seasons)} saisons chargées")
            
        except urllib.error.URLError as e:
            print(f"[Series] Erreur URL saisons: {e}")
            self["status"].setText(f"❌ Erreur réseau: {str(e)[:50]}")
            self.seasons = []
            self._update_seasons_list()
        except Exception as e:
            print(f"[Series] Stalker saisons error: {e}")
            self["status"].setText(f"❌ Saisons: {str(e)[:50]}")
            self.seasons = []
            self._update_seasons_list()

    def _stalker_load_episodes_direct(self, series_id, series_name):
        """Charge directement les épisodes quand il n'y a pas de saisons"""
        try:
            # Essayer avec season=all ou sans season
            for season_param in ["all", "0", "1"]:
                try:
                    url = self.portal + "?" + urllib.parse.urlencode({
                        "type": "series", "action": "get_episodes",
                        "movie_id": str(series_id), "season": season_param,
                        "JsHttpRequest": "1-xml",
                    })
                    req = urllib.request.Request(url, headers=self._get_stalker_headers())
                    ctx = ssl._create_unverified_context()
                    resp = urllib.request.urlopen(req, context=ctx, timeout=15)
                    raw_response = resp.read().decode('utf-8')
                    
                    if raw_response and raw_response.strip():
                        try:
                            data = json.loads(raw_response)
                            episodes_raw = data.get("js", [])
                            if isinstance(episodes_raw, dict):
                                episodes_raw = episodes_raw.get("data", [])
                            
                            if episodes_raw:
                                # Créer une saison virtuelle
                                self.seasons = [{
                                    "id": "1",
                                    "name": "Épisodes",
                                    "season_num": "1",
                                    "raw_data": None
                                }]
                                self._seasons_cache[f"stalker_{series_id}"] = self.seasons
                                self._update_seasons_list()
                                
                                # Charger directement les épisodes
                                self.episodes = []
                                for ep in episodes_raw:
                                    if isinstance(ep, dict):
                                        ep_num = ep.get("series", ep.get("episode_number", "?"))
                                        ep_name = ep.get("name", ep.get("title", f"Épisode {ep_num}"))
                                        self.episodes.append({
                                            "num": str(ep_num),
                                            "name": ep_name,
                                            "duration": "",
                                            "raw_data": ep
                                        })
                                self._episodes_cache[f"stalker_{series_id}_1"] = self.episodes
                                self._update_episodes_list()
                                self["status"].setText(f"✅ {len(self.episodes)} épisodes chargés")
                                return
                        except:
                            pass
                except:
                    continue
            
            self["status"].setText("⚠️ Aucun épisode disponible")
        except Exception as e:
            print(f"[Series] Erreur chargement direct épisodes: {e}")

    def _stalker_load_episodes(self, series_id, season_num, series_name):
        """Charge les épisodes d'une saison Stalker avec gestion d'erreur améliorée"""
        try:
            season_num_str = str(season_num).strip()
            
            cache_key = f"stalker_{series_id}_{season_num_str}"
            if cache_key in self._episodes_cache:
                self.episodes = self._episodes_cache[cache_key]
                self._update_episodes_list()
                return
            
            self["status"].setText(f"Chargement des épisodes saison {season_num_str}…")
            
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "series", "action": "get_episodes",
                "movie_id": str(series_id), "season": season_num_str,
                "JsHttpRequest": "1-xml",
            })
            
            print(f"[Series] URL épisodes: {url}")
            
            req = urllib.request.Request(url, headers=self._get_stalker_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            
            raw_response = resp.read().decode('utf-8')
            print(f"[Series] Réponse brute épisodes: {raw_response[:200]}...")
            
            if not raw_response or raw_response.strip() == "":
                print("[Series] Réponse vide pour les épisodes")
                self.episodes = []
                self._update_episodes_list()
                self["status"].setText("⚠️ Aucun épisode disponible")
                return
            
            try:
                data = json.loads(raw_response)
            except json.JSONDecodeError as e:
                print(f"[Series] Erreur JSON épisodes: {e}")
                import re
                json_match = re.search(r'\{.*\}', raw_response, re.DOTALL)
                if json_match:
                    try:
                        data = json.loads(json_match.group())
                    except:
                        data = {}
                else:
                    data = {}

            episodes_raw = data.get("js", [])
            if isinstance(episodes_raw, dict):
                episodes_raw = episodes_raw.get("data", [])

            self.episodes = []
            for ep in episodes_raw:
                try:
                    if isinstance(ep, dict):
                        ep_num = ep.get("series")
                        if ep_num is None:
                            ep_num = ep.get("episode_number", "?")
                        ep_name = ep.get("name")
                        if ep_name is None:
                            ep_name = ep.get("title", f"Épisode {ep_num}")
                        duration = ep.get("length")
                        if duration is None:
                            duration = ep.get("duration", "")
                        
                        duration_str = ""
                        if duration:
                            try:
                                minutes = int(duration) // 60
                                seconds = int(duration) % 60
                                if minutes > 0:
                                    duration_str = f" ({minutes}:{seconds:02d})"
                            except:
                                duration_str = f" ({duration})"
                        
                        self.episodes.append({
                            "num": str(ep_num) if ep_num is not None else "?",
                            "name": str(ep_name) if ep_name is not None else "Épisode",
                            "duration": duration_str,
                            "raw_data": ep
                        })
                except Exception as e:
                    print(f"[Series] Erreur traitement épisode: {e}")
                    continue
            
            self._episodes_cache[cache_key] = self.episodes
            self._update_episodes_list()
            self["status"].setText(f"✅ {len(self.episodes)} épisodes chargés")
            
        except Exception as e:
            print(f"[Series] Stalker épisodes error: {e}")
            self["status"].setText(f"❌ Épisodes: {str(e)[:50]}")
            self.episodes = []
            self._update_episodes_list()

    def _stalker_resolve_episode_url(self, cmd, ep):
        """Résout l'URL d'un épisode via create_link"""
        if not cmd:
            cmd = ep.get("raw_data", {}).get("cmd", "")
        
        if not cmd:
            return None
            
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "vod", "action": "create_link",
                "cmd": cmd, "series": "",
                "forced_storage": "undefined", "disable_ad": "0",
                "download": "0", "JsHttpRequest": "1-xml",
            })
            req = urllib.request.Request(url, headers=self._get_stalker_headers())
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())
            link = data.get("js", {}).get("cmd", "")
            if link:
                if link.startswith("ffmpeg "):
                    link = link.replace("ffmpeg ", "").strip()
                if link.startswith(("http://", "https://", "rtsp://", "rtmp://")):
                    return link
        except Exception as e:
            print(f"[Series] create_link error: {e}")

        if cmd.startswith("ffmpeg "):
            cmd = cmd.replace("ffmpeg ", "").strip()
        if cmd.startswith(("http://", "https://", "rtsp://", "rtmp://")):
            return cmd
        return None

    # ════════════════════════════════════════════════════════
    # XTREAM (fonctionne correctement)
    # ════════════════════════════════════════════════════════

    def _xtream_load_series_categories(self):
        try:
            self["status"].setText("Chargement catégories séries Xtream…")
            url = (f"{self.base_url}/player_api.php"
                   f"?username={self.username}&password={self.password}"
                   f"&action=get_series_categories")
            req = urllib.request.Request(url)
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())

            self.categories = [{"id": "all", "name": "📁 Toutes les séries"}]
            for cat in data:
                if isinstance(cat, dict):
                    self.categories.append({
                        "id":   cat.get("category_id", ""),
                        "name": cat.get("category_name", "Catégorie"),
                    })

            self._update_category_list()
            self["status"].setText(f"✅ {len(self.categories) - 1} genres")
        except Exception as e:
            print(f"[Series] Xtream catégories: {e}")
            self["status"].setText(f"❌ Catégories: {str(e)[:50]}")

    def _xtream_load_series(self, category_id, page=1):
        try:
            self["status"].setText("Chargement séries…")

            if category_id and category_id != "all":
                url = (f"{self.base_url}/player_api.php"
                       f"?username={self.username}&password={self.password}"
                       f"&action=get_series&category_id={category_id}")
            else:
                url = (f"{self.base_url}/player_api.php"
                       f"?username={self.username}&password={self.password}"
                       f"&action=get_series")

            req = urllib.request.Request(url)
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=20)
            all_series = json.loads(resp.read().decode())

            if not isinstance(all_series, list):
                all_series = []

            self._all_xtream_series = all_series
            self.total_series = len(all_series)
            self.max_page = max(1, (self.total_series + self.per_page - 1) // self.per_page)
            self.current_page = max(1, min(page, self.max_page))

            start = (self.current_page - 1) * self.per_page
            self.series = all_series[start: start + self.per_page]
            self._display_series()
            
            self.seasons = []
            self.episodes = []
            self.current_series_id = None
            self.current_series_name = ""
            self.current_season_num = None
            self._update_seasons_list()
            self._update_episodes_list()
            
        except Exception as e:
            print(f"[Series] Xtream séries: {e}")
            self["status"].setText(f"❌ Séries: {str(e)[:50]}")

    def _xtream_load_series_info(self, series_obj):
        """Charge les saisons d'une série Xtream"""
        try:
            series_id = series_obj.get("series_id", "")
            series_name = series_obj.get("name", "Série")
            
            if not series_id:
                self["status"].setText("❌ ID série manquant")
                return
            
            cache_key = f"xtream_{series_id}"
            if cache_key in self._seasons_cache:
                self.seasons = self._seasons_cache[cache_key]
                self._update_seasons_list()
                return

            self["status"].setText(f"Chargement des saisons de {series_name}…")

            url = (f"{self.base_url}/player_api.php"
                   f"?username={self.username}&password={self.password}"
                   f"&action=get_series_info&series_id={series_id}")
            req = urllib.request.Request(url)
            ctx = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=15)
            data = json.loads(resp.read().decode())

            seasons_dict = data.get("episodes", {})
            
            self.seasons = []
            for season_num, episodes in seasons_dict.items():
                try:
                    season_num_str = str(season_num) if season_num is not None else "?"
                    ep_count = len(episodes) if isinstance(episodes, list) else 0
                    display_name = f"Saison {season_num_str}"
                    if ep_count > 0:
                        display_name += f" ({ep_count} épisodes)"
                    
                    ep_cache_key = f"xtream_{series_id}_{season_num_str}"
                    episodes_list = []
                    for ep in episodes:
                        if isinstance(ep, dict):
                            ep_num = ep.get("episode_num", ep.get("id", "?"))
                            ep_name = ep.get("title", ep.get("name", f"Épisode {ep_num}"))
                            duration = ep.get("info", {}).get("duration", "") if isinstance(ep.get("info"), dict) else ""
                            episodes_list.append({
                                "num": str(ep_num),
                                "name": ep_name,
                                "duration": f" ({duration})" if duration else "",
                                "raw_data": ep
                            })
                    self._episodes_cache[ep_cache_key] = episodes_list
                    
                    self.seasons.append({
                        "id": season_num_str,
                        "name": display_name,
                        "season_num": season_num_str,
                        "series_id": series_id
                    })
                except Exception as e:
                    print(f"[Series] Erreur traitement saison Xtream: {e}")
                    continue
            
            self.seasons.sort(key=lambda x: int(x["season_num"]) if x["season_num"].isdigit() else 0)
            
            self._seasons_cache[cache_key] = self.seasons
            self._update_seasons_list()
            self["status"].setText(f"✅ {len(self.seasons)} saisons chargées")
            
        except Exception as e:
            print(f"[Series] Xtream série info: {e}")
            self["status"].setText(f"❌ Info série: {str(e)[:50]}")

    def _xtream_load_episodes(self, series_id, season_num, series_name):
        cache_key = f"xtream_{series_id}_{season_num}"
        if cache_key in self._episodes_cache:
            self.episodes = self._episodes_cache[cache_key]
            self._update_episodes_list()
            self["status"].setText(f"✅ {len(self.episodes)} épisodes chargés")
        else:
            self.episodes = []
            self._update_episodes_list()
            self["status"].setText("❌ Aucun épisode trouvé")

    def _xtream_get_episode_url(self, episode, series_name):
        try:
            ep_id = episode.get("raw_data", {}).get("id", "")
            ep_name = episode.get("name", "Épisode")
            ext = episode.get("raw_data", {}).get("container_extension", "mkv")
            
            if not ep_id:
                return None, None
            
            from urllib.parse import urlparse
            parsed = urlparse(self.base_url)
            base = f"{parsed.scheme}://{parsed.netloc}" if parsed.scheme and parsed.netloc else f"http://{self.base_url}"
            
            stream_url = f"{base}/series/{self.username}/{self.password}/{ep_id}.{ext}"
            return stream_url, f"{series_name} — {ep_name}"
        except Exception as e:
            print(f"[Series] Erreur construction URL Xtream: {e}")
            return None, None

    # ════════════════════════════════════════════════════════
    # AFFICHAGE
    # ════════════════════════════════════════════════════════

    def _update_category_list(self):
        self["category_list"].setList([c["name"] for c in self.categories])
        self["category_list"].moveToIndex(0)

    def _display_series(self):
        items = []
        for s in self.series:
            try:
                if self.server_type == "stalker":
                    name = s.get("name", s.get("title", "Série inconnue"))
                    if name is None:
                        name = "Série inconnue"
                    year = s.get("year", "")
                    if year is None:
                        year = ""
                    text = f"📺 {name}"
                    if year:
                        text += f" ({year})"
                else:
                    name = s.get("name", "Série inconnue")
                    if name is None:
                        name = "Série inconnue"
                    year = s.get("year", "")
                    if year is None:
                        year = ""
                    rating = s.get("rating", s.get("rating_5based", ""))
                    if rating is None:
                        rating = ""
                    text = f"📺 {name}"
                    if year:
                        text += f" ({year})"
                    if rating:
                        try:
                            text += f" ⭐{float(rating):.1f}"
                        except:
                            pass
                items.append(text)
            except Exception as e:
                print(f"[Series] Erreur affichage série: {e}")
                items.append("📺 Série inconnue")

        self["series_list"].setList(items)
        if items:
            self["series_list"].moveToIndex(0)

        cat_name = ""
        if self.current_cat_id:
            for c in self.categories:
                if c["id"] == self.current_cat_id:
                    cat_name = c["name"].split(" ", 1)[-1] if " " in c["name"] else c["name"]
                    break

        self["series_label"].setText(
            f"{cat_name.upper()} ({self.total_series})" if cat_name else f"SÉRIES ({self.total_series})"
        )

        if self.max_page > 1:
            self["page_info"].setText(f"Page {self.current_page}/{self.max_page}")
            self["key_yellow"].setText("◀ Page -")
            self["key_blue"].setText("▶ Page +")
        else:
            self["page_info"].setText(f"{len(items)} séries")
            self["key_yellow"].setText("")
            self["key_blue"].setText("")

        self["status"].setText(f"✅ {len(items)} séries chargées")
        self.updateFocusVisual()

    def _update_seasons_list(self):
        try:
            if self.seasons:
                items = [s.get("name", "Saison inconnue") for s in self.seasons if s.get("name")]
                self["seasons_list"].setList(items)
                if items:
                    self["seasons_list"].moveToIndex(0)
                self["seasons_label"].setText(f"SAISONS ({len(self.seasons)})")
            else:
                self["seasons_list"].setList([])
                self["seasons_label"].setText("SAISONS")
        except Exception as e:
            print(f"[Series] Erreur mise à jour saisons: {e}")
            self["seasons_list"].setList([])
            self["seasons_label"].setText("SAISONS")
        
        self.updateFocusVisual()

    def _update_episodes_list(self):
        try:
            if self.episodes:
                items = []
                for ep in self.episodes:
                    ep_num = ep.get("num", "?")
                    ep_name = ep.get("name", "Épisode")
                    duration = ep.get("duration", "")
                    text = f"{ep_num}️⃣ {ep_name}{duration}"
                    items.append(text)
                self["episodes_list"].setList(items)
                if items:
                    self["episodes_list"].moveToIndex(0)
                self["episodes_label"].setText(f"ÉPISODES ({len(self.episodes)})")
            else:
                self["episodes_list"].setList([])
                self["episodes_label"].setText("ÉPISODES")
        except Exception as e:
            print(f"[Series] Erreur mise à jour épisodes: {e}")
            self["episodes_list"].setList([])
            self["episodes_label"].setText("ÉPISODES")
        
        self.updateFocusVisual()

    def updateFocusVisual(self):
        try:
            cat_color = gRGB(170, 0, 68)
            series_color = gRGB(170, 0, 68)
            seasons_color = gRGB(170, 0, 68)
            episodes_color = gRGB(170, 0, 68)
            
            if self.current_focus == "categories":
                cat_color = gRGB(255, 255, 255)
            elif self.current_focus == "series":
                series_color = gRGB(255, 255, 255)
            elif self.current_focus == "seasons":
                seasons_color = gRGB(255, 255, 255)
            elif self.current_focus == "episodes":
                episodes_color = gRGB(255, 255, 255)
            
            self["category_label"].instance.setForegroundColor(cat_color)
            self["series_label"].instance.setForegroundColor(series_color)
            self["seasons_label"].instance.setForegroundColor(seasons_color)
            self["episodes_label"].instance.setForegroundColor(episodes_color)
        except:
            pass

    def _load_series_for_category(self, page=1):
        if self.server_type == "stalker":
            self._stalker_load_series(self.current_cat_id, page)
        elif self.server_type == "xtream":
            if page == 1 or not self._all_xtream_series:
                self._xtream_load_series(self.current_cat_id, page)
            else:
                self._xtream_change_page(page)

    def _xtream_change_page(self, page):
        self.current_page = max(1, min(page, self.max_page))
        start = (self.current_page - 1) * self.per_page
        self.series = self._all_xtream_series[start: start + self.per_page]
        self._display_series()

    def _play_episode(self, episode):
        try:
            if self.server_type == "stalker":
                cmd = episode.get("raw_data", {}).get("cmd", "")
                stream_url = self._stalker_resolve_episode_url(cmd, episode)
                ep_name = episode.get("name", "Épisode")
                if stream_url:
                    self._play_stream(stream_url, f"{self.current_series_name} — {ep_name}")
                else:
                    self["status"].setText("❌ URL de l'épisode introuvable")
            elif self.server_type == "xtream":
                stream_url, full_name = self._xtream_get_episode_url(episode, self.current_series_name)
                if stream_url:
                    self._play_stream(stream_url, full_name)
                else:
                    self["status"].setText("❌ URL de l'épisode introuvable")
        except Exception as e:
            print(f"[Series] Erreur lecture épisode: {e}")
            self["status"].setText("❌ Erreur lors de la lecture")

    def _play_stream(self, url, name):
        print(f"[Series] Lecture: {name}")
        try:
            sref = eServiceReference(4097, 0, url)
            sref.setName(name)
            sref.setData(0, 1)
            self.session.nav.playService(sref)
            self.playing = True
            self["status"].setText(f"▶️ Lecture: {name}")
            self["info"].setText(f"🔊 {name} en cours...")
            self.show_overlay()
        except Exception as e:
            print(f"[Series] Erreur lecture: {e}")
            self["status"].setText(f"❌ Lecture: {str(e)[:50]}")

    # ════════════════════════════════════════════════════════
    # NAVIGATION
    # ════════════════════════════════════════════════════════

    def keyUp(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "categories":
            self["category_list"].up()
        elif self.current_focus == "series":
            self["series_list"].up()
        elif self.current_focus == "seasons" and self.seasons:
            self["seasons_list"].up()
        elif self.current_focus == "episodes" and self.episodes:
            self["episodes_list"].up()
        if self.playing:
            self.show_overlay()

    def keyDown(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "categories":
            self["category_list"].down()
        elif self.current_focus == "series":
            self["series_list"].down()
        elif self.current_focus == "seasons" and self.seasons:
            self["seasons_list"].down()
        elif self.current_focus == "episodes" and self.episodes:
            self["episodes_list"].down()
        if self.playing:
            self.show_overlay()

    def keyLeft(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "series":
            self.current_focus = "categories"
        elif self.current_focus == "seasons":
            self.current_focus = "series"
        elif self.current_focus == "episodes":
            self.current_focus = "seasons"
        self.updateFocusVisual()
        if self.playing:
            self.show_overlay()

    def keyRight(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "categories" and self.series:
            self.current_focus = "series"
        elif self.current_focus == "series" and self.seasons:
            self.current_focus = "seasons"
        elif self.current_focus == "seasons" and self.episodes:
            self.current_focus = "episodes"
        self.updateFocusVisual()
        if self.playing:
            self.show_overlay()

    def keyOk(self):
        if self.playing:
            if not self.overlay_visible:
                self.show_overlay()
                return
        
        if self.current_focus == "categories":
            idx = self["category_list"].getSelectedIndex()
            if 0 <= idx < len(self.categories):
                cat = self.categories[idx]
                self.current_cat_id = cat["id"]
                self.current_page = 1
                self._all_xtream_series = []
                self.seasons = []
                self.episodes = []
                self.current_series_id = None
                self.current_series_name = ""
                self.current_season_num = None
                self._update_seasons_list()
                self._update_episodes_list()
                self["status"].setText(f"📂 Chargement: {cat['name']}…")
                self._load_series_for_category(1)
                self.current_focus = "series"
                self.updateFocusVisual()
        
        elif self.current_focus == "series":
            idx = self["series_list"].getSelectedIndex()
            if 0 <= idx < len(self.series):
                series_obj = self.series[idx]
                if self.server_type == "stalker":
                    self.current_series_id = series_obj.get("id", "")
                    self.current_series_name = series_obj.get("name", series_obj.get("title", "Série"))
                else:
                    self.current_series_id = series_obj.get("series_id", "")
                    self.current_series_name = series_obj.get("name", "Série")
                
                if self.current_series_id:
                    if self.server_type == "stalker":
                        self._stalker_load_seasons(self.current_series_id, self.current_series_name)
                    else:
                        self._xtream_load_series_info(series_obj)
                    self.current_focus = "seasons"
                    self.updateFocusVisual()
                else:
                    self["status"].setText("❌ ID série manquant")
        
        elif self.current_focus == "seasons":
            idx = self["seasons_list"].getSelectedIndex()
            if 0 <= idx < len(self.seasons):
                season = self.seasons[idx]
                self.current_season_num = season.get("season_num", "?")
                
                if self.server_type == "stalker":
                    self._stalker_load_episodes(self.current_series_id, self.current_season_num, self.current_series_name)
                elif self.server_type == "xtream":
                    self._xtream_load_episodes(self.current_series_id, self.current_season_num, self.current_series_name)
                
                self.current_focus = "episodes"
                self.updateFocusVisual()
        
        elif self.current_focus == "episodes":
            idx = self["episodes_list"].getSelectedIndex()
            if 0 <= idx < len(self.episodes):
                episode = self.episodes[idx]
                self._play_episode(episode)
        
        if self.playing:
            self.show_overlay()

    def keyGreen(self):
        if self.playing:
            if not self.overlay_visible:
                self.show_overlay()
                return
        if self.current_focus == "episodes":
            idx = self["episodes_list"].getSelectedIndex()
            if 0 <= idx < len(self.episodes):
                episode = self.episodes[idx]
                self._play_episode(episode)
        if self.playing:
            self.show_overlay()

    def keyYellow(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "series":
            self.prevPage()
        if self.playing:
            self.show_overlay()

    def keyBlue(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        if self.current_focus == "series":
            self.nextPage()
        if self.playing:
            self.show_overlay()

    def prevPage(self):
        if self.current_page > 1:
            self._load_series_for_category(self.current_page - 1)

    def nextPage(self):
        if self.current_page < self.max_page:
            self._load_series_for_category(self.current_page + 1)

    def exit(self):
        if self.playing:
            self.session.nav.stopService()
        print("[Series] Fermeture")
        self.close()