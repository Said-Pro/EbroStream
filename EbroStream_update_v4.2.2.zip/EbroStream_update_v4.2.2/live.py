#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, eTimer
import json
import os
import ssl
import urllib.request
import urllib.parse
import traceback

class LiveScreen(Screen):
    """Écran Live TV avec support Stalker et Xtream"""
    
    skin = """
    <screen name="LiveScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">
        <widget name="bg_bouquets" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png" 
                position="center,center" size="1920,1080" zPosition="0" alphatest="blend" />
        <widget name="bg_channels" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png.png" 
                position="center,center" size="1920,1080" zPosition="0" alphatest="blend" />

        <widget name="title" position="0,30" size="1920,60" font="Bold;45" halign="center" backgroundColor="transparent" transparent="1"/>
        <widget name="server_info" position="0,90" size="1920,35" font="Regular;26" halign="center" backgroundColor="transparent" transparent="1"/>

        <widget name="bouquet_list" position="50,130" size="860,750" itemHeight="45" font="Regular;28" zPosition="1" backgroundColor="#572c6e" transparent="0" foregroundColor="#ffffff"/>

        <widget name="channel_list" position="1000,130" size="850,750" itemHeight="45" font="Regular;28" zPosition="1" backgroundColor="#572c6e" transparent="0" foregroundColor="#ffffff"/>
        
        <widget name="status" position="50,920" size="850,35" font="Regular;26" halign="left" valign="center" backgroundColor="transparent" transparent="1"/>
        
        <widget name="page_info" position="1000,920" size="850,35" font="Regular;26" halign="right" valign="center" backgroundColor="transparent" transparent="1"/>
        
        <widget name="info" position="0,960" size="1920,40" font="Regular;26" halign="center" valign="center" backgroundColor="transparent" transparent="1"/>

        <widget name="key_red" position="1300,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#e74c3c" transparent="0" foregroundColor="white"/>
        <widget name="key_green" position="400,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#2ecc71" transparent="0" foregroundColor="white"/>
        <widget name="key_yellow" position="700,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#f1c40f" transparent="0" foregroundColor="black"/>
        <widget name="key_blue" position="1000,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#3498db" transparent="0" foregroundColor="white"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.error_shown = False  # Éviter les MessageBox multiples

        # Widgets
        self["bg_bouquets"] = Pixmap()
        self["bg_channels"] = Pixmap()
        self["title"] = Label("📡 Live TV")
        self["server_info"] = Label("")
        self["status"] = Label("Initialisation...")
        self["info"] = Label("EbroStream Live TV")
        self["page_info"] = Label("")

        # Listes
        self["bouquet_list"] = MenuList([])
        self["channel_list"] = MenuList([])

        # Boutons
        self["key_red"] = Button("🔴 EXIT")
        self["key_green"] = Button("✅ READ")
        self["key_yellow"] = Button("🔄 RELOAD")
        self["key_blue"] = Button("📋 ALL")

        # Variables
        self.server_type = None
        self.server_config = None
        self.portal = None
        self.mac = None
        self.token = None
        self.username = None
        self.password = None
        self.base_url = None

        self.bouquets = []
        self.channels = []
        self.all_channels = []
        self.total_channels = 0
        self.max_page = 1
        self.per_page = 50

        self.bouquet_index = 0
        self.channel_index = 0
        self.focus = "bouquet"
        self.playing = False
        self.overlay_visible = False
        self.current_genre_id = None
        self.current_page = 1
        self.show_all_mode = False

        # Timers
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hide_overlay)

        # Actions
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions", "NumberActions", "MenuActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "cancel": self.exit,
                "red": self.exit,
                "green": self.keyGreen,
                "yellow": self.keyYellow,
                "blue": self.keyBlue,
                "pageUp": self.prevPage,
                "pageDown": self.nextPage,
                "nextBouquet": self.nextBouquet,
                "prevBouquet": self.prevBouquet,
                "menu": self.show_options_menu,
                "0": lambda: self.numberKey(0),
                "1": lambda: self.numberKey(1),
                "2": lambda: self.numberKey(2),
                "3": lambda: self.numberKey(3),
                "4": lambda: self.numberKey(4),
                "5": lambda: self.numberKey(5),
                "6": lambda: self.numberKey(6),
                "7": lambda: self.numberKey(7),
                "8": lambda: self.numberKey(8),
                "9": lambda: self.numberKey(9),
            }, -2
        )

        # Démarrer après l'affichage
        self.onLayoutFinish.append(self.start)

    def show_error(self, message):
        """Affiche une erreur de manière sécurisée"""
        if not self.error_shown:
            self.error_shown = True
            self["status"].setText(f"❌ {message[:50]}")
            self["info"].setText(f"Erreur: {message[:80]}")
            # Utiliser un timer pour éviter les problèmes de modal
            from enigma import eTimer
            timer = eTimer()
            timer.callback.append(lambda: self._show_error_dialog(message))
            timer.start(100, True)

    def _show_error_dialog(self, message):
        """Affiche la dialog d'erreur après un délai"""
        try:
            self.session.open(MessageBox, f"❌ {message}", MessageBox.TYPE_ERROR, timeout=5)
        except:
            print(f"[LiveScreen] Error: {message}")

    def start(self):
        """Démarre le chargement"""
        self.load_active_server()

    def load_active_server(self):
        """Charge le serveur actif"""
        config_files = [
            "/etc/enigma2/EbroStream/servers.json",
            "/etc/enigma2/EbroStream/portals.json"
        ]
        
        config_file = None
        for cf in config_files:
            if os.path.exists(cf):
                config_file = cf
                break
        
        if not config_file:
            self["status"].setText("❌ Aucun serveur configuré")
            self["info"].setText("Configurez un serveur dans 'Servers'")
            self["server_info"].setText("⚠️ Configuration manquante")
            self["bouquet_list"].setList(["Configuration requise"])
            self["channel_list"].setList(["Ajoutez un serveur d'abord"])
            return

        try:
            with open(config_file, "r") as f:
                data = json.load(f)

            active_server = None
            
            if "servers" in data:
                for server in data.get("servers", []):
                    if server.get("active"):
                        active_server = server
                        break
            elif "portals" in data:
                for portal in data.get("portals", []):
                    if portal.get("active"):
                        active_server = portal
                        break
            
            if not active_server:
                self["status"].setText("⚠️ Aucun serveur actif")
                self["info"].setText("Activez un serveur dans 'Servers'")
                return

            self.server_config = active_server
            self.server_type = active_server.get('type', 'stalker')
            server_name = active_server.get('name', 'Serveur inconnu')
            
            if self.server_type == 'stalker':
                host = active_server.get("host", "")
                if not host:
                    self.show_error("URL du serveur Stalker manquante")
                    return
                self.portal = host.rstrip("/") + "/server/load.php"
                self.mac = active_server.get("mac", "00:1A:79:00:00:00")
                self["server_info"].setText(f"🌐 {server_name} (Stalker)")
                self["status"].setText("Connexion au serveur Stalker...")
                self.load_token()
                
            elif self.server_type == 'xtream':
                self.base_url = active_server.get("host", "").rstrip("/")
                self.username = active_server.get("username", active_server.get("user", ""))
                self.password = active_server.get("password", "")
                
                if not self.base_url:
                    self.show_error("URL du serveur Xtream manquante")
                    return
                if not self.username or not self.password:
                    self.show_error("Identifiants Xtream manquants")
                    return
                    
                self["server_info"].setText(f"🌐 {server_name} (Xtream)")
                self["status"].setText("Connexion au serveur Xtream...")
                self.load_xtream_categories()
                
        except Exception as e:
            print(f"[LiveScreen] Error loading server: {e}")
            self.show_error(f"Erreur chargement: {str(e)[:50]}")

    def load_token(self):
        """Récupère le token Stalker"""
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "stb",
                "action": "handshake",
                "token": "",
                "JsHttpRequest": "1-xml"
            })

            headers = {
                "User-Agent": "Mozilla/5.0",
                "X-User-Agent": "Model: MAG254",
                "Referer": self.portal,
                "Cookie": f"mac={self.mac}; stb_lang=en; timezone=UTC"
            }

            req = urllib.request.Request(url, headers=headers)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=10)
            
            data = json.loads(response.read().decode())
            
            if "js" in data and "token" in data["js"]:
                self.token = data["js"]["token"]
                self["status"].setText("✅ Connecté au serveur")
                self.load_bouquets()
            else:
                self.show_error("Token non reçu du serveur Stalker")
                
        except Exception as e:
            print(f"[LiveScreen] Token error: {e}")
            self.show_error(f"Erreur authentification: {str(e)[:40]}")

    def load_bouquets(self):
        """Charge les bouquets Stalker"""
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "itv",
                "action": "get_genres",
                "JsHttpRequest": "1-xml"
            })

            req = urllib.request.Request(url, headers=self.get_headers())
            response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=10)
            
            data = json.loads(response.read().decode())
            self.bouquets = data.get("js", [])
            
            if not self.bouquets:
                self["bouquet_list"].setList(["Aucun bouquet disponible"])
                return
            
            bouquet_items = []
            for bouquet in self.bouquets:
                title = bouquet.get('title', 'Bouquet sans nom')
                bouquet_items.append(f"📁 {title}")
            
            self["bouquet_list"].setList(bouquet_items)
            self["status"].setText(f"✅ {len(self.bouquets)} bouquets chargés")
            
            if self.bouquets:
                self.bouquet_index = 0
                self["bouquet_list"].moveToIndex(0)
                
        except Exception as e:
            print(f"[LiveScreen] Bouquets error: {e}")
            self.show_error(f"Erreur chargement bouquets: {str(e)[:40]}")

    def load_xtream_categories(self):
        """Charge les catégories Xtream"""
        try:
            # Construire l'URL complète
            if not self.base_url:
                self.show_error("URL du serveur Xtream non définie")
                return
                
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_live_categories"
            
            print(f"[LiveScreen] Loading Xtream categories from: {self.base_url}")
            
            req = urllib.request.Request(url)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=10)
            
            data = json.loads(response.read().decode())
            
            if not data:
                self["bouquet_list"].setList(["Aucune catégorie disponible"])
                return
            
            self.bouquets = []
            bouquet_items = []
            
            for idx, category in enumerate(data):
                if isinstance(category, dict):
                    category_id = category.get('category_id', idx)
                    category_name = category.get('category_name', f'Catégorie {idx}')
                    
                    self.bouquets.append({
                        'id': category_id,
                        'title': category_name,
                        'category_id': category_id
                    })
                    
                    bouquet_items.append(f"📁 {category_name}")
                else:
                    self.bouquets.append({
                        'id': idx,
                        'title': str(category),
                        'category_id': idx
                    })
                    bouquet_items.append(f"📁 {category}")
            
            self["bouquet_list"].setList(bouquet_items)
            self["status"].setText(f"✅ {len(self.bouquets)} loaded categories")
            
            if self.bouquets:
                self.bouquet_index = 0
                self["bouquet_list"].moveToIndex(0)
                
        except urllib.error.URLError as e:
            print(f"[LiveScreen] Xtream URL error: {e}")
            self.show_error(f"Erreur connexion Xtream: URL invalide ou serveur inaccessible")
        except Exception as e:
            print(f"[LiveScreen] Xtream categories error: {e}")
            self.show_error(f"Erreur chargement catégories: {str(e)[:40]}")

    def load_channels(self, genre_id=None, page=1):
        """Charge les chaînes"""
        self.show_all_mode = False
        
        if self.server_type == 'stalker':
            if genre_id is None and self.current_genre_id:
                genre_id = self.current_genre_id
            elif genre_id is None and self.bouquets:
                if self.bouquet_index < len(self.bouquets):
                    genre_id = self.bouquets[self.bouquet_index].get("id")
            
            if not genre_id:
                return
            
            self.current_genre_id = genre_id
            self.current_page = page
            self.load_stalker_channels(genre_id, page)
            
        elif self.server_type == 'xtream':
            if self.bouquets and self.bouquet_index < len(self.bouquets):
                category = self.bouquets[self.bouquet_index]
                category_id = category.get('category_id')
                
                if not category_id:
                    return
                
                self.current_genre_id = category_id
                self.current_page = page
                self.load_xtream_channels(category_id, page)

    def load_stalker_channels(self, genre_id, page=1):
        """Charge les chaînes Stalker"""
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "itv",
                "action": "get_ordered_list",
                "genre": str(genre_id),
                "p": str(page),
                "JsHttpRequest": "1-xml"
            })

            self["status"].setText(f"Chargement page {page}...")
            
            req = urllib.request.Request(url, headers=self.get_headers())
            response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=15)
            
            data = json.loads(response.read().decode())
            js = data.get("js", {})
            
            channels_data = []
            if isinstance(js, dict):
                if "data" in js:
                    channels_data = js.get("data", [])
                elif "channels" in js:
                    channels_data = js.get("channels", [])
            elif isinstance(js, list):
                channels_data = js
            
            self.channels = channels_data
            
            if isinstance(js, dict):
                self.total_channels = js.get("total_items", len(self.channels))
                self.max_page = js.get("max_page", 1)
            else:
                self.total_channels = len(self.channels)
                self.max_page = 1
            
            self.display_channels()
            
        except Exception as e:
            print(f"[LiveScreen] Stalker channels error: {e}")
            self["status"].setText(f"❌ Erreur: {str(e)[:30]}")

    def load_xtream_channels(self, category_id, page=1):
        """Charge les chaînes Xtream"""
        try:
            if not self.base_url:
                self.show_error("URL du serveur Xtream non définie")
                return
                
            items_per_page = self.per_page
            start_index = (page - 1) * items_per_page
            
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_live_streams&category_id={category_id}"
            
            self["status"].setText(f"Chargement catégorie...")
            
            req = urllib.request.Request(url)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=15)
            
            data = json.loads(response.read().decode())
            
            if not data:
                self.channels = []
                self.total_channels = 0
                self.max_page = 1
                self["channel_list"].setList(["Aucune chaîne"])
                return
            
            all_channels = data
            self.total_channels = len(all_channels)
            self.max_page = max(1, (self.total_channels + items_per_page - 1) // items_per_page)
            
            end_index = min(start_index + items_per_page, self.total_channels)
            self.channels = all_channels[start_index:end_index]
            
            self.display_channels()
            
        except Exception as e:
            print(f"[LiveScreen] Xtream channels error: {e}")
            self["status"].setText(f"❌ Erreur: {str(e)[:30]}")

    def display_channels(self):
        """Affiche les chaînes"""
        if self.max_page > 1:
            start_item = (self.current_page - 1) * self.per_page + 1
            end_item = min(self.current_page * self.per_page, self.total_channels)
        else:
            start_item = 1
            end_item = len(self.channels)
        
        channel_items = []
        for idx, channel in enumerate(self.channels):
            if self.server_type == 'stalker':
                number = channel.get('number', '')
                name = channel.get('name', 'Chaîne inconnue')
                if number:
                    channel_items.append(f"{number}. {name}")
                else:
                    channel_items.append(f"{idx+1}. {name}")
            elif self.server_type == 'xtream':
                name = channel.get('name', 'Chaîne inconnue')
                num = channel.get('num', idx + 1)
                channel_items.append(f"{num}. {name}")
        
        self["channel_list"].setList(channel_items)
        
        if self.max_page > 1:
            page_info = f"📄 Page {self.current_page}/{self.max_page} | Chaînes {start_item}-{end_item} sur {self.total_channels}"
            self["page_info"].setText(page_info)
            self["key_yellow"].setText("◀️ Page -")
            self["key_blue"].setText("▶️ Page +")
        else:
            page_info = f"📺 {len(self.channels)} chaînes"
            self["page_info"].setText(page_info)
            self["key_yellow"].setText("🔄 Recharger")
            self["key_blue"].setText("📋 Toutes")
        
        self["status"].setText(f"✅ {len(self.channels)} chaînes chargées")
        
        if self.channels:
            self.channel_index = 0
            self["channel_list"].moveToIndex(0)
            self.update_selection_info()

    def get_headers(self):
        """Retourne les headers HTTP"""
        headers = {
            "User-Agent": "Mozilla/5.0",
            "X-User-Agent": "Model: MAG254",
            "Referer": self.portal,
            "Cookie": f"mac={self.mac}; stb_lang=en"
        }
        
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        
        return headers

    def update_selection_info(self):
        """Met à jour les informations de sélection"""
        if self.focus == "bouquet" and self.bouquets:
            bouquet = self.bouquets[self.bouquet_index]
            name = bouquet.get('title', 'Bouquet sans nom')
            server_type_text = "Stalker" if self.server_type == 'stalker' else "Xtream"
            self["info"].setText(f"📁 {name} ({server_type_text})")
        
        elif self.focus == "channel" and self.channels:
            if self.channel_index < len(self.channels):
                channel = self.channels[self.channel_index]
                
                if self.server_type == 'stalker':
                    number = channel.get('number', '')
                    name = channel.get('name', 'Chaîne inconnue')
                    
                    if self.show_all_mode:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    elif self.max_page > 1:
                        absolute_position = ((self.current_page - 1) * self.per_page) + self.channel_index + 1
                        position = f"#{absolute_position}/{self.total_channels}"
                    else:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    
                    info_text = f"📺 "
                    if number:
                        info_text += f"{number}. "
                    info_text += f"{name} ({position})"
                    
                    self["info"].setText(info_text)
                    
                elif self.server_type == 'xtream':
                    name = channel.get('name', 'Chaîne inconnue')
                    num = channel.get('num', self.channel_index + 1)
                    
                    if self.show_all_mode:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    elif self.max_page > 1:
                        absolute_position = ((self.current_page - 1) * self.per_page) + self.channel_index + 1
                        position = f"#{absolute_position}/{self.total_channels}"
                    else:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    
                    info_text = f"📺 {num}. {name} ({position})"
                    self["info"].setText(info_text)

    def play_channel(self):
        """Joue la chaîne sélectionnée"""
        if not self.channels or self.channel_index >= len(self.channels):
            self["status"].setText("❌ Aucune chaîne sélectionnée")
            return

        channel = self.channels[self.channel_index]
        name = channel.get("name", "IPTV")
        
        if self.server_type == 'stalker':
            cmd = channel.get("cmd")
            if not cmd:
                self["status"].setText(f"❌ Flux invalide")
                return

            if cmd.startswith("ffmpeg "):
                cmd = cmd.replace("ffmpeg ", "").strip()
            
            if not (cmd.startswith("http://") or cmd.startswith("https://") or 
                    cmd.startswith("rtsp://") or cmd.startswith("rtmp://")):
                self["status"].setText("❌ Format non supporté")
                return
            
            stream_url = cmd
            
        elif self.server_type == 'xtream':
            stream_id = channel.get('stream_id')
            if not stream_id:
                self["status"].setText(f"❌ ID de flux invalide")
                return
            
            extension = channel.get('container_extension', 'ts')
            
            from urllib.parse import urlparse
            parsed = urlparse(self.base_url)
            
            if parsed.scheme and parsed.netloc:
                base_url = f"{parsed.scheme}://{parsed.netloc}"
            else:
                base_url = f"http://{self.base_url}"
            
            stream_url = f"{base_url}/live/{self.username}/{self.password}/{stream_id}.{extension}"
        
        else:
            self["status"].setText("❌ Type non supporté")
            return

        try:
            sref = eServiceReference(4097, 0, stream_url)
            sref.setName(name)
            sref.setData(0, 1)
            
            self.session.nav.playService(sref)
            self.playing = True
            
            self["status"].setText(f"▶️ Lecture: {name}")
            self["info"].setText(f"🔊 {name} en cours...")
            
            self.hide_timer.start(5000, True)
            
        except Exception as e:
            self["status"].setText(f"❌ Erreur lecture: {str(e)[:30]}")

    def show_overlay(self):
        if not self.playing:
            return
        
        self.show()
        self.overlay_visible = True
        self.hide_timer.stop()
        self.hide_timer.start(5000, True)

    def hide_overlay(self):
        if self.playing and self.overlay_visible:
            self.hide()
            self.overlay_visible = False

    # ==================== NAVIGATION ====================
    def keyOk(self):
        if self.playing:
            if self.overlay_visible:
                if self.focus == "bouquet":
                    if self.server_type == 'stalker':
                        self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
                    elif self.server_type == 'xtream':
                        category_id = self.bouquets[self.bouquet_index].get('category_id')
                        self.load_channels(category_id, 1)
                    self.focus = "channel"
                else:
                    self.play_channel()
            else:
                self.show_overlay()
        else:
            if self.focus == "bouquet":
                if self.bouquets:
                    if self.server_type == 'stalker':
                        self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
                    elif self.server_type == 'xtream':
                        category_id = self.bouquets[self.bouquet_index].get('category_id')
                        self.load_channels(category_id, 1)
                    self.focus = "channel"
            else:
                self.play_channel()

    def keyGreen(self):
        if self.focus == "channel" and self.channels:
            self.play_channel()

    def keyYellow(self):
        if self.max_page > 1 and not self.show_all_mode:
            self.prevPage()
        else:
            if self.current_genre_id:
                if self.server_type == 'stalker':
                    self.load_all_stalker_channels(self.current_genre_id)
                elif self.server_type == 'xtream':
                    self.load_all_xtream_channels(self.current_genre_id)

    def keyBlue(self):
        if self.max_page > 1 and not self.show_all_mode:
            self.nextPage()
        else:
            if self.all_channels:
                self.show_all_channels()

    def keyUp(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "bouquet":
            if self.bouquets:
                self.bouquet_index = max(0, self.bouquet_index - 1)
                self["bouquet_list"].moveToIndex(self.bouquet_index)
                self.update_selection_info()
        
        elif self.focus == "channel":
            if self.channels:
                self.channel_index = max(0, self.channel_index - 1)
                self["channel_list"].moveToIndex(self.channel_index)
                self.update_selection_info()
        
        if self.playing:
            self.show_overlay()

    def keyDown(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "bouquet":
            if self.bouquets:
                self.bouquet_index = min(len(self.bouquets) - 1, self.bouquet_index + 1)
                self["bouquet_list"].moveToIndex(self.bouquet_index)
                self.update_selection_info()
        
        elif self.focus == "channel":
            if self.channels:
                self.channel_index = min(len(self.channels) - 1, self.channel_index + 1)
                self["channel_list"].moveToIndex(self.channel_index)
                self.update_selection_info()
        
        if self.playing:
            self.show_overlay()

    def keyLeft(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "channel" and self.bouquets:
            self.focus = "bouquet"
        elif self.focus == "bouquet" and self.channels:
            self.focus = "channel"
        
        if self.playing:
            self.show_overlay()

    def keyRight(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "bouquet" and self.channels:
            self.focus = "channel"
        elif self.focus == "channel" and self.bouquets:
            self.focus = "bouquet"
        
        if self.playing:
            self.show_overlay()

    def prevPage(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        
        if self.focus == "channel" and self.current_genre_id:
            if self.current_page > 1:
                self.load_channels(page=self.current_page - 1)
                self["status"].setText(f"Page précédente: {self.current_page}")
        
        if self.playing:
            self.show_overlay()

    def nextPage(self):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        
        if self.focus == "channel" and self.current_genre_id:
            if self.current_page < self.max_page:
                self.load_channels(page=self.current_page + 1)
                self["status"].setText(f"Page suivante: {self.current_page}")
        
        if self.playing:
            self.show_overlay()

    def prevBouquet(self):
        if self.bouquets:
            self.bouquet_index = max(0, self.bouquet_index - 1)
            self["bouquet_list"].moveToIndex(self.bouquet_index)
            if self.server_type == 'stalker':
                self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
            elif self.server_type == 'xtream':
                category_id = self.bouquets[self.bouquet_index].get('category_id')
                self.load_channels(category_id, 1)
            self.update_selection_info()

    def nextBouquet(self):
        if self.bouquets:
            self.bouquet_index = min(len(self.bouquets) - 1, self.bouquet_index + 1)
            self["bouquet_list"].moveToIndex(self.bouquet_index)
            if self.server_type == 'stalker':
                self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
            elif self.server_type == 'xtream':
                category_id = self.bouquets[self.bouquet_index].get('category_id')
                self.load_channels(category_id, 1)
            self.update_selection_info()

    def numberKey(self, number):
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        
        if number == 0:
            if self.max_page > 1 and self.current_page != 1:
                self.load_channels(page=1)
                self["status"].setText("⏪ Première page")
        
        elif number == 9:
            if self.max_page > 1 and self.current_page != self.max_page:
                self.load_channels(page=self.max_page)
                self["status"].setText("⏩ Dernière page")
        
        elif 1 <= number <= 8:
            if self.focus == "bouquet" and self.bouquets:
                target_index = int((number / 8.0) * len(self.bouquets)) - 1
                if target_index < 0:
                    target_index = 0
                elif target_index >= len(self.bouquets):
                    target_index = len(self.bouquets) - 1
                
                if target_index != self.bouquet_index:
                    self.bouquet_index = target_index
                    self["bouquet_list"].moveToIndex(target_index)
                    self.update_selection_info()
            
            elif self.focus == "channel" and self.channels and self.max_page > 1:
                target_page = int((number / 8.0) * self.max_page)
                if target_page < 1:
                    target_page = 1
                elif target_page > self.max_page:
                    target_page = self.max_page
                
                if target_page != self.current_page:
                    self.load_channels(page=target_page)
                    self["status"].setText(f"↗️ Page {target_page}")

    def show_options_menu(self):
        from Screens.ChoiceBox import ChoiceBox
        
        options = [
            ("🔍 Voir toutes les chaînes", "show_all"),
            ("🔄 Recharger toutes les chaînes", "reload_all"),
        ]
        
        self.session.openWithCallback(
            self.options_menu_callback,
            ChoiceBox,
            title="Options",
            list=options
        )

    def options_menu_callback(self, result):
        if result is None:
            return
        
        action = result[1]
        
        if action == "show_all":
            if self.all_channels:
                self.show_all_channels()
            else:
                self["status"].setText("❌ Chargez d'abord les chaînes")
        
        elif action == "reload_all":
            if self.current_genre_id:
                if self.server_type == 'stalker':
                    self.load_all_stalker_channels(self.current_genre_id)
                elif self.server_type == 'xtream':
                    self.load_all_xtream_channels(self.current_genre_id)

    def load_all_stalker_channels(self, genre_id):
        try:
            all_channels = []
            page = 1
            max_attempts = 10
            
            while page <= max_attempts:
                url = self.portal + "?" + urllib.parse.urlencode({
                    "type": "itv",
                    "action": "get_ordered_list",
                    "genre": str(genre_id),
                    "p": str(page),
                    "JsHttpRequest": "1-xml"
                })
                
                req = urllib.request.Request(url, headers=self.get_headers())
                response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=10)
                data = json.loads(response.read().decode())
                js = data.get("js", {})
                
                page_channels = []
                if isinstance(js, dict):
                    if "data" in js:
                        page_channels = js.get("data", [])
                    elif "channels" in js:
                        page_channels = js.get("channels", [])
                elif isinstance(js, list):
                    page_channels = js
                
                if not page_channels:
                    break
                
                all_channels.extend(page_channels)
                
                if isinstance(js, dict):
                    max_page = js.get("max_page", 0)
                    if max_page > 0 and page >= max_page:
                        break
                
                if len(page_channels) < 10:
                    break
                
                page += 1
            
            self.channels = all_channels
            self.all_channels = all_channels.copy()
            self.total_channels = len(all_channels)
            self.max_page = 1
            
            self.display_channels()
            
        except Exception as e:
            print(f"[LiveScreen] Load all channels error: {e}")
            self["status"].setText(f"❌ Erreur: {str(e)[:30]}")

    def load_all_xtream_channels(self, category_id):
        try:
            if not self.base_url:
                return
                
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_live_streams&category_id={category_id}"
            
            self["status"].setText("Chargement toutes les chaînes...")
            
            req = urllib.request.Request(url)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=15)
            
            data = json.loads(response.read().decode())
            
            if not data:
                self.channels = []
                self.all_channels = []
                self["channel_list"].setList(["Aucune chaîne"])
                return
            
            self.channels = data
            self.all_channels = data.copy()
            self.total_channels = len(data)
            self.max_page = 1
            
            self.display_channels()
            
        except Exception as e:
            print(f"[LiveScreen] Load all Xtream channels error: {e}")
            self["status"].setText(f"❌ Erreur: {str(e)[:30]}")

    def show_all_channels(self):
        if not self.all_channels:
            self["status"].setText("❌ Aucune chaîne à afficher")
            return
        
        self.show_all_mode = True
        self.channels = self.all_channels.copy()
        
        channel_items = []
        for idx, channel in enumerate(self.channels):
            if self.server_type == 'stalker':
                number = channel.get('number', '')
                name = channel.get('name', 'Chaîne inconnue')
                if number:
                    channel_items.append(f"{number}. {name}")
                else:
                    channel_items.append(f"{idx+1}. {name}")
            elif self.server_type == 'xtream':
                name = channel.get('name', 'Chaîne inconnue')
                num = channel.get('num', idx + 1)
                channel_items.append(f"{num}. {name}")
        
        self["channel_list"].setList(channel_items)
        self["page_info"].setText(f"📺 {len(self.channels)} chaînes (liste complète)")
        self["status"].setText(f"✅ {len(self.channels)} chaînes affichées")
        
        if self.channels:
            self.channel_index = 0
            self["channel_list"].moveToIndex(0)
            self.update_selection_info()

    def exit(self):
        if self.playing:
            self.session.nav.stopService()
        self.close()