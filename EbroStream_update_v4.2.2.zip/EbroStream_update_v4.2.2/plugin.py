# plugin.py
#!/usr/bin/python
# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor

def main(session, **kwargs):
    """Main function - Entry point for Enigma2"""
    print("[EbroStream] Starting EbroStream plugin...")
    
    try:
        from Plugins.Extensions.EbroStream.main import EbroStreamMain
        print("[EbroStream] Successfully imported EbroStreamMain")
        return session.open(EbroStreamMain)
        
    except ImportError as e:
        print(f"[EbroStream] ImportError: {e}")
        
        try:
            import sys
            import os
            
            plugin_dir = '/usr/lib/enigma2/python/Plugins/Extensions/EbroStream'
            
            if plugin_dir not in sys.path:
                sys.path.append(plugin_dir)
            
            import main
            EbroStreamMain = main.EbroStreamMain
            print("[EbroStream] Imported via sys.path method")
            
            return session.open(EbroStreamMain)
            
        except Exception as e2:
            print(f"[EbroStream] Alternative import also failed: {e2}")
            
            try:
                from Screens.MessageBox import MessageBox
                error_msg = f"Cannot import EbroStream:\n\n{str(e)}"
                session.open(MessageBox, error_msg, MessageBox.TYPE_ERROR)
            except:
                pass
    
    except Exception as e:
        print(f"[EbroStream] General error: {e}")
        
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, f"Error: {str(e)[:50]}", MessageBox.TYPE_ERROR)
        except:
            pass
    
    return None

def Plugins(**kwargs):
    """Plugin descriptor for Enigma2"""
    return [
        PluginDescriptor(
            name="EbroStream",
            description="IPTV Client for Stalker & Xtream by Saïd M.S",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main,
            needsRestart=False
        )
    ]