# settings_menu.py - Version ultra stable
#!/usr/bin/python
# -*- coding: utf-8 -*-

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Screens.MessageBox import MessageBox

class SettingsMenuScreen(Screen):
    """
    Écran des paramètres avec image Add_S.png
    Contient uniquement un bouton ADD
    """
    
    skin = """
    <screen name="SettingsMenuScreen"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder">

        <!-- Background Image Add_S.png -->
        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/Add_S.png"
                 zPosition="-1"/>

        <!-- Bouton ADD -->
        <widget name="btn_add" position="50,1000" size="400,80"
                font="Bold;45" halign="center" valign="center"
                foregroundColor="#0de011" backgroundColor="#00aa00"
                transparent="1" zPosition="1"/>

        <!-- Bouton EXIT (RED) -->
        <widget name="key_red" position="1500,1000" size="400,80"
                font="Bold;45"  halign="center" valign="center"
                foregroundColor="#ff0000"  backgroundColor="#000000" 
                transparent="1" zPosition="1"/>
                

    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        
        # ==================== WIDGETS ====================
        self["btn_add"] = Button("➕ Add")
        self["key_red"] = Button("❌ Exit")
        
        # ==================== ACTIONS ====================
        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions"],
            {
                "red": self.exit,
                "cancel": self.exit,
                "ok": self.on_add_clicked,
            },
            -1
        )
    
    def on_add_clicked(self):
        """Action quand on clique sur ADD"""
        self.session.open(MessageBox, 
                         "✅ ADDITION EFFECTUÉE !", 
                         MessageBox.TYPE_INFO, 
                         timeout=2)
        print("[EbroStream] ADD button clicked")
    
    def exit(self):
        """Ferme l'écran"""
        print("[EbroStream] Closing settings...")
        self.close()