#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
XtreamServersScreen - Affiche uniquement les serveurs de type XTREAM
Affichage en grille 4x3 avec pagination
"""

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from enigma import gRGB
import json
import os
from datetime import datetime

class XtreamServersScreen(Screen):
    """Écran des serveurs Xtream uniquement - Affichage grille 4x3"""
    
    # Configuration de la grille
    GRID_COLS = 4
    GRID_ROWS = 3
    SERVERS_PER_PAGE = GRID_COLS * GRID_ROWS  # 12

    GRID_START_X = 100
    GRID_START_Y = 200
    CELL_WIDTH = 400
    CELL_HEIGHT = 180
    SPACING_X = 30
    SPACING_Y = 30

    ICON_WIDTH = 280
    ICON_HEIGHT = 100
    
    ICON_X_OFFSET = (CELL_WIDTH - ICON_WIDTH) // 2
    ICON_Y_OFFSET = 15
    LABEL_Y_OFFSET = CELL_HEIGHT - 40
    LABEL_HEIGHT = 35

    ICON_STALKER = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/iconS4.png"
    ICON_XTREAM = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/iconX4.png"
    ICON_DEFAULT = "/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/icon_default.png"

    CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"] = Label("🔗 SERVEURS XTREAM")
        self["subtitle"] = Label("Gestion des serveurs Xtream Codes API")
        self["status"] = Label("")
        self["page_info"] = Label("")

        # Boutons principaux
        self["btn_add"] = Button("➕ ADD")
        self["btn_connect"] = Button("✅ CONNECT")
        self["btn_edit"] = Button("✏️ EDIT")
        self["btn_delete"] = Button("🗑️ DELETE")
        self["btn_prev"] = Button("◀ PREV")
        self["btn_next"] = Button("NEXT ▶")

        # Widgets de la grille
        self.grid_backgrounds = []
        self.grid_pixmaps = []
        self.grid_labels = []

        for i in range(self.SERVERS_PER_PAGE):
            bg_name = f"grid_bg_{i}"
            pixmap_name = f"grid_pixmap_{i}"
            label_name = f"grid_label_{i}"

            self[bg_name] = Pixmap()
            self[pixmap_name] = Pixmap()
            self[label_name] = Label("")

            self.grid_backgrounds.append(bg_name)
            self.grid_pixmaps.append(pixmap_name)
            self.grid_labels.append(label_name)

        self.servers = []
        self.selected_index = 0
        self.current_page = 0

        # Générer le skin dynamique
        self.skin = self.generate_skin()

        self.load_servers()

        self.onLayoutFinish.append(self.update_display)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "cancel": self.close,
                "red": self.delete_server,
                "green": self.add_server,
                "yellow": self.edit_server,
                "blue": self.connect_server,
            }, -1
        )

        print(f"[XtreamServers] Screen initialisé avec {len(self.servers)} serveurs Xtream")

    def generate_skin(self):
        """Génère le skin dynamique avec la grille"""
        grid_widgets = ""

        for row in range(self.GRID_ROWS):
            for col in range(self.GRID_COLS):
                idx = row * self.GRID_COLS + col
                x = self.GRID_START_X + col * (self.CELL_WIDTH + self.SPACING_X)
                y = self.GRID_START_Y + row * (self.CELL_HEIGHT + self.SPACING_Y)
                
                icon_x = x + self.ICON_X_OFFSET
                icon_y = y + self.ICON_Y_OFFSET
                label_x = x
                label_y = y + self.LABEL_Y_OFFSET

                grid_widgets += f'''
    <widget name="grid_bg_{idx}" position="{x},{y}" size="{self.CELL_WIDTH},{self.CELL_HEIGHT}" 
            zPosition="1" backgroundColor="#2a2a2a" borderColor="#555555" borderWidth="2" transparent="1" />
    <widget name="grid_pixmap_{idx}" position="{icon_x},{icon_y}" size="{self.ICON_WIDTH},{self.ICON_HEIGHT}" 
            zPosition="2" transparent="1" alphatest="on" scale="1" />
    <eLabel position="{x + 20},{y + self.ICON_Y_OFFSET + self.ICON_HEIGHT + 8}" size="{self.CELL_WIDTH - 40},1" backgroundColor="#666666" zPosition="2" />
    <widget name="grid_label_{idx}" position="{label_x},{label_y}" size="{self.CELL_WIDTH},{self.LABEL_HEIGHT}" 
            font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" 
            backgroundColor="#00000000" transparent="1" zPosition="3" />
'''

        skin = f'''
<screen name="XtreamServersScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="#010103">
    
    <widget name="title" position="0,60" size="1920,70" font="Bold;52" halign="center" valign="center" foregroundColor="#3498db" transparent="1" />
    
    <widget name="subtitle" position="0,120" size="1920,40" font="Regular;28" halign="center" valign="center" foregroundColor="#aaaaaa" transparent="1" />
    
    <eLabel position="100,155" size="1720,2" backgroundColor="#333333" />
    
    <widget name="page_info" position="100,165" size="1720,40" font="Regular;24" halign="center" valign="center" foregroundColor="#888888" transparent="1" />
    
    <widget name="status" position="100,860" size="1720,40" font="Regular;25" halign="center" valign="center" foregroundColor="#d0de07" transparent="1" />
    
    <widget name="btn_add" position="400,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#2ecc71" transparent="0" />
    <widget name="btn_connect" position="700,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#3498db" transparent="0" />
    <widget name="btn_edit" position="1000,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#f39c12" transparent="0" />
    <widget name="btn_delete" position="1300,960" size="240,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#e74c3c" transparent="0" />
    
    <widget name="btn_prev" position="150,840" size="200,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#9b59b6" transparent="0" />
    <widget name="btn_next" position="1560,840" size="200,55" font="Bold;26" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#9b59b6" transparent="0" />
    
    {grid_widgets}

    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream/skins/live.png" zPosition="-1"/>

</screen>
'''
        return skin

    def get_total_pages(self):
        if len(self.servers) == 0:
            return 1
        return (len(self.servers) + self.SERVERS_PER_PAGE - 1) // self.SERVERS_PER_PAGE

    def get_page_servers(self):
        start = self.current_page * self.SERVERS_PER_PAGE
        end = start + self.SERVERS_PER_PAGE
        return self.servers[start:end]

    def next_page(self):
        if self.current_page + 1 < self.get_total_pages():
            self.current_page += 1
            self.update_display()

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.update_display()

    def load_servers(self):
        """Charge uniquement les serveurs Xtream"""
        try:
            if not os.path.exists(self.CONFIG_FILE):
                self.servers = []
                self["status"].setText("⚠️ Aucun serveur Xtream - Cliquez ADD")
                return

            with open(self.CONFIG_FILE, 'r') as f:
                data = json.load(f)

            if isinstance(data, list):
                all_servers = data
            elif isinstance(data, dict) and "servers" in data:
                all_servers = data["servers"]
            else:
                all_servers = []

            # Filtrer uniquement les serveurs Xtream
            self.servers = [s for s in all_servers if s.get('type') == 'xtream']

            # Normalisation des champs
            for server in self.servers:
                if 'active' not in server:
                    server['active'] = False
                if 'name' not in server:
                    server['name'] = 'Serveur inconnu'
                if 'host' not in server and 'url' in server:
                    server['host'] = server['url']
                if 'username' not in server:
                    server['username'] = server.get('user', '')
                if 'password' not in server:
                    server['password'] = ''

            # Ajuster l'index sélectionné
            if self.servers:
                active_index = -1
                for i, s in enumerate(self.servers):
                    if s.get('active', False):
                        active_index = i
                        break
                
                if active_index >= 0:
                    self.selected_index = active_index
                    self.current_page = active_index // self.SERVERS_PER_PAGE
                else:
                    self.selected_index = 0
                    self.current_page = 0
                
                active_count = sum(1 for s in self.servers if s.get('active', False))
                self["status"].setText(f"✅ {len(self.servers)} serveur(s) Xtream ({active_count} actif)")
            else:
                self.selected_index = 0
                self.current_page = 0
                self["status"].setText("⚠️ Aucun serveur Xtream - Cliquez ADD")

        except Exception as e:
            print(f"[XtreamServers] Erreur chargement: {e}")
            self.servers = []
            self["status"].setText("❌ Erreur chargement serveurs Xtream")

    def update_display(self):
        self.update_page_info()
        self.update_grid_display()
        self.update_navigation_buttons()

    def update_page_info(self):
        total_pages = self.get_total_pages()
        if total_pages > 1:
            self["page_info"].setText(f"📄 Page {self.current_page + 1} / {total_pages} ({len(self.servers)} serveur(s) Xtream)")
        else:
            self["page_info"].setText(f"📄 {len(self.servers)} serveur(s) Xtream")

    def update_navigation_buttons(self):
        total_pages = self.get_total_pages()
        if self.current_page == 0:
            self["btn_prev"].setText("◀ PREV (none)")
        else:
            self["btn_prev"].setText("◀ PREV")
            
        if self.current_page >= total_pages - 1:
            self["btn_next"].setText("NEXT (none) ▶")
        else:
            self["btn_next"].setText("NEXT ▶")

    def update_grid_display(self):
        try:
            page_servers = self.get_page_servers()
            start_global = self.current_page * self.SERVERS_PER_PAGE

            for i in range(self.SERVERS_PER_PAGE):
                bg_name = self.grid_backgrounds[i]
                pixmap_name = self.grid_pixmaps[i]
                label_name = self.grid_labels[i]

                if i < len(page_servers):
                    server = page_servers[i]
                    global_idx = start_global + i
                    server_name = server.get('name', f'Serveur {global_idx+1}')
                    is_active = server.get('active', False)
                    is_selected = (global_idx == self.selected_index)

                    if len(server_name) > 28:
                        server_name = server_name[:25] + "..."

                    self[bg_name].show()
                    
                    if is_selected:
                        color = gRGB(60, 75, 50)
                    elif is_active:
                        color = gRGB(30, 70, 30)
                    else:
                        color = gRGB(42, 42, 54)
                    
                    if self[bg_name].instance:
                        self[bg_name].instance.setBackgroundColor(color)
                        if is_selected:
                            self[bg_name].instance.setBorderColor(gRGB(100, 255, 100))
                        else:
                            self[bg_name].instance.setBorderColor(gRGB(85, 85, 85))

                    self[pixmap_name].show()
                    self.set_icon(self[pixmap_name], "xtream")

                    display_text = f"✓ {server_name}" if is_active else f"○ {server_name}"
                    self[label_name].setText(display_text)
                    
                    if is_selected:
                        self[label_name].instance.setForegroundColor(gRGB(255, 255, 100))
                    elif is_active:
                        self[label_name].instance.setForegroundColor(gRGB(0, 255, 0))
                    else:
                        self[label_name].instance.setForegroundColor(gRGB(200, 200, 200))
                    
                    self[label_name].show()

                else:
                    if len(self.servers) == 0 and self.current_page == 0 and i == 0:
                        self[bg_name].show()
                        if self[bg_name].instance:
                            self[bg_name].instance.setBackgroundColor(gRGB(45, 45, 55))
                        self[pixmap_name].hide()
                        self[label_name].setText("⊕ CLICK ADD")
                        self[label_name].instance.setForegroundColor(gRGB(100, 100, 255))
                        self[label_name].show()
                    else:
                        self[bg_name].hide()
                        self[pixmap_name].hide()
                        self[label_name].hide()

        except Exception as e:
            print(f"[XtreamServers] Erreur dans update_grid_display: {e}")

    def set_icon(self, pixmap_widget, server_type):
        try:
            icon_path = self.ICON_XTREAM
            if os.path.exists(icon_path):
                pixmap_widget.instance.setPixmapFromFile(icon_path)
                pixmap_widget.instance.setScale(1)
            else:
                pixmap_widget.hide()
        except Exception as e:
            print(f"[XtreamServers] Erreur chargement icône: {e}")

    def get_current_server(self):
        if 0 <= self.selected_index < len(self.servers):
            return self.servers[self.selected_index]
        return None

    def connect_server(self):
        server = self.get_current_server()
        if not server:
            self.show_message("❌ Aucun serveur sélectionné", "ERROR")
            return
        
        try:
            with open(self.CONFIG_FILE, 'r') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                all_servers = data
            else:
                all_servers = data.get("servers", [])
            
            # Désactiver tous les serveurs Xtream
            for s in all_servers:
                if s.get('type') == 'xtream':
                    s['active'] = False
            
            # Activer le serveur sélectionné
            for s in all_servers:
                if s.get('type') == 'xtream' and s.get('name') == server.get('name'):
                    s['active'] = True
            
            with open(self.CONFIG_FILE, 'w') as f:
                json.dump({"servers": all_servers, "last_updated": str(datetime.now())}, f, indent=4)
            
            self.load_servers()
            self.update_display()
            self.show_message(f"✅ Serveur Xtream activé:\n{server.get('name', '')}", "INFO")
            
        except Exception as e:
            print(f"[XtreamServers] Erreur sauvegarde: {e}")
            self.show_message("❌ Erreur sauvegarde", "ERROR")

    def add_server(self):
        from .servers_list import ServerFormScreen
        self.session.openWithCallback(self.on_form_closed, ServerFormScreen, mode="add", server_type="xtream")

    def edit_server(self):
        server = self.get_current_server()
        if not server:
            self.show_message("❌ Aucun serveur sélectionné", "ERROR")
            return
        from .servers_list import ServerFormScreen
        self.session.openWithCallback(self.on_form_closed, ServerFormScreen, mode="edit", server_data=server, server_index=self.selected_index)

    def on_form_closed(self, result):
        if result:
            self.load_servers()
            self.update_display()

    def delete_server(self):
        server = self.get_current_server()
        if not server:
            self.show_message("❌ Aucun serveur sélectionné", "ERROR")
            return
        
        self.session.openWithCallback(
            lambda result: self.confirm_delete(result, server.get('name', '')),
            MessageBox,
            f"🗑️ Supprimer '{server.get('name', '')}' ?\n\nCette action est irréversible!",
            MessageBox.TYPE_YESNO
        )

    def confirm_delete(self, result, server_name):
        if result:
            try:
                with open(self.CONFIG_FILE, 'r') as f:
                    data = json.load(f)
                
                if isinstance(data, list):
                    all_servers = data
                else:
                    all_servers = data.get("servers", [])
                
                # Supprimer le serveur
                all_servers = [s for s in all_servers if not (s.get('type') == 'xtream' and s.get('name') == server_name)]
                
                with open(self.CONFIG_FILE, 'w') as f:
                    json.dump({"servers": all_servers, "last_updated": str(datetime.now())}, f, indent=4)
                
                self.load_servers()
                self.update_display()
                self.show_message(f"✅ '{server_name}' supprimé", "INFO")
                
            except Exception as e:
                print(f"[XtreamServers] Erreur suppression: {e}")
                self.show_message("❌ Erreur suppression", "ERROR")

    def keyUp(self):
        new_idx = self.selected_index - self.GRID_COLS
        if new_idx >= 0:
            self.selected_index = new_idx
            if new_idx // self.SERVERS_PER_PAGE != self.current_page:
                self.current_page = new_idx // self.SERVERS_PER_PAGE
                self.update_display()
            else:
                self.update_grid_display()
                self.update_navigation_buttons()

    def keyDown(self):
        new_idx = self.selected_index + self.GRID_COLS
        if new_idx < len(self.servers):
            self.selected_index = new_idx
            if new_idx // self.SERVERS_PER_PAGE != self.current_page:
                self.current_page = new_idx // self.SERVERS_PER_PAGE
                self.update_display()
            else:
                self.update_grid_display()
                self.update_navigation_buttons()

    def keyLeft(self):
        if self.selected_index % self.GRID_COLS > 0:
            self.selected_index -= 1
            self.update_grid_display()
            self.update_navigation_buttons()

    def keyRight(self):
        if (self.selected_index % self.GRID_COLS) < self.GRID_COLS - 1:
            new_idx = self.selected_index + 1
            if new_idx < len(self.servers):
                self.selected_index = new_idx
                self.update_grid_display()
                self.update_navigation_buttons()

    def keyOk(self):
        self.connect_server()

    def show_message(self, message, msg_type="INFO"):
        typ = MessageBox.TYPE_INFO if msg_type == "INFO" else MessageBox.TYPE_ERROR
        self.session.open(MessageBox, message, typ, timeout=3)

    def close(self):
        print("[XtreamServers] Fermeture")
        super().close()
