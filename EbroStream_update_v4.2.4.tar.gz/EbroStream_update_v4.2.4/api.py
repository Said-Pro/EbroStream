#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EbroStream Web API Server - Version Complète
Gestion complète des serveurs Stalker et Xtream (CRUD complet)
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import sys
import uuid
import re
from urllib.parse import urlparse

# Configuration
CONFIG_FILE = "/etc/enigma2/EbroStream/servers.json"
DEFAULT_PORT = 8088

# Créer le répertoire de config si nécessaire
os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)


class EbroStreamAPIHandler(BaseHTTPRequestHandler):
    """Gestionnaire complet des requêtes API"""
    
    def _send_json_response(self, code, data):
        response = json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(response)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(response)
    
    def _send_html_response(self, content):
        content_encoded = content.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(content_encoded)))
        self.end_headers()
        self.wfile.write(content_encoded)
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path == '/api/servers':
            self._get_servers()
        elif path == '/api/active':
            self._get_active_server()
        elif path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._get_server_by_id(server_id)
        elif path == '/' or path == '' or path == '/index.html':
            self._serve_web_interface()
        else:
            self._send_json_response(404, {"error": f"Route non trouvée: {path}"})
    
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(post_data) if post_data else {}
        except json.JSONDecodeError:
            data = {}
        
        if path == '/api/servers':
            self._add_server(data)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    def do_PUT(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        put_data = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(put_data) if put_data else {}
        except json.JSONDecodeError:
            data = {}
        
        if path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._update_server(server_id, data)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path.startswith('/api/servers/'):
            server_id = path.split('/')[-1]
            self._delete_server(server_id)
        else:
            self._send_json_response(404, {"error": "Route non trouvée"})
    
    # ==================== MÉTHODES PRINCIPALES ====================
    
    def _get_servers(self):
        """Retourne tous les serveurs"""
        try:
            servers = self._load_servers()
            safe = []
            for server in servers:
                s = server.copy()
                if 'password' in s:
                    s['password'] = '********'
                safe.append(s)
            self._send_json_response(200, {
                "success": True,
                "servers": safe,
                "total": len(safe)
            })
        except Exception as e:
            print(f"[WebAPI] Erreur _get_servers: {e}")
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_server_by_id(self, server_id):
        """Retourne un serveur par son ID (sans cacher le mot de passe)"""
        try:
            servers = self._load_servers()
            server = next((s for s in servers if s.get('id') == server_id), None)
            if not server:
                self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
                return
            self._send_json_response(200, {"success": True, "server": server})
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _get_active_server(self):
        """Retourne le serveur actif"""
        try:
            servers = self._load_servers()
            active = next((s for s in servers if s.get('active', False)), None)
            if active and 'password' in active:
                active = active.copy()
                active['password'] = '********'
            self._send_json_response(200, {"success": True, "server": active})
        except Exception as e:
            self._send_json_response(500, {"success": False, "error": str(e)})
    
    def _add_server(self, data):
        """Ajoute un serveur (Stalker ou Xtream)"""
        errors = []
        server_type = data.get('type', 'stalker')
        
        name = data.get('name', '').strip()
        if not name:
            errors.append("Le nom du serveur est requis")
        
        host = data.get('host', '').strip()
        if not host:
            errors.append("L'URL du serveur est requise")
        
        if server_type == 'stalker':
            mac = data.get('mac', '').strip()
            if not mac:
                errors.append("L'adresse MAC est requise")
        else:
            username = data.get('username', '').strip()
            password = data.get('password', '').strip()
            if not username:
                errors.append("Le nom d'utilisateur est requis")
            if not password:
                errors.append("Le mot de passe est requis")
        
        if errors:
            self._send_json_response(400, {"success": False, "errors": errors})
            return
        
        server = {
            "id": str(uuid.uuid4())[:8],
            "type": server_type,
            "name": name,
            "host": host.rstrip('/'),
            "active": data.get('active', False)
        }
        
        if server_type == 'stalker':
            server["mac"] = self._format_mac(mac)
        else:
            server["username"] = username
            server["password"] = password
        
        if server['active']:
            self._deactivate_all_servers()
        
        servers = self._load_servers()
        servers.append(server)
        
        if self._save_servers(servers):
            response_server = server.copy()
            if 'password' in response_server:
                response_server['password'] = '********'
            self._send_json_response(201, {
                "success": True,
                "message": f"Serveur '{name}' ajouté avec succès",
                "server": response_server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _update_server(self, server_id, data):
        """Met à jour un serveur existant"""
        servers = self._load_servers()
        
        server_index = None
        for i, s in enumerate(servers):
            if s.get('id') == server_id:
                server_index = i
                break
        
        if server_index is None:
            self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
            return
        
        server = servers[server_index]
        old_active = server.get('active', False)
        
        if 'name' in data and data['name']:
            server['name'] = data['name'].strip()
        if 'host' in data and data['host']:
            server['host'] = data['host'].strip().rstrip('/')
        if 'active' in data:
            server['active'] = data['active']
        
        if server['type'] == 'stalker':
            if 'mac' in data and data['mac']:
                server['mac'] = self._format_mac(data['mac'])
        else:
            if 'username' in data and data['username']:
                server['username'] = data['username'].strip()
            if 'password' in data and data['password'] and data['password'] != '********':
                server['password'] = data['password'].strip()
        
        if server.get('active', False) and not old_active:
            for i, s in enumerate(servers):
                if i != server_index:
                    s['active'] = False
        
        if self._save_servers(servers):
            response_server = server.copy()
            if 'password' in response_server:
                response_server['password'] = '********'
            self._send_json_response(200, {
                "success": True,
                "message": "Serveur mis à jour avec succès",
                "server": response_server
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la sauvegarde"})
    
    def _delete_server(self, server_id):
        """Supprime un serveur du fichier"""
        servers = self._load_servers()
        
        server_to_delete = next((s for s in servers if s.get('id') == server_id), None)
        
        if not server_to_delete:
            self._send_json_response(404, {"success": False, "error": "Serveur non trouvé"})
            return
        
        server_name = server_to_delete.get('name', 'Inconnu')
        new_servers = [s for s in servers if s.get('id') != server_id]
        
        if self._save_servers(new_servers):
            self._send_json_response(200, {
                "success": True,
                "message": f"Serveur '{server_name}' supprimé avec succès"
            })
        else:
            self._send_json_response(500, {"success": False, "error": "Erreur lors de la suppression"})
    
    # ==================== MÉTHODES UTILITAIRES ====================
    
    def _load_servers(self):
        """Charge les serveurs depuis le fichier JSON (tolère tous les formats)"""
        if not os.path.exists(CONFIG_FILE):
            # Créer un fichier vide si inexistant
            self._save_servers([])
            return []
        
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
                # Format 1: {"servers": [...]}
                if isinstance(data, dict) and 'servers' in data:
                    return data['servers']
                
                # Format 2: [...] (liste directe)
                elif isinstance(data, list):
                    # Ajouter des IDs si manquants
                    for i, s in enumerate(data):
                        if 'id' not in s:
                            s['id'] = str(uuid.uuid4())[:8]
                        if 'type' not in s:
                            s['type'] = 'stalker'
                        if 'active' not in s:
                            s['active'] = False
                    # Sauvegarder au nouveau format
                    self._save_servers(data)
                    return data
                
                else:
                    return []
                    
        except (json.JSONDecodeError, IOError) as e:
            print(f"[WebAPI] Erreur chargement: {e}")
            return []
    
    def _save_servers(self, servers):
        """Sauvegarde les serveurs dans le fichier JSON"""
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            data = {
                "version": "2.0",
                "servers": servers,
                "total": len(servers)
            }
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"[WebAPI] Sauvegarde réussie: {len(servers)} serveurs")
            return True
        except IOError as e:
            print(f"[WebAPI] Erreur sauvegarde: {e}")
            return False
    
    def _deactivate_all_servers(self):
        servers = self._load_servers()
        for server in servers:
            server['active'] = False
        self._save_servers(servers)
    
    def _format_mac(self, mac):
        if not mac:
            return "00:00:00:00:00:00"
        mac = mac.strip().upper()
        mac = ''.join(c for c in mac if c.isalnum())
        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]
        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])
    
    # ==================== INTERFACE WEB ====================
    
    def _serve_web_interface(self):
        """Sert l'interface HTML complète"""
        html = '''<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EbroStream - Gestion des Serveurs IPTV</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
        body {
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            min-height: 100vh;
            padding: 24px;
        }
        .container { max-width: 1300px; margin:0 auto; }
        .card {
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            border: 1px solid rgba(255,255,255,0.12);
            overflow: hidden;
            margin-bottom: 28px;
        }
        .card-header {
            padding: 20px 28px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        .card-header h2 { font-size: 1.5rem; font-weight: 600; color: #fff; display: flex; align-items: center; gap: 8px; }
        .card-body { padding: 24px 28px; }
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 28px;
        }
        .stat {
            background: rgba(255,255,255,0.08);
            border-radius: 20px;
            padding: 18px 32px;
            text-align: center;
            flex: 1;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .stat-value { font-size: 2.5rem; font-weight: 700; color: #60efff; }
        .stat-label { color: #a8b2d1; margin-top: 6px; font-weight: 500; }
        .tabs {
            display: flex;
            gap: 6px;
            background: rgba(0,0,0,0.3);
            padding: 8px;
            border-radius: 60px;
            width: fit-content;
            margin-bottom: 24px;
        }
        .tab {
            padding: 10px 24px;
            border-radius: 50px;
            color: #ccc;
            cursor: pointer;
            font-weight: 600;
            transition: 0.2s;
        }
        .tab.active {
            background: #3b82f6;
            color: white;
            box-shadow: 0 4px 12px rgba(59,130,246,0.3);
        }
        .form-panel { display: none; }
        .form-panel.active { display: block; }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .form-group { margin-bottom: 18px; }
        label {
            display: block;
            margin-bottom: 8px;
            color: #cbd5e1;
            font-weight: 500;
            font-size: 0.85rem;
        }
        input {
            width: 100%;
            padding: 12px 16px;
            background: rgba(0,0,0,0.45);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 14px;
            color: white;
            font-size: 0.95rem;
            transition: 0.2s;
        }
        input:focus { outline: none; border-color: #60efff; background: rgba(0,0,0,0.6); }
        .checkbox-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 24px;
        }
        .checkbox-row input { width: auto; margin: 0; }
        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-primary { background: #3b82f6; color: white; }
        .btn-primary:hover { background: #2563eb; transform: scale(1.02); }
        .btn-success { background: #10b981; color: white; }
        .btn-success:hover { background: #059669; }
        .btn-warning { background: #f59e0b; color: white; }
        .btn-warning:hover { background: #d97706; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-danger:hover { background: #dc2626; }
        .btn-purple { background: #8b5cf6; color: white; }
        .btn-purple:hover { background: #7c3aed; }
        .btn-sm { padding: 6px 16px; font-size: 0.8rem; }
        .server-list { display: flex; flex-direction: column; gap: 12px; }
        .server-item {
            background: rgba(0,0,0,0.35);
            border-radius: 18px;
            padding: 16px 20px;
            border-left: 4px solid;
            transition: 0.2s;
        }
        .server-item.stalker { border-left-color: #3b82f6; }
        .server-item.xtream { border-left-color: #10b981; }
        .server-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 10px;
        }
        .server-title {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .server-name { font-size: 1.2rem; font-weight: 600; color: white; }
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .badge-stalker { background: rgba(59,130,246,0.2); color: #60a5fa; }
        .badge-xtream { background: rgba(16,185,129,0.2); color: #34d399; }
        .badge-active { background: rgba(16,185,129,0.25); color: #34d399; }
        .badge-inactive { background: rgba(156,163,175,0.2); color: #9ca3af; }
        .server-details {
            font-size: 0.8rem;
            color: #9ca3af;
            margin: 8px 0;
            line-height: 1.5;
        }
        .server-actions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
            flex-wrap: wrap;
        }
        .alert {
            position: fixed;
            bottom: 20px;
            right: 20px;
            max-width: 380px;
            background: #1e293b;
            border-left: 4px solid;
            padding: 14px 20px;
            border-radius: 16px;
            color: white;
            z-index: 1000;
            opacity: 0;
            transition: 0.3s;
            pointer-events: none;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3);
        }
        .alert.show { opacity: 1; }
        .alert.success { border-left-color: #10b981; }
        .alert.error { border-left-color: #ef4444; }
        .loading { text-align: center; padding: 40px; color: #94a3b8; }
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.7);
            align-items: center;
            justify-content: center;
            z-index: 1001;
        }
        .modal.open { display: flex; }
        .modal-content {
            background: #1e1b4b;
            border-radius: 32px;
            width: 90%;
            max-width: 520px;
            padding: 28px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }
        .modal-close {
            background: none;
            border: none;
            color: #cbd5e1;
            font-size: 1.5rem;
            cursor: pointer;
        }
        hr { border-color: rgba(255,255,255,0.08); margin: 16px 0; }
        @media (max-width:700px){ .form-grid { grid-template-columns:1fr; } .stats { flex-direction:column; } }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>📡 EbroStream · Gestion des serveurs IPTV</h2>
        </div>
        <div class="card-body">
            <div class="stats">
                <div class="stat"><div class="stat-value" id="totalCount">0</div><div class="stat-label">Serveurs</div></div>
                <div class="stat"><div class="stat-value" id="activeCount">0</div><div class="stat-label">Actifs</div></div>
            </div>

            <div class="tabs">
                <div class="tab active" data-tab="stalker">📡 Stalker</div>
                <div class="tab" data-tab="xtream">⚡ Xtream Codes</div>
            </div>

            <!-- Formulaire Stalker -->
            <div id="panelStalker" class="form-panel active">
                <div class="form-grid">
                    <div><label>📛 Nom du serveur</label><input type="text" id="stalkerName" placeholder="ex: Mon serveur Stalker"></div>
                    <div><label>🌐 URL du serveur</label><input type="text" id="stalkerHost" placeholder="http://ip:port/c/"></div>
                    <div><label>🔑 Adresse MAC</label><input type="text" id="stalkerMac" placeholder="00:1A:79:00:00:00"></div>
                    <div class="checkbox-row"><input type="checkbox" id="stalkerActive"> <label>✅ Marquer comme actif</label></div>
                </div>
                <button class="btn btn-primary" onclick="addServer('stalker')" style="margin-top:8px">➕ Ajouter le serveur Stalker</button>
            </div>

            <!-- Formulaire Xtream -->
            <div id="panelXtream" class="form-panel">
                <div class="form-grid">
                    <div><label>📛 Nom du serveur</label><input type="text" id="xtreamName" placeholder="ex: Serveur Xtream"></div>
                    <div><label>🌐 URL du serveur</label><input type="text" id="xtreamHost" placeholder="http://ip:port"></div>
                    <div><label>👤 Nom d'utilisateur</label><input type="text" id="xtreamUser" placeholder="username"></div>
                    <div><label>🔒 Mot de passe</label><input type="password" id="xtreamPass" placeholder="password"></div>
                    <div class="checkbox-row"><input type="checkbox" id="xtreamActive"> <label>✅ Marquer comme actif</label></div>
                </div>
                <button class="btn btn-success" onclick="addServer('xtream')" style="margin-top:8px">⚡ Ajouter le serveur Xtream</button>
            </div>

            <hr>
            <h3 style="margin:6px 0 18px 0; color:#cbd5e1;">📋 Liste des serveurs</h3>
            <div id="serversList"><div class="loading">⏳ Chargement en cours...</div></div>
        </div>
    </div>
</div>

<!-- Modal édition -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 style="color:white;">✏️ Modifier le serveur</h3>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <input type="hidden" id="editId">
        <input type="hidden" id="editType">
        <div><label>📛 Nom</label><input type="text" id="editName" placeholder="Nom"></div>
        <div style="margin-top:14px;"><label>🌐 URL</label><input type="text" id="editHost" placeholder="URL"></div>
        <div id="editMacGroup" style="margin-top:14px;"><label>🔑 MAC</label><input type="text" id="editMac" placeholder="00:1A:79:xx:xx:xx"></div>
        <div id="editXtreamGroup" style="display:none; margin-top:14px;">
            <div><label>👤 Username</label><input type="text" id="editUsername" placeholder="username"></div>
            <div style="margin-top:12px;"><label>🔒 Mot de passe</label><input type="password" id="editPassword" placeholder="Laisser vide = inchangé"></div>
        </div>
        <div class="checkbox-row" style="margin-top:18px;"><input type="checkbox" id="editActive"> <label>✅ Actif</label></div>
        <div style="display:flex; gap:12px; margin-top:28px; justify-content:flex-end;">
            <button class="btn" style="background:#334155;" onclick="closeModal()">Annuler</button>
            <button class="btn btn-purple" onclick="saveEdit()">💾 Enregistrer</button>
        </div>
    </div>
</div>

<div id="toast" class="alert"></div>

<script>
    // Tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const type = tab.dataset.tab;
            document.getElementById('panelStalker').classList.toggle('active', type === 'stalker');
            document.getElementById('panelXtream').classList.toggle('active', type === 'xtream');
        });
    });

    function showToast(msg, type='success') {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.className = `alert ${type} show`;
        setTimeout(() => toast.classList.remove('show'), 3500);
    }

    async function loadServers() {
        try {
            const res = await fetch('/api/servers');
            const data = await res.json();
            if(data.success) {
                renderServers(data.servers);
                document.getElementById('totalCount').innerText = data.servers.length;
                document.getElementById('activeCount').innerText = data.servers.filter(s=>s.active).length;
            } else throw new Error(data.error || 'Erreur');
        } catch(e) {
            document.getElementById('serversList').innerHTML = '<div class="loading">❌ Impossible de charger les serveurs</div>';
            showToast(e.message, 'error');
        }
    }

    function renderServers(servers) {
        const container = document.getElementById('serversList');
        if(!servers.length) {
            container.innerHTML = '<div class="loading">📭 Aucun serveur configuré</div>';
            return;
        }
        container.innerHTML = servers.map(s => {
            const isStalker = s.type === 'stalker';
            return `
            <div class="server-item ${isStalker ? 'stalker' : 'xtream'}">
                <div class="server-header">
                    <div class="server-title">
                        <span class="server-name">${escapeHtml(s.name)}</span>
                        <span class="badge ${isStalker ? 'badge-stalker' : 'badge-xtream'}">${s.type.toUpperCase()}</span>
                        <span class="badge ${s.active ? 'badge-active' : 'badge-inactive'}">${s.active ? '✅ ACTIF' : '⭕ INACTIF'}</span>
                    </div>
                </div>
                <div class="server-details">
                    ${isStalker ? `🌐 ${escapeHtml(s.host)}<br>🔑 MAC: ${escapeHtml(s.mac)}` : `🌐 ${escapeHtml(s.host)}<br>👤 User: ${escapeHtml(s.username)}`}
                </div>
                <div class="server-actions">
                    <button class="btn btn-sm ${s.active ? 'btn-warning' : 'btn-success'}" onclick="toggleActive('${s.id}', ${!s.active})">${s.active ? '⏸️ Désactiver' : '▶️ Activer'}</button>
                    <button class="btn btn-sm btn-purple" onclick="openEditModal('${s.id}')">✏️ Modifier</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteServer('${s.id}', '${escapeHtml(s.name).replace(/'/g, "\\'")}')">🗑️ Supprimer</button>
                </div>
            </div>`;
        }).join('');
    }

    function escapeHtml(str) { if(!str) return ''; return str.replace(/[&<>]/g, function(m){ if(m==='&') return '&amp;'; if(m==='<') return '&lt;'; if(m==='>') return '&gt;'; return m;}); }

    async function addServer(type) {
        let payload = { type };
        if(type === 'stalker') {
            payload.name = document.getElementById('stalkerName').value.trim();
            payload.host = document.getElementById('stalkerHost').value.trim();
            payload.mac = document.getElementById('stalkerMac').value.trim();
            payload.active = document.getElementById('stalkerActive').checked;
            if(!payload.name || !payload.host || !payload.mac) { showToast('Tous les champs sont obligatoires', 'error'); return; }
        } else {
            payload.name = document.getElementById('xtreamName').value.trim();
            payload.host = document.getElementById('xtreamHost').value.trim();
            payload.username = document.getElementById('xtreamUser').value.trim();
            payload.password = document.getElementById('xtreamPass').value.trim();
            payload.active = document.getElementById('xtreamActive').checked;
            if(!payload.name || !payload.host || !payload.username || !payload.password) { showToast('Tous les champs sont obligatoires', 'error'); return; }
        }
        try {
            const res = await fetch('/api/servers', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            if(data.success) {
                showToast(data.message, 'success');
                if(type==='stalker') { document.getElementById('stalkerName').value=''; document.getElementById('stalkerHost').value=''; document.getElementById('stalkerMac').value=''; document.getElementById('stalkerActive').checked=false; }
                else { document.getElementById('xtreamName').value=''; document.getElementById('xtreamHost').value=''; document.getElementById('xtreamUser').value=''; document.getElementById('xtreamPass').value=''; document.getElementById('xtreamActive').checked=false; }
                loadServers();
            } else showToast(data.errors ? data.errors.join(', ') : 'Erreur', 'error');
        } catch(e) { showToast('Erreur réseau', 'error'); }
    }

    async function toggleActive(id, active) {
        try {
            const res = await fetch(`/api/servers/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ active }) });
            const data = await res.json();
            if(data.success) { showToast(data.message, 'success'); loadServers(); }
            else showToast(data.error || 'Erreur', 'error');
        } catch(e) { showToast('Erreur', 'error'); }
    }

    async function deleteServer(id, name) {
        if(!confirm(`Supprimer définitivement "${name}" ?`)) return;
        try {
            const res = await fetch(`/api/servers/${id}`, { method:'DELETE' });
            const data = await res.json();
            if(data.success) { showToast(data.message, 'success'); loadServers(); }
            else showToast(data.error, 'error');
        } catch(e) { showToast('Erreur', 'error'); }
    }

    async function openEditModal(id) {
        try {
            const res = await fetch(`/api/servers/${id}`);
            const data = await res.json();
            if(!data.success || !data.server) throw new Error('Impossible de charger');
            const s = data.server;
            document.getElementById('editId').value = s.id;
            document.getElementById('editType').value = s.type;
            document.getElementById('editName').value = s.name || '';
            document.getElementById('editHost').value = s.host || '';
            document.getElementById('editActive').checked = s.active || false;
            const isStalker = s.type === 'stalker';
            document.getElementById('editMacGroup').style.display = isStalker ? 'block' : 'none';
            document.getElementById('editXtreamGroup').style.display = isStalker ? 'none' : 'block';
            if(isStalker) document.getElementById('editMac').value = s.mac || '';
            else {
                document.getElementById('editUsername').value = s.username || '';
                document.getElementById('editPassword').value = '';
            }
            document.getElementById('editModal').classList.add('open');
        } catch(e) { showToast('Erreur chargement', 'error'); }
    }

    async function saveEdit() {
        const id = document.getElementById('editId').value;
        const type = document.getElementById('editType').value;
        const payload = {
            name: document.getElementById('editName').value.trim(),
            host: document.getElementById('editHost').value.trim(),
            active: document.getElementById('editActive').checked,
        };
        if(!payload.name || !payload.host) { showToast('Nom et URL requis', 'error'); return; }
        if(type === 'stalker') {
            const mac = document.getElementById('editMac').value.trim();
            if(mac) payload.mac = mac;
        } else {
            const user = document.getElementById('editUsername').value.trim();
            const pass = document.getElementById('editPassword').value.trim();
            if(user) payload.username = user;
            if(pass) payload.password = pass;
        }
        try {
            const res = await fetch(`/api/servers/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            if(data.success) {
                showToast(data.message, 'success');
                closeModal();
                loadServers();
            } else showToast(data.error || 'Erreur', 'error');
        } catch(e) { showToast('Erreur', 'error'); }
    }

    function closeModal() { document.getElementById('editModal').classList.remove('open'); }
    window.onclick = function(e) { if(e.target === document.getElementById('editModal')) closeModal(); };
    document.addEventListener('DOMContentLoaded', loadServers);
</script>
</body>
</html>'''
        self._send_html_response(html)
    
    def log_message(self, format, *args):
        pass


def run_server(port=DEFAULT_PORT):
    try:
        server = HTTPServer(('0.0.0.0', port), EbroStreamAPIHandler)
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            ip = "127.0.0.1"
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║              EbroStream Web Server v4.3.0                    ║
╠══════════════════════════════════════════════════════════════╣
║  🌐 Serveur démarré sur le port {port}                         ║
║  📁 Fichier config: {CONFIG_FILE}                           ║
║                                                              ║
║  📱 Accédez à l'interface via:                              ║
║     http://{ip}:{port}                                       ║
║                                                              ║
║  🛑 Ctrl+C pour arrêter                                      ║
╚══════════════════════════════════════════════════════════════╝
        """)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Arrêt du serveur web...")
    except Exception as e:
        print(f"❌ Erreur: {e}")


if __name__ == '__main__':
    port = DEFAULT_PORT
    if len(sys.argv) > 2 and sys.argv[1] == '--port':
        try:
            port = int(sys.argv[2])
        except ValueError:
            pass
    run_server(port)