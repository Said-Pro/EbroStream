#!/bin/bash
# start_web.sh - Démarre l'interface web EbroStream

PORT=8088
PLUGIN_DIR="/usr/lib/enigma2/python/Plugins/Extensions/EbroStream"
PID_FILE="/tmp/ebrostream_web.pid"
LOG_FILE="/tmp/ebrostream_web.log"

echo "=========================================="
echo "     EbroStream Web Interface v4.2.1      "
echo "=========================================="

# Vérifier Python3
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 n'est pas installé!"
    exit 1
fi

# Arrêter une instance existante
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 $OLD_PID 2>/dev/null; then
        echo "🛑 Arrêt de l'ancienne instance (PID: $OLD_PID)..."
        kill $OLD_PID
        sleep 2
    fi
    rm -f "$PID_FILE"
fi

# Démarrer le serveur
cd "$PLUGIN_DIR"

echo "🚀 Démarrage du serveur web sur le port $PORT..."

nohup python3 "$PLUGIN_DIR/api.py" --port $PORT > "$LOG_FILE" 2>&1 &
NEW_PID=$!
echo $NEW_PID > "$PID_FILE"

sleep 2

# Vérifier
if kill -0 $NEW_PID 2>/dev/null; then
    # Récupérer l'IP - Version compatible BusyBox
    IP=$(ip -4 addr show | grep -o 'inet [0-9]*\.[0-9]*\.[0-9]*\.[0-9]*' | grep -v 127.0.0.1 | head -1 | cut -d' ' -f2)
    
    if [ -z "$IP" ]; then
        IP=$(ifconfig 2>/dev/null | grep -o 'inet addr:[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*' | grep -v '127.0.0.1' | head -1 | cut -d':' -f2)
    fi
    
    if [ -z "$IP" ]; then
        IP="[IP_DE_LA_BOX]"
    fi
    
    echo ""
    echo "✅ Serveur web démarré avec succès!"
    echo "   PID: $NEW_PID"
    echo "   Port: $PORT"
    echo "   URL: http://$IP:$PORT"
    echo "   Logs: $LOG_FILE"
    echo ""
else
    echo "❌ Échec du démarrage du serveur web"
    echo "📋 Logs:"
    tail -20 "$LOG_FILE"
    exit 1
fi