#!/bin/bash
# stop_web.sh - Arrête l'interface web EbroStream

PID_FILE="/tmp/ebrostream_web.pid"

echo "=========================================="
echo "     Arrêt EbroStream Web Interface       "
echo "=========================================="

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    
    if kill -0 $PID 2>/dev/null; then
        echo "🛑 Arrêt du serveur (PID: $PID)..."
        kill $PID
        sleep 2
        
        if kill -0 $PID 2>/dev/null; then
            echo "⚠️  Force l'arrêt..."
            kill -9 $PID
        fi
        echo "✅ Serveur arrêté"
    else
        echo "ℹ️  Le processus n'existe plus"
    fi
    
    rm -f "$PID_FILE"
else
    echo "ℹ️  Aucun serveur en cours d'exécution"
fi

# Nettoyer les processus orphelins
pkill -f "api.py" 2>/dev/null

echo ""
echo "✅ Nettoyage terminé"